#!/usr/bin/env node
/**
 * Installs the kit's skills (spec M12.11 §6.4, §6.14). It copies every file of each kit skill the configured areas use
 * (`skillsFor`: plan C) from the kit's `skills/` into the repository's skills directory (`areas.about.skillsDir`,
 * default .agents/skills), file for file, and deletes an installed file of a kit skill that the kit no longer ships.
 * A kit skill whose area is not configured is dropped: its kit files and its links go, and its directory with them
 * unless the repository keeps a file of its own there. `REPOSITORY.md`, a repository's own guidance beside a skill, is
 * never written or deleted; nor is any skill the kit does not ship.
 *
 * Then, for each kit skill and each agent directory in `areas.about.skillLinks` (default .claude/skills), it makes the
 * relative symlink `<dir>/<name>` → `<skillsDir>/<name>`, replaces a link that points elsewhere, and removes a link
 * into the skills directory left dangling there (a kit skill the kit dropped, once the repository deletes its copy:
 * the kit cannot tell that copy from the repository's own skill, so it never deletes a skill directory). A real
 * directory at a link's place that is a kit skill (installed before §6.14) moves into the skills directory, its
 * REPOSITORY.md and any file the repository added with it, when the skills directory has no copy yet; when it has one,
 * nothing is written and both paths are named. A link or directory that is not a kit skill's is never touched.
 *
 * The links are committed, so git must not ignore them: the installer refuses, and the About check fails, while it
 * ignores one (an agent directory ignored whole, such as `.claude/`, narrows its rule to what must stay local).
 *
 * Writing needs Linux or macOS (WSL reports linux): the links are symlinks. `--check` only reads, on any platform. The About
 * check fails while an installed kit skill differs from the kit's or a link is missing, wrong or ignored.
 *
 * Which kit skills an area uses: `assess-workspace` and `wayfinder-onboard` always; `assess-audit` with the Audit area,
 * `todo` with its TODO list (`areas.audit.todo`) and `assess-feature-audit` with its feature audit
 * (`areas.audit.featureAudit`); `assess-features`, `assess-api` and `assess-platform-docs` with Features, API and
 * Platform Docs. Readme and Monitor have none.
 *
 * Usage (from the repository root): node node_modules/@nexstratus/workspace-wayfinder/check/install-skills.mjs [--check]
 * --check  report what would change and exit 1 if anything would, without writing
 */
import { execFileSync } from 'node:child_process';
import {
  existsSync,
  lstatSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  readlinkSync,
  realpathSync,
  renameSync,
  rmSync,
  symlinkSync,
  unlinkSync,
  writeFileSync,
} from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadWorkspaceSettings, repoRoot } from './index.mjs';
import { aboutSettings, skillLinksProblems } from './settings-defaults.mjs';

/** The kit's skills directory (`skills/` beside `check/`). */
export const KIT_SKILLS = fileURLToPath(new URL('../skills/', import.meta.url));

/** A file the installer never touches. */
export const REPOSITORY_FILE = 'REPOSITORY.md';

/**
 * Why the installer will not write on `platform`, or undefined on Linux and macOS. The links are symlinks, which a
 * Windows checkout without symlink support turns into text files (spec M12.11 §6.14).
 */
export function platformProblem(platform = process.platform) {
  if (platform === 'linux' || platform === 'darwin') return undefined;
  return `Workspace Wayfinder's skills are installed with symlinks; run this on Linux, macOS or WSL (process.platform is ${platform})`;
}

/**
 * Each kit skill's link path (`<dir>/<name>`, one per `skillLinks` directory) that git ignores at `root`. The links are
 * committed (spec M12.11 §6.14), so an ignored one would never reach a clone. Outside a git repository nothing is.
 */
export function ignoredLinks(skillLinks, { root = repoRoot, kitDir = KIT_SKILLS, skills } = {}) {
  const names = kitSkillNames(kitDir).filter((name) => !skills || skills.includes(name));
  const paths = skillLinks.flatMap((dir) => names.map((name) => `${dir}/${name}`));
  if (paths.length === 0) return [];
  try {
    const out = execFileSync('git', ['check-ignore', '--', ...paths], { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
    return out.split('\n').filter(Boolean);
  } catch (error) {
    if (error.status === 1) return [];
    if (error.status === 128 && /not a git repository/.test(String(error.stderr))) return [];
    throw error;
  }
}

/** Why `ignoredLinks` stops the install and the check, or undefined. */
export function ignoredLinksProblem(ignored) {
  if (ignored.length === 0) return undefined;
  const dirs = [...new Set(ignored.map((at) => path.posix.dirname(at)))];
  return `wayfinder: git ignores ${dirs.join(', ')}, where the skill links are committed; narrow the .gitignore rule to what must stay local (for .claude/: .claude/worktrees/, .claude/settings.local.json), then run install-skills again`;
}

/** Every file under `dir`, relative to it, sorted. */
function files(dir, base = dir) {
  if (!existsSync(dir)) return [];
  return readdirSync(dir, { withFileTypes: true })
    .flatMap((e) => (e.isDirectory() ? files(path.join(dir, e.name), base) : [path.relative(base, path.join(dir, e.name))]))
    .map((f) => f.split(path.sep).join('/'))
    .sort();
}

/** `lstat` or undefined: what is at `at` itself, a symlink not followed. */
function lstat(at) {
  try {
    return lstatSync(at);
  } catch {
    return undefined;
  }
}

/** The names of the skills the kit ships. */
export function kitSkillNames(kitDir = KIT_SKILLS) {
  return readdirSync(kitDir, { withFileTypes: true })
    .filter((e) => e.isDirectory())
    .map((e) => e.name)
    .sort();
}

/** The kit skills every repository installs, whatever its areas. */
export const ALWAYS_SKILLS = ['assess-workspace', 'wayfinder-onboard'];

/**
 * The kit skills the configured areas use (plan C), sorted: `ALWAYS_SKILLS`, then by `settings.areas`: `audit` →
 * `assess-audit`, with `todo` → `todo`, with `featureAudit` → `assess-feature-audit`; `features` → `assess-features`;
 * `api` → `assess-api`; `platform-docs` → `assess-platform-docs`.
 */
export function skillsFor(settings) {
  const areas = settings?.areas ?? {};
  const audit = areas.audit;
  return [
    ...ALWAYS_SKILLS,
    ...(audit ? ['assess-audit'] : []),
    ...(audit?.todo !== undefined ? ['todo'] : []),
    ...(audit?.featureAudit !== undefined ? ['assess-feature-audit'] : []),
    ...(areas.features ? ['assess-features'] : []),
    ...(areas.api ? ['assess-api'] : []),
    ...(areas['platform-docs'] ? ['assess-platform-docs'] : []),
  ].sort();
}

/** The link `<dir>/<name>` should hold: the relative path from `dir` to `<skillsDir>/<name>`. */
export function linkTarget(dir, skillsDir, name) {
  return path.posix.relative(dir, `${skillsDir}/${name}`);
}

/**
 * What installing would change, by repository path: `{ path, change }`, with `to` on a 'move' and 'conflict'.
 * In `skillsDir`: 'add' (a kit file not installed), 'update' (installed but different), 'remove' (installed in a kit
 * skill, no longer shipped). In each `skillLinks` directory: 'link' (no link yet), 'relink' (a link elsewhere),
 * 'unlink' (a link to `<skillsDir>/<its name>`, which does not exist), 'move' (a real directory of a kit skill, moved
 * to `to` before linking) and 'conflict' (something at the link's place that cannot be moved: a copy is at `to` too,
 * or it is not a directory; installSkills writes nothing while there is one).
 * `installedOnly` covers only the kit skills installed in `skillsDir` and leaves out moves and unlinks (the About
 * check's view).
 *
 * `skills` (default every kit skill) names the kit skills to install, and every other is left alone; with `prune`
 * (or `installedOnly`) every other kit skill installed is a 'drop': each file of it the kit ships that is in
 * `skillsDir` (never REPOSITORY.md or a file the repository added), and each link to it in a `skillLinks` directory.
 */
export function skillChanges(
  skillsDir,
  { root = repoRoot, kitDir = KIT_SKILLS, installedOnly = false, skillLinks = [], skills, prune = false } = {}
) {
  const problems = skillLinksProblems(skillsDir, skillLinks, 'installSkills');
  if (problems.length > 0) throw new Error(`wayfinder: ${problems.join('; ')}`);
  const allNames = kitSkillNames(kitDir);
  const unknown = (skills ?? []).filter((name) => !allNames.includes(name));
  if (unknown.length > 0) throw new Error(`wayfinder: ${unknown.join(', ')} is not a kit skill (${allNames.join(', ')})`);
  const kitNames = skills ? allNames.filter((name) => skills.includes(name)) : allNames;
  const changes = [];
  if (skills && (prune || installedOnly))
    for (const name of allNames.filter((n) => !kitNames.includes(n))) {
      const installedAt = `${skillsDir}/${name}`;
      for (const f of files(path.join(kitDir, name)))
        if (f !== REPOSITORY_FILE && lstat(path.join(root, installedAt, f))) changes.push({ path: `${installedAt}/${f}`, change: 'drop' });
      for (const dir of skillLinks) {
        const at = `${dir}/${name}`;
        const link = lstat(path.join(root, at));
        if (link?.isSymbolicLink() && path.resolve(path.join(root, dir), readlinkSync(path.join(root, at))) === path.join(root, installedAt))
          changes.push({ path: at, change: 'drop' });
      }
    }
  for (const name of kitNames) {
    const installedAt = `${skillsDir}/${name}`;
    const installed = lstat(path.join(root, installedAt));
    // A real directory of this kit skill at a link's place: installed there before the skills directory had links.
    const placed = skillLinks.filter((dir) => {
      const at = lstat(path.join(root, dir, name));
      return at && !at.isSymbolicLink();
    });
    let source = installed ? installedAt : undefined;
    if (!installedOnly) {
      for (const dir of placed) {
        const at = `${dir}/${name}`;
        if (!lstat(path.join(root, at)).isDirectory()) changes.push({ path: at, change: 'conflict', to: installedAt });
        else if (source) changes.push({ path: at, change: 'conflict', to: source });
        else {
          changes.push({ path: at, change: 'move', to: installedAt });
          source = at;
        }
      }
    }
    if (installedOnly && !installed) continue;
    const kit = files(path.join(kitDir, name));
    const present = source ? files(path.join(root, source)).filter((f) => f !== REPOSITORY_FILE) : [];
    for (const f of kit) {
      if (f === REPOSITORY_FILE) continue;
      const at = `${installedAt}/${f}`;
      const current = source && path.join(root, source, f);
      if (!current || !existsSync(current)) changes.push({ path: at, change: 'add' });
      else if (!readFileSync(current).equals(readFileSync(path.join(kitDir, name, f)))) changes.push({ path: at, change: 'update' });
    }
    for (const f of present) if (!kit.includes(f)) changes.push({ path: `${installedAt}/${f}`, change: 'remove' });
    for (const dir of skillLinks) {
      const at = `${dir}/${name}`;
      const link = lstat(path.join(root, at));
      if (!link || (!link.isSymbolicLink() && changes.some((c) => c.path === at && c.change === 'move')))
        changes.push({ path: at, change: 'link' });
      else if (!link.isSymbolicLink()) {
        // installedOnly: the About check reports a copy where a link belongs; otherwise it is a 'conflict' above.
        if (installedOnly) changes.push({ path: at, change: 'relink' });
      } else if (path.resolve(path.join(root, dir), readlinkSync(path.join(root, at))) !== path.join(root, installedAt))
        changes.push({ path: at, change: 'relink' });
    }
  }
  if (!installedOnly)
    for (const dir of skillLinks) {
      if (!existsSync(path.join(root, dir))) continue;
      for (const entry of readdirSync(path.join(root, dir), { withFileTypes: true })) {
        if (!entry.isSymbolicLink() || allNames.includes(entry.name)) continue;
        const at = path.join(root, dir, entry.name);
        const target = path.join(root, skillsDir, entry.name);
        if (path.resolve(path.join(root, dir), readlinkSync(at)) === target && !lstat(target))
          changes.push({ path: `${dir}/${entry.name}`, change: 'unlink' });
      }
    }
  return changes;
}

/**
 * Applies `skillChanges` (unless `dryRun`) and returns them. Throws before writing anything on a platform other than
 * Linux or macOS (`platform`, default process.platform; a dry run reads on any), on a link path git ignores, and on a
 * 'conflict'. `skills` and `prune` are `skillChanges`'.
 */
export function installSkills(
  skillsDir,
  { root = repoRoot, kitDir = KIT_SKILLS, dryRun = false, skillLinks = [], platform = process.platform, skills, prune = false } = {}
) {
  const refused = dryRun ? undefined : platformProblem(platform);
  if (refused) throw new Error(refused);
  const ignored = ignoredLinksProblem(ignoredLinks(skillLinks, { root, kitDir, skills }));
  if (ignored) throw new Error(ignored);
  const changes = skillChanges(skillsDir, { root, kitDir, skillLinks, skills, prune });
  if (dryRun) return changes;
  const conflicts = changes.filter((c) => c.change === 'conflict');
  if (conflicts.length > 0)
    throw new Error(
      `wayfinder: nothing installed; ${conflicts
        .map((c) => `${c.path} is in the way of a link to ${c.to}`)
        .join('; ')}. Merge what each holds into ${conflicts.map((c) => c.to).join(', ')} and remove ${conflicts.map((c) => c.path).join(', ')}, then run install-skills again`
    );
  for (const { path: at, to } of changes.filter((c) => c.change === 'move')) {
    mkdirSync(path.dirname(path.join(root, to)), { recursive: true });
    renameSync(path.join(root, at), path.join(root, to));
  }
  for (const { path: at, change } of changes) {
    const target = path.join(root, at);
    if (change === 'remove') rmSync(target);
    else if (change === 'add' || change === 'update') {
      const [, name, ...rest] = at.slice(skillsDir.length).split('/');
      mkdirSync(path.dirname(target), { recursive: true });
      writeFileSync(target, readFileSync(path.join(kitDir, name, ...rest)));
    } else if (change === 'link' || change === 'relink') {
      const dir = path.posix.dirname(at);
      if (change === 'relink') unlinkSync(target);
      mkdirSync(path.dirname(target), { recursive: true });
      symlinkSync(linkTarget(dir, skillsDir, path.posix.basename(at)), target, 'dir');
    } else if (change === 'unlink') unlinkSync(target);
    else if (change === 'drop') {
      if (lstat(target)?.isSymbolicLink()) unlinkSync(target);
      else rmSync(target);
    }
  }
  // A dropped skill's directory goes with its last file; one holding REPOSITORY.md or the repository's own files stays.
  const dropped = changes.filter((c) => c.change === 'drop' && c.path.startsWith(`${skillsDir}/`));
  for (const name of new Set(dropped.map((c) => path.posix.relative(skillsDir, c.path).split('/')[0])))
    removeEmptyDirs(path.join(root, skillsDir, name));
  return changes;
}

/** Removes `dir` and the directories under it that hold no file, deepest first. */
function removeEmptyDirs(dir) {
  if (!existsSync(dir) || !lstatSync(dir).isDirectory()) return;
  for (const e of readdirSync(dir, { withFileTypes: true })) if (e.isDirectory()) removeEmptyDirs(path.join(dir, e.name));
  if (readdirSync(dir).length === 0) rmSync(dir, { recursive: true });
}

/** One change as the script prints it. */
export function describeChange({ path: at, change, to }, dryRun = false) {
  if (change === 'conflict') return `conflict: ${at} is in the way of a link to ${to}; neither is touched`;
  const verb = `${dryRun ? 'would ' : ''}${change}`;
  if (change === 'drop') return `${verb} ${at} (its area is not configured)`;
  return to ? `${verb} ${at} → ${to}` : `${verb} ${at}`;
}

// Run as a script (through node_modules, the path is a symlink to the real file).
if (process.argv[1] && fileURLToPath(import.meta.url) === realpathSync(path.resolve(process.argv[1]))) {
  const settings = await loadWorkspaceSettings();
  const { skillsDir, skillLinks } = aboutSettings(settings.areas.about ?? {});
  const skills = skillsFor(settings);
  const dryRun = process.argv.includes('--check');
  let changes;
  try {
    changes = installSkills(skillsDir, { dryRun, skillLinks, skills, prune: true });
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
  for (const change of changes) console.log(describeChange(change, dryRun));
  const links = skillLinks.length > 0 ? `, linked from ${skillLinks.join(', ')}` : '';
  if (changes.length === 0) console.log(`skills up to date in ${skillsDir} (${skills.length} of the kit's ${kitSkillNames().length} skills, for the configured areas${links})`);
  else if (dryRun) process.exit(1);
}
