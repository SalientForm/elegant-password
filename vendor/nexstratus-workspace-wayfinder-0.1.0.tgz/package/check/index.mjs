/**
 * The check library every workspace script imports (spec M12.3 §5.9): plain node, no dependencies, no build step.
 * Scripts import it by name: `@nexstratus/workspace-wayfinder/check`.
 */
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

/** The repository the script runs in (the cwd's git top level). */
export const repoRoot = execFileSync('git', ['rev-parse', '--show-toplevel'], { encoding: 'utf8' }).trim();
export const today = new Date().toISOString().slice(0, 10);

export function readRepo(file) { return readFileSync(path.join(repoRoot, file), 'utf8'); }
export function exists(file) { return existsSync(path.join(repoRoot, file)); }

/** Value of `export const NAME = 'YYYY-MM-DD'` in file, or null. */
export function readDate(file, exportName) {
  const m = new RegExp(`export const ${exportName} = '(\\d{4}-\\d{2}-\\d{2})'`).exec(readRepo(file));
  return m ? m[1] : null;
}

/** The date rule for a `export const NAME = 'YYYY-MM-DD'` reviewed-at date in file. */
export function dateRule(problems, file, exportName) {
  modifiedDateRule(problems, `${file}: ${exportName}`, readDate(file, exportName));
}

/**
 * The one rule for every "when was this last modified" date: a valid ISO date that is not after today.
 * It records the day the change was actually made, written by whoever makes it. It is not derived
 * from git: when the change is committed, rebased or merged has no bearing on it.
 * `label` names the date in the problem text (e.g. `docs/reviews/index.md: reviewedAt` or `docs/reviews: docReviews README.md lastModified`).
 */
export function modifiedDateRule(problems, label, value) {
  if (!value || Number.isNaN(Date.parse(value))) { problems.push(`${label} missing or not an ISO date`); return; }
  if (value > today) problems.push(`${label}=${value} is in the future (today is ${today})`);
}

export function finish(problems, okMessage) {
  if (problems.length) { console.error(problems.join('\n')); console.error(`\n${problems.length} problem(s)`); process.exit(1); }
  console.log(okMessage);
}

/** The workspace config's data half, from the path in the root package.json `wayfinder.config` (spec §5.9, §7). */
export async function loadWorkspaceSettings() {
  const pointer = JSON.parse(readRepo('package.json')).wayfinder?.config;
  if (typeof pointer !== 'string') throw new Error('wayfinder: package.json has no wayfinder.config (the path of workspace.config.mts)');
  if (!exists(pointer)) throw new Error(`wayfinder: ${pointer} does not exist (package.json wayfinder.config)`);
  const settings = (await import(pathToFileURL(path.join(repoRoot, pointer)).href)).default;
  if (!settings || typeof settings.areas !== 'object') throw new Error(`wayfinder: ${pointer} has no default export with areas`);
  return settings;
}

/** The hooks a repository's rules file may export (spec M12.11 §6.2). */
export const RULE_HOOKS = ['productRoutes', 'navLabels', 'fetchSites', 'extraChecks'];

/**
 * The repository's own rules, from the path in the root package.json `wayfinder.rules`: an ESM module whose named
 * exports from RULE_HOOKS are its hooks (other exports, helpers its tests import, are ignored). `{}` without the
 * pointer; throws on a missing file or a hook that is not a function.
 */
export async function loadWorkspaceRules() {
  const pointer = JSON.parse(readRepo('package.json')).wayfinder?.rules;
  if (pointer === undefined) return {};
  if (typeof pointer !== 'string') throw new Error('wayfinder: package.json wayfinder.rules is not a path');
  if (!exists(pointer)) throw new Error(`wayfinder: ${pointer} does not exist (package.json wayfinder.rules)`);
  const module = await import(pathToFileURL(path.join(repoRoot, pointer)).href);
  const rules = {};
  for (const name of RULE_HOOKS) {
    if (module[name] === undefined) continue;
    if (typeof module[name] !== 'function') throw new Error(`wayfinder: ${pointer} export ${name} is not a function`);
    rules[name] = module[name];
  }
  return rules;
}
