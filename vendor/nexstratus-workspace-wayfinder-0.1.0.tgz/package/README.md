# @nexstratus/workspace-wayfinder

Workspace Wayfinder: an engineering workspace a repository runs as its own small Vite app. Areas for the roadmap,
specs and every markdown file (Audit), READMEs, a feature catalogue with its tests and coverage, an API reference,
plain-language product docs and environments, each built from the repository's files at build time, and skills with check scripts that keep them true to the code. The kit holds the shell, the area contract, the
area modules, the Vite plugins, the check library, the skills and the default About prose; a repository supplies its
configuration, its registries and its theme mapping. It assumes JavaScript or TypeScript with Vite.

- **Releases are tarballs:** each version is a `.tgz` attached to a GitHub Release of the kit's repository (the
  `repository` in its `package.json`), with its sha256. There is no registry: a repository commits the tarball under
  `vendor/` and depends on it by that path, so installs need no token anywhere
- **Seven areas, no Design System:** a design system shows a product's look, so it is the repository's own app; the
  workspace's header can link to it (`links`)

## In a repository

Start from the repository root of a git checkout, on Linux, macOS or WSL, with Node 22.18 or later. Download the
release's tarball into `vendor/` (from the Releases page of the kit's repository, or with the GitHub CLI), then:

```bash
gh release download v<version> --repo <owner>/workspace-wayfinder --pattern '*.tgz' --dir vendor
pnpm add -D file:vendor/nexstratus-workspace-wayfinder-<version>.tgz
pnpm exec wayfinder init   # installs the wayfinder-onboard skill alone, linked from .claude/skills
```

**Commit the tarball.** `vendor/nexstratus-workspace-wayfinder-<version>.tgz` is committed with `package.json` and the
lockfile, which name it by that relative path (`file:vendor/…`) with its integrity hash. So `pnpm install
--frozen-lockfile` works in every checkout, in CI and in an image built from the repository, with no registry and no
token. Keep `vendor/` and `*.tgz` out of the ignore files of anything that builds from the repository (`.gitignore`,
`.dockerignore`, a deploy tool's own). The release's `.sha256` file checks the download (`sha256sum -c`, run in
`vendor/`).

**Exclude the kit from pnpm's release-age policy.** pnpm 11 checks a lockfile's entries against `minimumReleaseAge`
on an install it has not verified before (CI, an image build), asking the registry when each version was published.
The registry has no such package, so the install fails (`ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION`, a 404). Name the
kit in `pnpm-workspace.yaml` (a single-package repository can have one for settings alone):

```yaml
minimumReleaseAgeExclude:
  - '@nexstratus/workspace-wayfinder'
```

**Upgrading.** Download the new version's tarball into `vendor/`, then:

```bash
pnpm add -D file:vendor/nexstratus-workspace-wayfinder-<new>.tgz
git rm vendor/nexstratus-workspace-wayfinder-<old>.tgz
pnpm skills:install         # the kit's skills as the new version ships them
pnpm workspace:check        # or the repository's areas.about.checkScript
```

Commit the new tarball, `package.json`, the lockfile and the skills' changes together. A release changes the installed
skills only through `skills:install`; review its diff like any other.

**What the workspace app needs beside the kit** (the onboarding skill's §3 step 1 installs those the repository lacks,
as dev dependencies in a single-package repository). The kit's peer dependencies: `react` and `react-dom` 19, `vite` 7
or 8, `@tanstack/react-router`, `@tanstack/react-query` and `@tanstack/router-core`; `vitest` 3 or 5 and
`@testing-library/react` only for tests that use the kit's `./testing` helpers; `typescript` 5 only for the Features
area's test inventory, which parses test files with its compiler API (TypeScript 7's package has none). The app's own, which its templates
use but the kit does not import: `@vitejs/plugin-react`, and with Tailwind v4, `tailwindcss` and `@tailwindcss/vite`.

**The toolchain it is proved on:** Node 22.18 or later, React 19, Vite 7 and 8, Vitest 3 and 5, and TypeScript 5.9 and 7
typechecking the app against the kit's declarations; pnpm. **Tailwind is optional:** an app with Tailwind v4 imports
`./tailwind.css`, so its own build compiles the kit's classes with its theme; an app without it imports the compiled
`./styles.css` and installs no Tailwind. The onboarding skill writes either, from what it finds.

Then ask the repository's coding agent to run the `wayfinder-onboard` skill. `wayfinder init [--skills-dir <dir>]`
installs that one skill into the skills directory (`.agents/skills` by default) byte for byte as the installer would,
and links it from `.claude/skills`; run again, it updates it. The skill does the rest: it discovers the repository's
shape, chooses the areas, writes the files below from its templates, adds the root script `skills:install`
(`node node_modules/@nexstratus/workspace-wayfinder/check/install-skills.mjs`) and runs it to install the skills. From then on that script owns the skills: once
`package.json` names `wayfinder.config`, `wayfinder init` installs nothing and points at it. What a repository holds:

| File | What it is |
| --- | --- |
| root `package.json` `wayfinder` | `config`: the workspace config's path; `rules`: the rules file's, when there is one |
| the workspace config (`workspace.config.mts`) | the data half: `WorkspaceSettings` (`dist/settings.d.ts` in the package documents every field), read by Vite, the browser and the checks; among them the workspace's `ports`, assigned at setup and never a default, and optional header `links` to the repository's other apps served beside the workspace (on the page's host at another port in development, at a path on the same origin in a build; an app on another origin is not linked) |
| the rules file (`workspace.rules.mjs`) | optional: the repository's own rules for the checks, as hooks (`productRoutes`, `navLabels`, `fetchSites`, `extraChecks`; `check/index.d.mts`) |
| the workspace app | `create…Area` per configured area, `createWorkspace`, the router, `WorkspaceShell`, the Vite plugins its areas need |
| registries | the JSON and markdown files the areas read (the spec ledger and reviews, the feature audit, the API registry, the roadmap and TODO list, all in `docs/formats.md`'s formats) |
| reviews (`areas.audit.reviews`, default `docs/reviews`) | a markdown folder: `index.md` (date, All markdowns sections, Documentation list) and one `<path>.review.md` per reviewed document. A content collection must cover it |
| About prose | `<areas.about.prose>/<name>.md`, only where the kit's default (`prose/`) says something untrue for the repository |
| skills | the kit's skills of the configured areas, copied into the skills directory (`areas.about.skillsDir`, default `.agents/skills`) by the root script `skills:install` (`node node_modules/@nexstratus/workspace-wayfinder/check/install-skills.mjs`), with a relative symlink per skill in each agent directory of `areas.about.skillLinks` (default `['.claude/skills']`); the repository's own rules for one go in `REPOSITORY.md` beside it, which the installer never touches |
| the check script | `workspace:check` (or `areas.about.checkScript`): one `node <skillsDir>/<skill>/scripts/<check>.mjs` per area, each a `runCheck('<name>')` |

### Skills for any agent

The skills are in the shared skill format (a directory with a `SKILL.md`) that Claude Code, Codex and opencode all
read; only where each looks differs. The installer copies those of the configured areas (`assess-workspace` and
`wayfinder-onboard` always; `assess-audit` with Audit, `todo` with its TODO list, `assess-feature-audit` with its
feature audit; `assess-features`, `assess-api` and `assess-platform-docs` with their areas) into the skills directory,
by default the agent-neutral `.agents/skills`, which Codex (from the working directory up to the repository root) and
opencode read, and drops a kit skill whose area is no longer configured (its kit files and links; a `REPOSITORY.md`
stays).
For every agent directory in `skillLinks` it makes `<dir>/<name>` → the relative path to `<skillsDir>/<name>`
(`.claude/skills/todo` → `../../.agents/skills/todo`, for Claude Code), so an agent directory keeps skills of its own
beside the kit's. It replaces a link that points elsewhere, removes a link into the skills directory whose skill is
gone, and moves a kit skill installed in an agent directory before the links (a real directory there) into the
skills directory, `REPOSITORY.md` with it; when both exist it stops and names the two. It touches no skill or link
that is not the kit's. The links are committed (git stores symlinks as such), so git must not ignore them: the
installer refuses and the About check fails while it does. A repository that ignores an agent directory whole (often
`.claude/`, for agents' scratch worktrees) narrows the rule to what stays local: `.claude/worktrees/`,
`.claude/settings.local.json`.

**Linux, macOS or WSL.** The links are symlinks, which a Windows checkout without symlink support turns into text
files, so the installer (and `wayfinder init`, which uses it) refuses to write unless `process.platform` is `linux`
or `darwin` (WSL reports `linux`). `--check` and the checks only read, and run anywhere. The About check fails while a copy
differs from the kit's, a link is missing, is a copy or points elsewhere, or the check script runs a kit skill through
an agent directory.

## Subpaths

| Subpath        | What it is                                                                        |
| -------------- | --------------------------------------------------------------------------------- |
| `.`            | the browser entry (`dist/index.js`)                                               |
| `./vite`       | the Vite plugins (node side; the browser entry never imports them): `wayfinder()`, the content manifest and the dev and preview ports, `featureSources()`, the Features source scan, `testInventory()`, the Features test inventory, and `featureCoverage()`, the Features coverage summaries |
| `./testing`    | render and router helpers for a consumer's tests                                  |
| `./check`      | the check library the drift scripts run on (plain-node ESM, no build step)        |
| `./check/*`    | single check files, such as the audit markdown parser                             |
| `./tailwind.css` | for an app with Tailwind v4: the `--ws-*` token contract and the kit's rules, with an `@source` on the kit's built JS, so the app's own build compiles the kit's classes with its theme |
| `./styles.css` | for an app without Tailwind: the same, compiled with Tailwind's theme, preflight and the kit's utilities |
| `./env`        | the declarations of the four `virtual:` modules the plugins serve; an app adds it to its tsconfig `types` |

## Modules

Each module below ships built in `dist/` (its `.js` and `.d.ts`; `dist/settings.d.ts` for `settings.ts`, say) unless
named otherwise; `check/`, `bin/`, `skills/`, `prose/` and `docs/` ship as they are, beside `dist/`.

| Path                                    | What it holds                                                                                                                                                                     |
| --------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `contract.ts`, `settings.ts`            | the area contract (`AreaDefinition` and the nav, search, title, redirect and link types) and `WorkspaceSettings`, a config's data half                                            |
| `workspace.ts`, `workspace-context.tsx` | `createWorkspace` (load-time checks over the settings and the definitions), `WorkspaceProvider` / `useWorkspace`, `AreaProvider` / `useArea`                                      |
| `redirects.ts`, `links.ts`              | the redirect table built from the config and each area's rows; `resolveLink`, which asks each area's resolver in header order and falls back to the repository's GitHub URL       |
| `router/`                               | `createWorkspaceRoutes` (the root route), `createWorkspaceRouter`, `WsLink` and the location seam                                                                                 |
| `shell/`                                | `WorkspaceShell` and the frame it draws: header, area frame and sidebar, search palette, not-found                                                                                |
| `markdown/`                             | `MarkdownDoc`, `MarkdownBody`, front matter, heading anchors and heading search entries                                                                                           |
| `components/`                           | `GithubLink`, `CopyButton`, `MarkdownDownloadLink`                                                                                                                                |
| `lib/`                                  | search and fuzzy matching, the search shortcut, the hash-arrival and filter-reset hooks, last-viewed memory, storage                                                              |
| `content/`, `vite/`                     | the content API (`readDoc`, `hasDoc`, `listDocs`, `listCollection`, `contentCollections`) over `virtual:workspace-content`, which `wayfinder()` builds from `settings.content`, with the app's `base` and `dev`; `featureSources()`, which serves `virtual:workspace-feature-sources` from the Features area's source roots and its features' `sources` globs; `testInventory()`, which serves `virtual:workspace-test-inventory`, every test file the Features area's `tests.include` globs match, parsed and cached by mtime; `featureCoverage()`, which serves `virtual:workspace-feature-coverage`, the v8 `json-summary` files its `coverage.summaries` globs match |
| `ui/`, `styles.css`                     | the primitives the kit renders with (not exported) and the `--ws-*` token contract                                                                                                |
| `about/`                                | About, the first kit module: `createAboutArea`, its pages, and the kit's own models (`SHELL_MODELS`, `ABOUT_MODELS`)                                                              |
| `readme/`                               | Readme Index: `createReadmeArea`, configured with a content collection and sidebar sections (`settings.areas.readme`); its `kitModels`                                            |
| `platform-docs/`                        | Platform Docs: `createPlatformDocsArea`, configured with a front-matter markdown directory and its reviewed date (`settings.areas['platform-docs']`) and `settings.product`; its `kitModels` |
| `api/`                                  | API: `createApiArea`, configured with an OpenAPI document and an optional JSON consumer registry with its reviewed date (`settings.areas.api`), the running API's URL and legacy redirects; its `kitModels` |
| `monitor/`                              | Monitor: `createMonitorArea`, configured with the environments and the build-info endpoint contract (`settings.areas.monitor`), `settings.product` and values for the URLs' `{NAME}` placeholders; the reader's list in `ws:environments`, the request a `useQuery`; its `kitModels` |
| `features/`                             | Features: `createFeaturesArea`, the feature catalogue from a front-matter markdown directory (`settings.areas.features`: `directory`, `reviewedAt`, `sourceRoots`, `tests`, `coverage`) joined with the route mirror (`settings.productRoutes`), the source scan, the test inventory and the coverage summaries; an index filterable by status and sortable by line coverage, a page per feature (links, prose, its unit and end-to-end tests by description, its coverage and E2E routes visited, the files each glob matches), Tests (every test by file: unassigned, by feature, infrastructure) and Gaps (unowned routes, features with no tests, empty globs, unclaimed source files); the product passes its links for specs and roadmap ids; its `kitModels` |
| `audit/`                                | Audit: `createAuditArea`, the whole area from four internal parts: the implementation pages (Architecture, Roadmap, Todo over three markdown files, each optional, and their phase kinds and TODO areas), the spec ledger (unimplemented and implemented specs, All markdowns, the full-document view), the optional Documentation section and the optional feature audit: the ledger from each spec's and plan's front matter and the review files (`settings.areas.audit`: `reviews`, `specDirs`), the feature audit from JSON (`featureAudit`); the product passes its legacy redirects; its `kitModels` |
| `testing/`                              | `renderAt`, `routerAt`, `renderWorkspace` and `testWorkspace`                                                                                                                     |
| `check/` (beside `dist/`)               | the check library (plain-node ESM): the repository root, the date rule, `finish`, `loadWorkspaceSettings` and `loadWorkspaceRules` (`index.mjs`); the runner every skill script calls (`run.mjs`); the settings' defaults both sides read (`settings-defaults.mjs`); each area's rules (`about.mjs`, `audit-implementation.mjs`, `audit-ledger.mjs`, `feature-audit.mjs`, `feature-catalogue.mjs`, `api.mjs`, `platform-docs.mjs`) with the readers and builders they share with the modules; the ports and links rules `wayfinder()` and `createWorkspace` share (`ports.mjs`); the dead-code sweep (`unused-exports.mjs`); the skills installer and linker (`install-skills.mjs`) |
| `bin/` (beside `dist/`)                 | the command line, the package's `bin` `wayfinder` (`bin/wayfinder.mjs`): `wayfinder init`, which starts a repository by installing the onboarding skill |
| `skills/`, `prose/`, `docs/` (beside `dist/`) | the skills a repository installs (the six `assess-*` skills, `todo`, and `wayfinder-onboard` with its templates); the default About prose; `formats.md`, the roadmap, TODO, architecture, Milestone-line and ledger formats |

## Built

The package is built: no consumer aliases, references or scans the kit's source. `dist/` holds the three entries' JS,
one file per module, with their declarations and `env.d.ts`, and the two stylesheets, `styles.css` and `tailwind.css`;
dependencies, peers and the `virtual:` modules stay imports, and so do the `check/` modules, which ship beside
`dist/`. The JS reads nothing from `import.meta.env`: the app's base URL and dev flag come from
`virtual:workspace-content`'s `base` and `dev`, which `wayfinder()` writes in the app's build. `wayfinder()` also keeps
the kit out of Vite's dependency optimiser (its `virtual:` imports must reach the plugins) and pre-bundles the kit's
dependencies through it instead. Under Vitest, a test that imports the kit from `node_modules` needs it inlined
(`test.server.deps.inline: ['@nexstratus/workspace-wayfinder']`), for the same reason.

## The boundary

The kit is decoupled from any product. Nothing in the kit imports a product package, reads a product CSS variable or
palette class, or names a product or its paths. The consumer passes in its theme provider, its QueryClient and any component library it wants; the kit
renders with its own primitives over the `--ws-*` tokens, which the consumer maps from its theme. Monitor's request
is a TanStack Query `useQuery`, so `@tanstack/react-query` is a peer dependency and the consumer renders the
`QueryClientProvider`.

The kit renders no component library's providers either. `WorkspaceShell` provides only the tooltip provider the
kit's own `Tooltip` needs; a consumer whose own areas need its library's providers (toasts, tooltips)
renders them around the shell. `@radix-ui/react-toast` is not a kit dependency.

## Developing the kit

For the kit's maintainers, in this repository; nothing here is needed to install or use it.

- **Setup:** `pnpm install` (Node 22.18 or later, pnpm as `packageManager` names it). CI (`.github/workflows/ci.yml`)
  runs, on Node 22 and 24: `pnpm install --frozen-lockfile`, `pnpm lint`, `pnpm typecheck`, `pnpm build`, `pnpm test`,
  `pnpm test:check` and `pnpm tarball`.
- **Building:** `pnpm build` (`scripts/build.mjs`) writes `dist/`: the JS in Vite library mode (`vite.config.ts`), the
  declarations (`tsconfig.lib.json`), `env.d.ts` (`src/env.d.ts`) and the stylesheets (`src/build.css`, and
  `tailwind.css`). `pnpm test` reads `dist/`, so build first (the built-package tests are skipped without it).
  `prepack` builds too, so every tarball is packed from a fresh `dist/`. `build:watch` rebuilds on change.
- **Tooling:** `tsconfig.lib.json` (what is built) and `tsconfig.spec.json` (the tests), with `tsconfig.json` for
  editors; `eslint.config.mjs`; `vite.config.ts`, which holds the library build and the Vitest config; the scripts
  `build`, `typecheck`, `lint`, `test`, `test:check` (the `check/` specs, `node --test`) and `tarball` (`pnpm pack` into
  `pack/`). Tests sit beside their file in `src/`; they read only the fixture repository, `src/test-fixtures/`.
- **Against a repository that runs it:** build and pack straight into that repository's `vendor/`, then reinstall
  there:

  ```bash
  pnpm pack --pack-destination <repository>/vendor          # prepack builds first
  cd <repository> && pnpm add -D file:vendor/nexstratus-workspace-wayfinder-<version>.tgz
  ```

  The version is the one in this `package.json`, so a repack replaces the file in place. `pnpm add` again records the
  new integrity in the lockfile, but pnpm can keep the copy it installed before for an unchanged version, so remove
  that first: `rm -rf node_modules/.pnpm/@nexstratus+workspace-wayfinder@* node_modules/.pnpm-workspace-state-v1.json`
  in the repository, then `pnpm add`. Run its `skills:install`, its check script and its workspace build. Commit
  nothing there from a local pack; a repository commits only a released tarball.
- **Releasing:** bump `version` in `package.json` and the tag in `KIT_SOURCE` (`src/kit.ts`; a test keeps them equal),
  commit, tag `v<version>` and push the tag. `.github/workflows/release.yml` checks that the tag is the version, builds,
  tests, packs and creates the GitHub Release with the `.tgz` and its `.sha256`, using the workflow's own token. A
  given commit packs to the same bytes anywhere (`pnpm pack` fixes every entry's mtime).
- **The boundary's tests:** the kit names its own files by their source path (`src/settings.ts`), linked through
  `KIT_SOURCE` (`src/kit.ts`), this repository at the installed version's tag; a test fails on a product name in
  anything the kit ships, and `src/package.test.ts` on a package the kit imports that its `package.json` does not
  declare.
- **History:** the kit was developed in the first repository that ran it, at `libs/workspace`, until version 0.1.0;
  its history came with it (`git subtree split`), so earlier commit messages cite that repository's specs and plans by
  milestone.
