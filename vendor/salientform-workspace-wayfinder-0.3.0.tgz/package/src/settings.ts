/** The data half of a workspace config: plain values only, so plain `node` can load it. */
export interface WorkspaceSettings {
  /** Last part of every `document.title`, e.g. 'Acme Workspace'. */
  title: string;
  /** The product the workspace documents, e.g. 'Acme' (Platform Docs and check messages). */
  product: string;
  /** Header logo, served from the app's public directory under BASE_URL. Omit to show `title` as text. */
  logo?: { src: string; alt: string; width: number; height: number };
  /** Where repository paths link when no area renders them: `${url}/blob/${branch}/<path>`. */
  repository: { url: string; branch: string };
  /**
   * The workspace's own ports, assigned when the kit is set up from the repository's port rules, never a default:
   * `wayfinder()` serves the dev server on `dev` and the preview on `preview` (`strictPort`, host 127.0.0.1). A
   * repository whose ports live in its environment passes them to `wayfinder({ ports })`, which wins. Checked at load:
   * integers from 1024 to 65535, different, and not a framework default (`check/ports.mjs`).
   */
  ports: WorkspacePorts;
  /**
   * Links in the header, after the areas, to the repository's other apps served beside the workspace: on a dev server
   * (or a build served at '/'), the page's host on `port`; in a build served under another base, `path` on the same
   * origin. Only for such apps: a link is never a full URL, so an app deployed on another origin is not linked here.
   */
  links?: readonly WorkspaceLink[];
  /** Areas in header order. Keys are URL slugs (lowercase kebab); values are each area module's settings. */
  areas: Readonly<Record<string, AreaSettings>>;
  /** The content manifest: named collections of repository-relative globs, '!' excluding. */
  content: Readonly<Record<string, readonly string[]>>;
  /**
   * Repository path of the product's route mirror (JSON, `ProductRoutes`): the routes and sidebar paths of the product
   * the workspace documents, which the product's own check keeps equal to its router. The Features area needs
   * it: every route belongs to one feature. A content collection must cover it.
   */
  productRoutes?: string;
}

/** The workspace's dev and preview server ports (`settings.ports`, or `wayfinder({ ports })`). */
export interface WorkspacePorts {
  dev: number;
  preview: number;
}

/** A header link to another of the repository's apps served beside the workspace (`settings.links`); no full URL. */
export interface WorkspaceLink {
  /** The link's text. */
  label: string;
  /** The other app's dev server port. */
  port: number;
  /**
   * The other app's path on the workspace's origin when built and served beside it under a base, e.g. '/docs/'.
   * Leave it out when the two are never served together: a build under a base then shows no link to the app.
   */
  path?: string;
}

/** Settings of one area module; each module narrows it (About: AboutSettings). Empty until the area moves. */
export type AreaSettings = Readonly<Record<string, unknown>>;

/** About's entry in `settings.areas` (the About module, `about/`). */
export interface AboutSettings {
  /** Repository path of the product's About manifest; `check/about.mjs` reads it with a regex. */
  manifest: string;
  /** Directory of the About prose files: `check/about.mjs` checks them; the product passes it to `createAboutArea`. */
  prose: string;
  /**
   * The skills directory, where the kit's skills are installed: `<skillsDir>/<name>/SKILL.md` and
   * `<skillsDir>/<name>/scripts/*.mjs`. Default `.agents/skills`, which Codex and opencode read.
   */
  skillsDir?: string;
  /**
   * The agent directories that see each kit skill through a relative symlink `<dir>/<name>` → `<skillsDir>/<name>`
   * (`check/install-skills.mjs` makes them). Repository-relative, none equal to `skillsDir` or inside it, none
   * repeated; checked at load. Default `['.claude/skills']`, for Claude Code; `[]` for none.
   */
  skillLinks?: readonly string[];
  /** The root package.json script that runs every check (`node <script>` steps). Default `workspace:check`. */
  checkScript?: string;
}

/** Readme's entry in `settings.areas` (the Readme module, `readme/`). */
export interface ReadmeSettings {
  /** Content collection of the READMEs to render: the root `README.md` (the area root) and `<dir>/README.md` files. */
  collection: string;
  /**
   * Sidebar sections after the root README, in order. A README belongs to the first section whose `prefix` its path
   * starts with, and is labelled by its directory with that prefix removed.
   */
  sections: readonly ReadmeSection[];
  /** Header and page title. Default 'Readme Index'. */
  title?: string;
  /** One sentence under the title and on About. */
  description?: string;
}

/** One sidebar section of the Readme module. */
export interface ReadmeSection {
  title: string;
  /** Repository path prefix, ending in '/': 'libs/'. */
  prefix: string;
}

/** Platform Docs' entry in `settings.areas` (the Platform Docs module, `platform-docs/`). */
export interface PlatformDocsSettings {
  /**
   * Repository directory of the pages, no trailing '/': one markdown file per page, named `<order>-<slug>.md`, with
   * `title`, numeric `order` and `summary` front matter. A content collection must cover its `*.md` files.
   */
  directory: string;
  /** ISO date the pages were last checked against the product. Written only by the area's skill. */
  reviewedAt: string;
  /** Header and page title. Default 'Platform'. */
  title?: string;
  /** One sentence under the title and on About. Default built from `settings.product`. */
  description?: string;
}

/**
 * What a part of the workspace that cannot be generated yet says instead: why, and what would fill it.
 * The settings form of a document's placeholder (`docs/formats.md`, "Placeholders"): `reason` is its "Not generated
 * yet." line, `toFill` its "To fill:" line. Both are non-empty sentences.
 */
export interface Placeholder {
  /** Why it cannot be generated yet: what was looked for and not found. */
  reason: string;
  /** What would fill it: a file to add, a decision to make, a skill to run. */
  toFill: string;
}

/**
 * The settings of an area the repository cannot support yet (Features, API, Platform Docs): it stays in
 * `areas`, in the header and in About, and its page is the placeholder under the area's default description. Its
 * check passes and prints the placeholder; its skill tests first whether the area can now be generated.
 */
export interface PlaceholderAreaSettings {
  placeholder: Placeholder;
  /** Header and page title. Default the area's. */
  title?: string;
  /** One sentence under the title and on About. Default the area's description of what it will hold. */
  description?: string;
}

/** Features' entry in `settings.areas` (the Features module, `features/`). */
export interface FeaturesSettings {
  /**
   * Repository directory of the catalogue, no trailing '/': one `<id>.md` per feature (direct children only), with
   * `title`, `status`, `summary` and `sources` front matter. A content collection must cover its `*.md` files.
   */
  directory: string;
  /** ISO date the catalogue was last checked against the product. Written only by the area's skill. */
  reviewedAt: string;
  /**
   * Repository directories, or globs of directories such as `libs/features/{a,b}/src`, whose source files a feature's `sources`
   * should claim: Gaps lists the files under them that none does, and nothing fails on them. Tests are left out.
   */
  sourceRoots: readonly string[];
  /**
   * The test files the area inventories and maps to features; or a placeholder where they cannot be listed (on
   * TypeScript 7 alone, whose package has no compiler API): the Tests page shows it, and no feature lists tests.
   */
  tests: FeatureTestsSettings | { placeholder: Placeholder };
  /** Where the coverage summaries are. Omit it and the coverage section is a placeholder saying none is configured. */
  coverage?: FeatureCoverageSettings;
  /** Header and page title. Default 'Features'. */
  title?: string;
  /** One sentence under the title and on About. */
  description?: string;
}

/** `settings.areas.features.tests`: the test files the Features area inventories, and which of them test no feature. */
export interface FeatureTestsSettings {
  /** Repository-relative globs of the test files to inventory: every `*.test.ts` under `libs/`, say. */
  include: readonly string[];
  /**
   * Globs of test files that test tooling, the platform or shared code rather than a feature: the Tests page lists
   * them under Infrastructure, and the check never counts them unassigned. A feature that owns such a file still lists it.
   */
  infrastructure: readonly string[];
  /** Globs of Playwright files that do not import `@playwright/test` themselves (they import a fixtures module). */
  playwright?: readonly string[];
}

/** `settings.areas.features.coverage`: the v8 coverage summaries the Features area reads. */
export interface FeatureCoverageSettings {
  /** Globs of `json-summary` files (`coverage-summary.json`), one per test project; a missing one reads "Not measured". */
  summaries: readonly string[];
}

/** API's entry in `settings.areas` (the API module, `api/`). */
export interface ApiSettings {
  /** Repository path of the OpenAPI 3 document (JSON) the area renders. A content collection must cover it. */
  document: string;
  /**
   * Repository path of the consumer registry (JSON, `ApiRegistry`): which operations the product calls, from which
   * pages, in which groups. Omit it and the area renders the document alone, grouped by tag. A content collection must
   * cover it.
   */
  registry?: string;
  /** ISO date the registry was last checked against the API and its callers. Required with a registry; written only by the area's skill. */
  reviewedAt?: string;
  /**
   * Path prefix of the routes the product calls, e.g. '/api'. A `used` row under it links its path to the running API,
   * and the check fails a `used` GET under it that no fetch site calls. Default '/'.
   */
  basePath?: string;
  /**
   * Files that must equal the output of a command (an emitted document, generated client types): the check runs each
   * `command` (an argv array) at the repository root and fails when its stdout differs from `path`, naming `fix`.
   */
  generated?: readonly ApiGeneratedFile[];
  /**
   * Where the product calls the API: the check scans the source files under `roots` (tests excluded) for
   * `fetch('<basePath>…')` and `<client>.GET|POST|PUT|PATCH|DELETE('<basePath>…')`. A hooks file's `fetchSites`
   * replaces the scan. Without either, the fetched-path rules are skipped.
   */
  callers?: { roots: readonly string[] };
  /** Header and page title. Default 'API'. */
  title?: string;
  /** One sentence under the title and on About. Default names the document and, with a registry, its callers. */
  description?: string;
  /** The paragraph above the tables; `code` in backticks renders as code. Default names the document. */
  intro?: string;
}

/** One `ApiSettings.generated` file. */
export interface ApiGeneratedFile {
  /** Repository path of the generated file. */
  path: string;
  /** The command whose stdout the file must equal, as an argv array run at the repository root. */
  command: readonly string[];
  /** The command to run when it is stale, named in the problem. */
  fix?: string;
}

/**
 * Audit's entry in `settings.areas` (the Audit module, `audit/`). The three markdown files, all required, follow the
 * formats in the kit's `docs/formats.md`, and the `document-repo` skill writes them; the reviews and the specs' front
 * matter are markdown, the feature audit JSON (`check/audit-registries.d.mts`). A content collection must cover each.
 * The parser, the pages, the checks and the skills all read the paths and conventions from here.
 */
export interface AuditSettings {
  /** Repository path of the roadmap (the ROADMAP.md format): the Roadmap page, and what every Milestone line names. */
  roadmap: string;
  /** Repository path of the TODO list (the TODO.md format): the Todo page. */
  todo: string;
  /**
   * Repository path of the architecture document: its Stack summary and Planned migrations make the Architecture page,
   * and the audit check requires its other sections (`docs/formats.md`, "The architecture document").
   */
  architecture: string;
  /** The values a phase's `Kind:` may take. The Roadmap page tones their badges by position. */
  phaseKinds: readonly string[];
  /** The values a TODO entry's `Area:` may take, in the Todo page's filter order. */
  todoAreas: readonly string[];
  /** `Source:` values that are not repository paths: an exact value, or a prefix ending in ':'. Default ['idea']. */
  todoSources?: readonly string[];
  /**
   * The prefix every roadmap and TODO id carries: upper-case letters and digits, starting with a letter. With `ACME` a
   * milestone is `ACME-M1`, a phase `ACME-M1.2`, an Outside the roadmap row `ACME-X3` and a TODO entry `ACME-4`
   * (`docs/formats.md`, "Ids"). The onboarding suggests the initials of the repository's name.
   */
  idPrefix: string;
  /**
   * The folder of the reviews (default `docs/reviews`): `<reviews>/index.md` (the review date, the All markdowns
   * sections and the Documentation list, in its front matter) and one `<reviews>/<reviewed path without .md>.review.md`
   * per reviewed document (`docs/formats.md`, "The spec ledger and reviews"). A content collection must cover
   * every markdown file in the folder, including any dot-directory inside it (`.agents`, for a review of `.agents/`),
   * which Vite's glob wildcards do not enter.
   */
  reviews?: string;
  /**
   * Repository path of the feature audit (JSON, `FeatureAudit`): findings in groups, and optionally the feature
   * inventory. Omit it and the area has no Features page. With it, `todoSources` must list 'feature-audit:'. A content
   * collection must cover it.
   */
  featureAudit?: string;
  /**
   * The directories of specs and plans: the first holds specs, the others plans (their documents' `kind`), read
   * recursively. Each document's state is its own front matter (`state`, `summary`, …); directly in one of these
   * directories it must have front matter and one `**Milestone:**` line; in a subdirectory (`archive/`) it is a row only
   * when it has front matter. A content collection must cover the documents that have a row.
   * Default `['docs/specs', 'docs/plans']`.
   */
  specDirs?: readonly string[];
  /** Path prefixes of tracked markdown that is not the repository's own (agent worktrees, say): no review is needed. Default none. */
  ignore?: readonly string[];
  /** Path prefixes whose markdown links are not checked (a fixture that links to a missing page on purpose). Default none. */
  linkExempt?: readonly string[];
  /** The feature audit's dead-code sweep (`check/unused-exports.mjs`). Default: everything under `src`. */
  unusedExports?: UnusedExportsSettings;
  /** Header and page title. Default 'Audit'. */
  title?: string;
  /**
   * One sentence under the title and on About. Default: where the repository stands, naming the spec ledger and, when
   * configured, the implementation picture and the key documents.
   */
  description?: string;
}

/** `AuditSettings.unusedExports`: where the dead-code sweep looks. */
export interface UnusedExportsSettings {
  /** Repository directories whose source files are swept. Default `['src']`. */
  roots?: readonly string[];
  /** Globs of entry files nothing imports (app entries, tool configs): never orphans. Default the kit's list; a list replaces it whole. */
  entries?: readonly string[];
  /**
   * Paths not reported, though their files still count as users: a directory (`lib/`, a library whose exports are its
   * public API) or a file (one a tool loads by a name no config states, or whose exports are kept on purpose).
   */
  ignore?: readonly string[];
}
