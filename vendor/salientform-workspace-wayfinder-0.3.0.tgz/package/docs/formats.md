# Wayfinder formats

The formats the Audit area reads and the checks enforce: the roadmap, the TODO list, the architecture document's two
sections, the Milestone line on specs and plans, the spec ledger and reviews, and the document set the
`document-repo` skill writes, with its placeholders; and how the skills build the registries. A repository adopting Wayfinder
adopts these. The paths are settings (`settings.areas.audit`: `roadmap`, `todo`, `architecture`, `reviews`, `specDirs`). The house
vocabularies are settings too: `phaseKinds` for a phase's `Kind`, `todoAreas` for a TODO's `Area`, and `todoSources`
for the `Source` values that are not paths; so is `idPrefix`, the prefix every id carries.

The roadmap, the TODO list and the architecture document are required: every repository keeps all three, and the
`document-repo` skill writes them from what the repository already says (one with nothing to say yet holds a
placeholder, "The document set" below). `roadmap`, `todo`, `architecture`, `phaseKinds`, `todoAreas` and `idPrefix`
must all be set; the workspace fails at load without one. The spec ledger and reviews are always there too. This file is the normative description. The parser is
`check/audit-markdown.mjs`, and the rules are the headers of `check/audit-implementation.mjs` and
`check/audit-ledger.mjs`.

Every date is `YYYY-MM-DD`. A "Reviewed" or "last modified" date follows one rule: it must be a valid date and not
after today. It records the day the change was made, written by whoever made it, and is never derived from git.

## Ids

Every id starts with the repository's prefix (`idPrefix`) and a hyphen, so an id names its repository wherever it is
quoted: in another repository's documents, a commit, a branch, a chat. The prefix is upper-case letters and digits,
starting with a letter; the onboarding suggests the initials of the repository's name (`workspace-wayfinder` → `WW`,
`acme-billing-api` → `ABA`; a one-word name, its first three letters). With the prefix `ACME`:

| Id | Is | Example |
| --- | --- | --- |
| `<P>-M<n>` | a milestone: one outcome | `ACME-M4` |
| `<P>-M<n>.<k>` | a phase: an independently shippable step towards its milestone | `ACME-M4.2` |
| `<P>-X<n>` | a spec or plan that aligns with no milestone (Outside the roadmap) | `ACME-X7` |
| `<P>-<n>` | a TODO entry | `ACME-12` |

An id is written whole wherever it is named, in the structures below and in prose; the parser and the checks refuse an
id without the prefix or with another. The prefix is chosen once: changing it rewrites every id in the repository's
markdown in one change. No id is ever reused. A milestone or phase that is merged or dropped is listed on the roadmap's "Retired numbers"
line.

## The roadmap

```markdown
# Roadmap

Reviewed: 2026-11-18

<intro: the order is a forecast, not a commitment; the vocabulary>

Retired numbers (never reused): ACME-M7 — merged into ACME-M4 on 2026-01-01.

## Sequence

1. ACME-M2.4
2. ACME-M4.2

## ACME-M2. API rebuild

<one outcome paragraph>

### ACME-M2.4 Release versioning

- **Status:** not started
- **Kind:** migration
- **Goal:** …
- **Not in scope:** …
- **Depends on:** ACME-M2.1
- **Spec:** —
- **Plan:** —

<optional free text>

## Completed

| ID | Title | Shipped | Spec / plan |
| --- | --- | --- | --- |
| ACME-M2.1 | Framework swap | 2026-01-01 | docs/specs/2026-01-01-framework-swap-design.md |

## Outside the roadmap

Next X: 3

| ID | Title | Spec | Plan |
| --- | --- | --- | --- |
| ACME-X1 | Engineering workspace | docs/specs/… | docs/plans/… |
```

**Header and sections.**
- A `Reviewed:` line comes before the first section.
- The only sections are `Sequence`, the milestones (`## <P>-M<n>. Title`), `Completed` and `Outside the roadmap`.

**An empty roadmap.** A roadmap with no open milestone has a placeholder under `Sequence` instead of a list, saying
that no planned work was found and what would add the first phase:

```markdown
## Sequence

> **Not generated yet.** No planned work was found in this repository: no open spec or plan, and no list of planned work in its README or docs.
> **To fill:** write a spec for the next piece of work; its phase replaces this placeholder.
```

The check fails a roadmap with no open milestone and no such placeholder, and a placeholder beside a Sequence that
lists phases.

**Milestones.**
- A milestone is followed by its outcome paragraph and its open phases (`### <P>-M<n>.<k> Title`).
- A milestone with no open phase is deleted: when its last phase ships or is dropped, its heading and paragraph go.

**Phase fields.** Each phase has these bullets, in this order:

| Field | Value |
| --- | --- |
| `Status` | `not started`, `specified`, `planned` or `in progress` |
| `Kind` | one of `phaseKinds` |
| `Goal` | required |
| `Not in scope` | optional |
| `Depends on` | a comma-separated list of phase ids and free-text conditions, or `—` |
| `Spec` | a repository path, or `—` |
| `Plan` | a repository path; several, comma-separated, in the order they run, the first being the current one; or `—` |

**The status follows the documents:**
- `not started`: no spec, no plan;
- `specified`: a spec and no plan;
- `planned` and `in progress`: both.

A named spec or plan must exist and be an active row of the ledger (`draft`, `under-review` or `blocked`).

**Sequence.** A numbered list of every open phase, exactly once each, in likely order. No completed id appears in it.

**Completed.** A table with four cells per row, and a `Shipped` date; the Spec / plan cell names a path that exists, or
is `—` where the repository deletes its specs and plans once built. When a phase ships, its section is deleted and
a row is added here.

**Outside the roadmap.**
- A `Next X: <n>` line, greater than every X id below it, then a four-cell table.
- To add a row, allocate `<P>-X<Next X>` and bump the counter.
- A row's Spec and Plan are exactly the ledger rows carrying its id.

## The TODO list

```markdown
# TODO

Reviewed: 2026-11-18
Next ID: 13

<intro: what belongs here, how to act on an entry>

## ACME-12 Notification bell never shows a count

- **Area:** app
- **Source:** idea
- **Added:** 2026-01-01

<free markdown, may be empty>
```

**Ids.** Each entry is `## <P>-<n> Title`.
- The numbers are positive integers, unique and never reused.
- `Next ID` is greater than every number in the file.
- To add an entry, take `Next ID` and bump it.

**Fields.**
- `Area` is one of `todoAreas`.
- `Source` is a repository path that exists, or one of `todoSources` (an exact value, or a prefix ending in `:` such
  as `feature-audit:`).
- `Added` is a date.

**Lifecycle.**
- An entry lives only while the work is unplanned. Planning or finishing it deletes the entry; the spec, phase or
  commit carries it from there.
- File order is priority, highest first.
- A list with no entry may hold a placeholder after its intro, saying where a TODO list was looked for. The first entry
  replaces it: the check fails a placeholder beside an entry.

## The architecture document

Six sections, in this order, among any others the repository keeps. A leading `<n>. ` on a heading is allowed
(`## 3. Stack summary`), so a section can be cited as `§<n>`.

| Section | Holds |
| --- | --- |
| `## Overview` | what the product is and who uses it, one paragraph |
| `## Repository layout` | each top-level directory and package, one line each |
| `## Stack summary` | below |
| `## Running it` | the commands that start, test and build it, with their ports, one line each |
| `## Deployment` | where it is deployed or published, and what deploys it |
| `## Planned migrations` | below |

Overview, Repository layout, Running it and Deployment must exist and hold something: text, a table, or a placeholder
where the repository has nothing for the section yet. The check fails on a missing or empty one.

**`## Stack summary`.** One `### <Area>` heading per area. Under each, a table:

```markdown
| Item | Status | Note | Ref |
| --- | --- | --- | --- |
| Vite 7 | current | | §8 |
| Kysely | planned | | ACME-M2.5 |
```

- `Status` is `current` or `planned`.
- `Ref` is one of:
  - a section of the same file (`§<n>`);
  - a roadmap phase or milestone id;
  - a repository path that exists;
  - empty.
- A `planned` row's phase must be open.

**`## Planned migrations`.** One bullet per open phase that changes the architecture:
`- **ACME-M2.4 Release versioning** — [ROADMAP.md](ROADMAP.md#acme-m24-release-versioning)`. Its id must be on the roadmap.

The document also has a `Reviewed:` line under its title.

## The Milestone line

Every document directly in one of `specDirs` (default `docs/specs` and `docs/plans`; an `archive/` below them is
exempt) has exactly one `**Milestone:** <id>` line before its first `## ` heading.

**What the id can be:**
- an open or completed phase;
- an `X` id from Outside the roadmap;
- for a row already closed (`implemented` or `superseded`), a milestone.

**How the document and the ledger agree:**
- An active row's phase names the document as its Spec or one of its Plans. Every plan a phase names is active: a
  finished plan leaves the list.
- A plan carries its spec's id. When its spec spans several phases of one milestone, it may carry the phase it
  implements instead (`ACME-M4.2` under an `ACME-M4.1` spec).

## The spec ledger and reviews

The ledger is markdown: no JSON registry, no generated index. Each spec's and plan's state is its own front matter,
and every tracked markdown file, specs and plans included, has a review file under `reviews` (a spec's review holds
what its front matter does not: what is stale, what is still to come and where it is tracked); `reviews/index.md`
holds the rest. They read and diff like the
documents they describe. CommonMark with YAML front matter and nothing else: no tool-specific syntax, no reader beyond
the kit is required; GitHub, an editor or Obsidian show them correctly.

**A spec or plan.** Every document in `specDirs` (the first holds specs, the others plans; read recursively, and a
document in a subdirectory, an `archive/` for instance, is a row only if it has front matter) opens with front matter
before its `# ` heading:

```markdown
---
state: draft
summary: >
  One paragraph: what the document decides or delivers.
followUps:
  - A later idea it names
evidence: Branch feat/… (2026-11-03), what proves it.
spec: docs/specs/2026-10-21-example-design.md   # plans only
blockedOn: What must land first   # when state is blocked
---

# Title

**Milestone:** ACME-M12.11
```

`state` and `summary` are required; `followUps`, `evidence`, `spec`, `blockedOn` are as the state calls for. A
document's title is its first `# ` heading, its kind its directory, its milestone its `**Milestone:**` line
(`milestone` is never front matter). `spec` is its spec's path, equal to the path on any body `**Spec:**` line.
`state` is one of `draft`, `under-review` or `blocked` (active); `implemented` or `superseded` (closed); `conflicting`.
A plan's `spec` is what links its card to the spec's card.

A value with `: `, `#`, a brace or a bracket is quoted (`'…'`), as YAML requires: a `{a,b}` glob, `#3`, a sentence with
a colon. Inside a one-line flow collection (`{ id: x, title: y }`, `[a, b]`) a comma ends the value too, so a value
there with a comma is quoted; block style, one key per line, avoids that, and is what the kit's templates use. A front
matter block that does not parse, or a flow entry split by a comma into an unknown key, stops the workspace from
loading, naming the file and the line or the key.

**A review**, one per reviewed markdown file, at `<reviews>/<path without .md>.review.md`, or per directory
`<dir>/`, at `<reviews>/<dir>/_directory.review.md` (a file name holds no `/`, so the path is the directories):

```markdown
---
path: docs/ARCHITECTURE.md
kind: documentation
lastModified: 2026-11-02
verdict: current
tracked: [ACME-M2.4, ACME-M3.3]
ref: docs/ROADMAP.md §ACME-M12
---

## Stale content

What is out of date and how that was verified.

## Future content

Future work, TODOs, roadmap items or open follow-ups the document carries.

## Recommendation

One imperative sentence.
```

A directory review's `path` is the directory with a trailing `/`, and its `lastModified` is the newest of its files':
`<reviews>/.agents/skills/_directory.review.md` holds

```markdown
---
path: .agents/skills/
kind: config
lastModified: 2026-11-02
verdict: current
---

## Recommendation

Change the skills only through the kit's installer.
```

A section's text is markdown, read as one paragraph (its line breaks fold to spaces) and rendered inline on the All
markdowns page: code spans, emphasis and links show as such, and raw HTML stays text.

`path`, `kind`, `lastModified`, `verdict` and `## Recommendation` are required; the others appear only when they have
text. `path` must equal the file's own name under the rule above; `kind` is an `id` from the index's `kinds`, the All
markdowns section the review sits in. With the onboarding template's kinds: `spec` and `plan` for the documents in
`specDirs` (the first directory specs, the others plans), `config` for agent and tooling configuration (a skills
directory, `CLAUDE.md` or `AGENTS.md`, a tool's settings), and `documentation` for every other markdown file. A
repository adds a kind to the index deliberately. A
`## Future content` needs `tracked` and the other way round: `<P>-<n>` (the TODO list), a phase,
milestone or X id (the roadmap), or a spec or plan path. Every token must resolve. A review's `lastModified` follows the date rule; its
`verdict` is one of `current`, `partially-stale`, `stale`, `superseded`, `done`, `conflicting` or `wrong`.

Every markdown file `git ls-files` lists has a review, except paths under `ignore`, the review files and `index.md`.

**The index**, `<reviews>/index.md`:

```markdown
---
reviewedAt: 2026-11-03
kinds:
  - id: documentation
    label: Documentation
  - id: spec
    label: Specs
documents:
  - id: architecture
    title: Architecture (full document)
    path: docs/ARCHITECTURE.md
    description: Layering, boundaries, build and deploy.
---

# Reviews

What this folder is, for a reader who opens it.
```

`reviewedAt` is the date of the last review of anything in the folder. `kinds` are the All markdowns page's sections,
in page order. `documents` is the Documentation section, in nav order (`id` lowercase kebab, `anchor` optional); omit
it and the area has no Documentation section. A content collection must cover the folder.

The types are in `check/audit-registries.d.mts`.

**Links.** Every relative link in tracked markdown resolves, except under `linkExempt` and in the reviews folder, whose
files are not read as pages.

## The document set

Eight documents, written by the `document-repo` skill and checked by its `check-documents.mjs` (the rules are
`check/documents.mjs`). They live in `docs/`, except that the roadmap, the TODO list and the architecture document are
wherever `areas.audit` names them. The set needs no workspace config.

| File | Holds |
| --- | --- |
| `ABOUT.md` | what the repository is, who it is for, its state, and where each other document is |
| `SKILLS.md` | the agent skills the repository keeps |
| `ARCHITECTURE.md` | overview, layout, stack summary, running it, deployment, planned migrations (its six sections above) |
| `ROADMAP.md` | the roadmap, above |
| `FEATURES.md` | what the product does, one `## ` section per feature; with the Features area, a table of its catalogue's files |
| `TODO.md` | the TODO list, above |
| `SETUP.md` | requirements, install, configure, run, test, build, release |
| `ISSUES.md` | known problems and limits, one `## ` section each with `Area`, `Found`, `Workaround` and `Fix` |

**Every document** opens with a `# ` title and has a `Reviewed:` line before its first `## ` section, following the
date rule.

**A placeholder** stands where the repository has nothing for a document or a section yet. It is one blockquote of two
labelled lines, plain CommonMark, so any markdown reader shows it:

```markdown
> **Not generated yet.** No deployment configuration was found in this repository.
> **To fill:** add the deployment (a CI workflow or a platform file), then run `document-repo`.
```

- The reason follows `> **Not generated yet.**` and the remedy follows `> **To fill:**`, on the next line; neither is
  empty.
- A **placeholder file** is a title, a `Reviewed:` line, any intro, and exactly one placeholder, with no `## ` section.
- A placeholder never stands beside real content for the same section.
- The check prints each placeholder after its OK line and does not fail on one; with `--strict` it does.
- A placeholder inside a fenced code block is an example of the format, and is not read as one.

**An area or a section of one** that cannot be generated yet has the same two fields in the workspace config,
`{ reason, toFill }`: an area's settings `{ placeholder: { reason, toFill } }` (Features, API and Platform
Docs; Readme, Audit and About are always generated), and the Features area's `tests: { placeholder }`. The kit states two itself: the Features area's coverage without `coverage` settings, and
Audit's Features page without a feature audit. Each is shown where the area or section would be, and each check prints
the ones it owns after its OK line (`placeholder: <where> — <reason> To fill: <toFill>`), failing on them only with
`--strict`. About's Placeholders page lists them all, then the document set's. The About check fails while one of
the six areas is missing from `areas`: one the repository cannot support yet is written as a placeholder, never
left out.

**A Platform Docs page** may hold a placeholder too: one the `assess-platform-docs` skill drafted opens with one,
under its front matter, until a person has read it against the product. The Platform Docs check prints it after its
OK line, About's Placeholders page lists it under the area, linked to the page, and a malformed one fails the check.

**`SKILLS.md`** lists skills in tables whose first cell is the skill's name in backticks:

```markdown
## Repository skills

| Skill | What it does | Path |
| --- | --- | --- |
| `release-notes` | Drafts the release notes from the merged pull requests. | `.agents/skills/release-notes` |

## Wayfinder skills collection

| Skill | What it does | Repository rules |
| --- | --- | --- |
| `todo` | Adds, plans and drops entries in the TODO list. | [REPOSITORY.md](../.agents/skills/todo/REPOSITORY.md) |
```

- **Repository skills** are exactly the skills the repository keeps of its own, found in the skills directory
  (`areas.about.skillsDir`), each `skillLinks` directory, `.agents/skills`, `.claude/skills` and `.opencode/skills`.
- **Wayfinder skills collection** is exactly the kit's skills installed there (a directory with a kit skill's name),
  each row's last cell linking the skill's `REPOSITORY.md` where the repository has written one, and `—` where not.
  In the kit's own repository, whose `skills/` is the collection's source, those are the repository's own skills and
  this section is absent.
- Neither lists a skill named in the root `skills-lock.json` (a vendor's) or one whose directory resolves outside the
  repository (the user's or a plugin's).
- A section whose list would be empty may be left out, or hold a placeholder. With no skill at all, the document is
  a placeholder file.

## Registries built by the skills

No registry, detailed setting or About manifest is written by hand or copied from another repository. Each area's
skill builds its own on its first run, from the repository, and keeps it after. Every skill that owns an area's
settings has a `scripts/propose.mjs` (the rules are `check/propose.mjs` and the `check/propose-*.mjs` beside it): it
reads the repository's files and its test runners' configs as text, never running them and never asking the network,
and prints a table of what a script can derive without judgement, with where it read each value:

```text
features proposals — 3 test runners, 78 test files, 1 source roots

| Setting | Proposed | From |
| --- | --- | --- |
| `areas.features.tests.include` | `["src/**/*.test.ts"]` | vite.config.ts |

judged: areas.features.tests.infrastructure — the tests of tooling, the platform and shared code, which no feature owns
would write: workspace/src/product-routes.json — the route mirror: 2 routes (run with --write)
```

Two runs on the same repository print the same. `--json` prints the proposal as JSON. The skill writes the settings
into the workspace config (no script edits it), opens its `REPOSITORY.md` with the table, and records below it what
it judged and why. `--write` writes the files a script can make:

| File | Made by | How |
| --- | --- | --- |
| the About manifest (`areas.about.manifest`) | `assess-workspace` | **built** whole from the config and the installed skills; the About check fails while it differs from a fresh build |
| the route mirror (`productRoutes`) | `assess-features` | **built** from the hooks file's `productRoutes` hook; the Features check fails while it differs from the router |
| the API consumer registry (`areas.api.registry`) | `assess-api` | **drafted**: `method`, `path`, `example`, `handler`, `consumer` and `status` derived, the rest a first value the skill rewrites; a later run keeps the judged fields and recomputes the others |
| the feature audit (`areas.audit.featureAudit`) | `assess-feature-audit` | **drafted** when there is none: one `dead-code` finding per file the dead-code sweep reports; with one, the run lists what is new and what is gone |

A first run writes afresh: an existing registry, About manifest, feature page or review is the kit's output and is
neither kept nor read. The repository's own records (a roadmap, a TODO list, an architecture document, a setup guide,
a list of issues) are sources, and the `document-repo` skill reads them into the document set.
