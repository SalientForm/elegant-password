/**
 * The About manifest, built whole (spec WW-M1 §5: `assess-workspace` generates it from the configured areas and their
 * registries, and regenerates it when either changes), and the `content` collections that cover every file an area
 * reads. The About check compares the manifest with a fresh build; `assess-workspace`'s propose.mjs writes it.
 *
 * The build assumes the onboarding's layout: the manifest beside the app's `audit.ts` and `features.ts`, which create
 * the two areas it reads for counts, and the app's `vite.config.ts` one directory up.
 */
import { readdirSync } from 'node:fs';
import path from 'node:path';
import { globMatcher } from './features.mjs';
import { kitSkillNames } from './install-skills.mjs';
import { fixtureRoots, underAny } from './propose-audit.mjs';
import { readText, unique } from './repo-files.mjs';
import { ABOUT_DEFAULTS, aboutSettings, isPlaceholderArea } from './settings-defaults.mjs';

/** The kit's skills in the order ABOUT_SKILLS lists them: by the first area, in header order, each maintains. */
export const KIT_SKILL_ORDER = [
  'assess-audit',
  'todo',
  'assess-feature-audit',
  'assess-features',
  'assess-api',
  'assess-platform-docs',
  'assess-workspace',
  'document-repo',
  'wayfinder-onboard',
];

/** A TypeScript string literal: single-quoted, or double-quoted when the text holds a single quote. */
const str = (text) => (text.includes("'") ? JSON.stringify(text) : `'${text.replace(/\\/g, '\\\\')}'`);

/** An import path from `fromDir` to `file`, without leaving a `.ts`/`.tsx` extension (`./audit`). */
function importPath(fromDir, file) {
  const rel = path.posix.relative(fromDir, file).replace(/\.tsx?$/, '');
  return rel.startsWith('.') ? rel : `./${rel}`;
}

/** The `.mjs` scripts in `<skillsDir>/<name>/scripts`, sorted, repository-relative; none when the directory is missing. */
function skillScripts(root, skillsDir, name) {
  try {
    return readdirSync(path.join(root, skillsDir, name, 'scripts'))
      .filter((f) => f.endsWith('.mjs') && !f.endsWith('.spec.mjs'))
      .sort()
      .map((f) => `${skillsDir}/${name}/scripts/${f}`);
  } catch {
    return [];
  }
}

/**
 * ABOUT_SKILLS: the kit's skills (KIT_SKILL_ORDER, then any the kit adds), each with every script it ships, then each
 * other skill the check script runs from the skills directory, in the order it runs them.
 */
export function manifestSkills({ root, settings, packageJson }) {
  const { skillsDir, checkScript } = aboutSettings(settings.areas.about);
  const kit = kitSkillNames();
  const names = [...KIT_SKILL_ORDER.filter((n) => kit.includes(n)), ...kit.filter((n) => !KIT_SKILL_ORDER.includes(n)).sort()];
  const command = packageJson?.scripts?.[checkScript] ?? '';
  const escaped = skillsDir.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const others = unique([...command.matchAll(new RegExp(`${escaped}/([^/\\s]+)/scripts/`, 'g'))].map((m) => m[1])).filter((n) => !names.includes(n));
  return [...names, ...others].map((name) => ({ name, scripts: skillScripts(root, skillsDir, name) }));
}

const row = (fields) =>
  `{ ${Object.entries(fields)
    .filter(([, v]) => v !== undefined)
    .map(([k, v]) => `${k}: ${v}`)
    .join(', ')} }`;

/**
 * The manifest's source. `settings` is the workspace config, `configFile` its path (the root package.json
 * `wayfinder.config`), `skills` ABOUT_SKILLS (`manifestSkills`), `reviewedAt` ABOUT_REVIEWED_AT, and `exists(file)`
 * says whether a repository file exists (the app's Vite config, named by the generated modules' rows).
 */
export function aboutManifestSource({ settings, configFile, skills, reviewedAt, exists = () => true }) {
  const manifest = settings.areas.about.manifest;
  const appDir = path.posix.dirname(manifest);
  const viteConfig = path.posix.join(path.posix.dirname(appDir), 'vite.config.ts');
  const generated = (slug) => settings.areas[slug] !== undefined && !isPlaceholderArea(settings.areas[slug], `settings.areas.${slug}`);
  const uses = { settings: false, features: false, kit: new Set(), types: new Set(['AboutManifest', 'AboutSkill']) };
  const config = str(configFile);
  const areas = {};

  // Readme: the collection it renders.
  const readme = settings.areas.readme;
  if (readme) {
    const collection = readme.collection ?? 'readmes';
    uses.kit.add('listCollection');
    areas.readme = [
      row({ name: str(collection), file: config, source: "'config'", holds: str(`the content collection of READMEs the area renders (areas.readme.collection)`), count: `listCollection(${str(collection)}).length` }),
    ];
  }

  // Audit: the three documents and the reviews, always; the feature audit when there is one.
  const audit = settings.areas.audit;
  const reviews = audit.reviews ?? 'docs/reviews';
  const parts = ['implementation', 'ledger'];
  areas.audit = [
    row({ name: str(path.posix.basename(audit.roadmap)), file: str(audit.roadmap), source: "'markdown'", holds: str('milestones, phases and their sequence'), owner: "'assess-audit'", count: 'implementation.openPhases.length', date: "{ name: 'Reviewed:', value: implementation.roadmap.reviewedAt }" }),
    row({ name: str(path.posix.basename(audit.todo)), file: str(audit.todo), source: "'markdown'", holds: str('small unplanned items'), owner: "'todo'", count: 'implementation.todos.todos.length', date: "{ name: 'Reviewed:', value: implementation.todos.reviewedAt }" }),
    row({ name: str(path.posix.basename(audit.architecture)), file: str(audit.architecture), source: "'markdown'", holds: str('the stack summary and the planned migrations'), owner: "'assess-audit'", count: 'implementation.stack.items.length', date: "{ name: 'Reviewed:', value: implementation.stack.reviewedAt }" }),
    row({ name: "'reviews'", file: str(`${reviews}/index.md`), source: "'markdown'", holds: str('a review per markdown file; the index holds the date, the All markdowns sections and the Documentation list'), owner: "'assess-audit'", count: 'ledger.docReviews.length', date: "{ name: 'reviewedAt', value: ledger.reviewedAt }" }),
  ];
  if (audit.featureAudit) {
    parts.push('featureAudit');
    areas.audit.push(
      row({ name: str(path.posix.basename(audit.featureAudit)), file: str(audit.featureAudit), source: "'json'", holds: str('the feature audit: dead code, unreachable pages, stale TODOs and recommendations, by group'), owner: "'assess-feature-audit'", count: 'featureAudit?.findings.length ?? 0', date: "{ name: 'reviewedAt', value: featureAudit?.reviewedAt ?? '' }" }),
    );
  }

  // Features: the catalogue, the route mirror and the three modules the Vite plugins generate.
  if (generated('features')) {
    const features = settings.areas.features;
    uses.features = true;
    const date = "{ name: 'areas.features.reviewedAt', value: FEATURES.reviewedAt }";
    areas.features = [
      row({ name: str(features.directory), file: config, source: "'markdown'", holds: str('the feature catalogue (areas.features.directory): one markdown file per feature, the routes it owns, the sources it claims and any extra test globs'), owner: "'assess-features'", count: 'FEATURES.features.length', date }),
    ];
    if (settings.productRoutes) {
      areas.features.push(
        row({ name: str(`${path.posix.basename(settings.productRoutes)} routes`), file: str(settings.productRoutes), source: "'json'", holds: str("a mirror of the product's routes (productRoutes), equal to its router; each belongs to one feature"), owner: "'assess-features'", count: 'FEATURES.productRoutes.routes.length', date }),
        row({ name: str(`${path.posix.basename(settings.productRoutes)} sidebar`), file: str(settings.productRoutes), source: "'json'", holds: str("a mirror of the product's sidebar paths"), owner: "'assess-features'", count: 'FEATURES.productRoutes.sidebar?.length ?? 0', date }),
      );
    }
    if (exists(viteConfig)) {
      const vite = str(viteConfig);
      areas.features.push(row({ name: "'virtual:workspace-feature-sources'", file: vite, source: "'generated'", holds: str("the files the catalogue's globs can match, walked at build time from areas.features.sourceRoots and each feature's sources"), count: 'FEATURES.sourceScan.files.length' }));
      if (!features.tests?.placeholder)
        areas.features.push(row({ name: "'virtual:workspace-test-inventory'", file: vite, source: "'generated'", holds: str('every test file areas.features.tests.include matches, parsed at build time and mapped to features'), count: 'FEATURES.testInventory.files.length' }));
      if (features.coverage)
        areas.features.push(row({ name: "'virtual:workspace-feature-coverage'", file: vite, source: "'generated'", holds: str('the coverage summaries areas.features.coverage.summaries finds, summed per feature'), count: 'FEATURES.coverage?.summaries.length ?? 0' }));
    }
  }

  // API: the OpenAPI document and the consumer registry.
  if (generated('api')) {
    const api = settings.areas.api;
    uses.kit.add('readJsonDoc');
    uses.kit.add('documentOperations');
    areas.api = [
      row({ name: str(path.posix.basename(api.document)), file: str(api.document), source: "'json'", holds: str('the OpenAPI document: every route, with its request and response shapes'), count: `documentOperations(readJsonDoc(${str(api.document)})).length` }),
    ];
    if (api.registry) {
      uses.settings = true;
      uses.types.add('ApiRegistry');
      areas.api.push(
        row({ name: str(path.posix.basename(api.registry)), file: str(api.registry), source: "'json'", holds: str('the consumer registry: which product code calls each route, from which pages, and whether it is used'), owner: "'assess-api'", count: `readJsonDoc<ApiRegistry>(${str(api.registry)}).endpoints.length`, date: "{ name: 'areas.api.reviewedAt', value: settings.areas.api.reviewedAt }" }),
      );
    }
  }

  // Platform Docs: the directory of pages.
  if (generated('platform-docs')) {
    const docs = settings.areas['platform-docs'];
    uses.settings = true;
    uses.kit.add('platformDocPaths');
    areas['platform-docs'] = [
      row({ name: str(docs.directory), file: config, source: "'markdown'", holds: str("the Platform Docs pages (areas['platform-docs'].directory): one per markdown file, built from its front matter"), owner: "'assess-platform-docs'", count: `platformDocPaths(${str(docs.directory)}).length`, date: `{ name: ${str("areas['platform-docs'].reviewedAt")}, value: settings.areas['platform-docs'].reviewedAt }` }),
    ];
  }

  const imports = [
    `import {\n${[...[...uses.kit].sort(), ...[...uses.types].sort().map((t) => `type ${t}`)].map((n) => `  ${n},`).join('\n')}\n} from '@salientform/workspace-wayfinder';`,
  ];
  if (uses.settings) imports.push(`import settings from '${importPath(appDir, configFile)}';`);
  imports.push(`// The areas the manifest reads for counts and dates, each from its own module (no import cycle: workspace.tsx imports\n// the manifest).`);
  imports.push(`import { AUDIT_AREA } from '${importPath(appDir, `${appDir}/audit`)}';`);
  if (uses.features) imports.push(`import { FEATURES_AREA } from '${importPath(appDir, `${appDir}/features`)}';`);

  const consts = [`const { ${parts.join(', ')} } = AUDIT_AREA.module;`];
  if (uses.features) consts.push('const FEATURES = FEATURES_AREA.module;');

  const skillLines = skills.map((s) => `  { name: ${str(s.name)}, scripts: [${s.scripts.map(str).join(', ')}] },`);
  const slugs = Object.keys(settings.areas);
  const areaLines = slugs.map((slug) => {
    const key = /^[a-z]\w*$/i.test(slug) ? slug : str(slug);
    const rows = areas[slug] ?? [];
    if (rows.length === 0) {
      const why = settings.areas[slug]?.placeholder ? ' // A placeholder: no registry until it is filled.' : '';
      return `    ${key}: { registries: [], models: [] },${why}`;
    }
    return `    ${key}: {\n      registries: [\n${rows.map((r) => `        ${r},`).join('\n')}\n      ],\n      models: [],\n    },`;
  });

  return `/**
 * The About manifest of ${settings.product}: each area's registries, the workspace skills and the review date. Built by
 * the assess-workspace skill from the workspace config and the installed skills (${aboutSettings(settings.areas.about).skillsDir}/assess-workspace/scripts/propose.mjs
 * --write), never edited by hand: the About check fails when it differs from a fresh build.
 */
${imports.join('\n')}

${consts.join('\n')}

/** Set by the assess-workspace skill when the manifest changes. */
export const ABOUT_REVIEWED_AT = '${reviewedAt}';

/** Workspace skills, ordered by the first area (header order) they maintain. */
export const ABOUT_SKILLS: AboutSkill[] = [
${skillLines.join('\n')}
];

export const ABOUT_MANIFEST: AboutManifest = {
  reviewedAt: ABOUT_REVIEWED_AT,
  skills: ABOUT_SKILLS,
  areas: {
${areaLines.join('\n')}
  },
};
`;
}

/** The manifest's own ABOUT_REVIEWED_AT, or undefined. */
export const manifestDate = (source) => /export const ABOUT_REVIEWED_AT = '(\d{4}-\d{2}-\d{2})'/.exec(source ?? '')?.[1];

/**
 * The manifest a fresh build gives for the repository at `root`: `{ file, text, current }`, `text` dated as the current
 * file is (today when it has no date, or when the build differs from it apart from the date).
 */
export function buildAboutManifest({ root, settings, packageJson, today }) {
  const file = settings.areas.about.manifest;
  const current = readText(root, file);
  const configFile = packageJson?.wayfinder?.config;
  const skills = manifestSkills({ root, settings, packageJson });
  const exists = (f) => readText(root, f) !== undefined;
  const build = (reviewedAt) => aboutManifestSource({ settings, configFile, skills, reviewedAt, exists });
  const dated = manifestDate(current);
  const same = dated !== undefined && build(dated) === current;
  return { file, text: same ? current : build(today), current, same };
}

/**
 * The `content` collections that cover every file the areas read: `ctx` is `{ files, settings }`. The README
 * collection the Readme area names; `markdown`, every other tracked markdown file the audit reviews (one `<dir>/*.md`
 * per directory, `**` for the spec directories, the root's, the About prose and Platform Docs directories always, so a
 * file added there later is covered); `skills`, the kit skills' files; `reviews`, the reviews folder and each
 * dot-directory in it by name (a glob enters a dot-directory only where its pattern names one); `features` (the
 * catalogue and the route mirror), `api`, `audit` (the feature audit) and `sources`, the areas' own files.
 */
export function proposeContent({ files, settings }) {
  const areas = settings.areas;
  const audit = areas.audit;
  const reviews = audit.reviews ?? 'docs/reviews';
  const { skillsDir, prose, manifest } = { ...ABOUT_DEFAULTS, ...areas.about };
  const generated = (slug) => areas[slug] !== undefined && !areas[slug].placeholder;
  const content = {};

  const sections = areas.readme?.sections ?? [];
  const collection = areas.readme?.collection ?? 'readmes';
  content[collection] = ['README.md', ...sections.map((s) => `${s.prefix.replace(/\/?$/, '/')}**/README.md`)];

  const specDirs = audit.specDirs ?? ['docs/specs', 'docs/plans'];
  const features = generated('features') ? areas.features.directory : undefined;
  const platform = generated('platform-docs') ? areas['platform-docs'].directory : undefined;
  const skip = [...(audit.ignore ?? []), ...fixtureRoots(files), `${reviews}/`, `${skillsDir}/`, 'node_modules/', ...(features ? [`${features}/`] : [])];
  const readmes = content[collection].map(globMatcher);
  const markdown = files.filter((f) => f.endsWith('.md') && !underAny(f, skip) && !readmes.some((m) => m(f)));
  const fixed = ['*.md', ...specDirs.map((d) => `${d}/**/*.md`), `${prose}/*.md`, ...(platform ? [`${platform}/*.md`] : [])];
  const fixedMatch = fixed.map(globMatcher);
  const dirs = unique(markdown.filter((f) => !fixedMatch.some((m) => m(f))).map((f) => path.posix.dirname(f)));
  const patterns = unique([...dirs.map((d) => (d === '.' ? '*.md' : `${d}/*.md`)), ...fixed]);
  content.markdown = [...patterns.filter((p) => p === '*.md'), ...patterns.filter((p) => p !== '*.md').sort()];

  const kitSkills = `{assess-*,document-repo,todo,wayfinder-onboard}`;
  content.skills = [`${skillsDir}/${kitSkills}/SKILL.md`, `${skillsDir}/${kitSkills}/scripts/*.mjs`, `${skillsDir}/${kitSkills}/REPOSITORY.md`, 'package.json'];

  const dotDirs = unique(
    [...files.filter((f) => f.startsWith(`${reviews}/`)).map((f) => f.slice(reviews.length + 1)), `${skillsDir}/_directory.review.md`]
      .map((rest) => {
        const segments = rest.split('/');
        const at = segments.slice(0, -1).findIndex((s) => s.startsWith('.'));
        return at === -1 ? undefined : segments.slice(0, at + 1).join('/');
      })
      .filter(Boolean),
  ).sort();
  content.reviews = [`${reviews}/**/*.md`, ...dotDirs.map((d) => `${reviews}/${d}/**/*.md`)];

  if (features) content.features = [`${features}/*.md`, ...(settings.productRoutes ? [settings.productRoutes] : [])];
  if (generated('api')) content.api = [areas.api.document, ...(areas.api.registry ? [areas.api.registry] : [])];
  const auditFiles = [audit.featureAudit, ...(features ? [] : [settings.productRoutes])].filter(Boolean);
  if (auditFiles.length > 0) content.audit = auditFiles;
  content.sources = [manifest];
  return content;
}

/**
 * The proposal for `assess-workspace`: the `content` collections, and the About manifest built whole (`--write` writes
 * it when it differs). `ctx` is `{ root, files, settings, packageJson, today }`.
 */
export function proposeWorkspace({ root, files, settings, packageJson, today }) {
  if (!settings) throw new Error('wayfinder: assess-workspace proposes nothing before the workspace config exists (package.json wayfinder.config)');
  const content = proposeContent({ files, settings });
  const entries = Object.entries(content).map(([name, value]) => ({ setting: `content.${name}`, value, from: 'the files the areas read' }));
  const notes = [];
  for (const name of Object.keys(settings.content ?? {}))
    if (!(name in content)) notes.push(`content.${name} is the repository's own collection: keep it if a page reads it`);
  const built = buildAboutManifest({ root, settings, packageJson, today });
  return {
    summary: `${Object.keys(content).length} content collections, the About manifest ${built.same ? 'up to date' : 'to rebuild'}`,
    entries,
    judged: [{ setting: 'areas.about.prose', rule: 'a file of the repository\'s own only where the kit\'s default prose says something untrue for it' }],
    notes,
    writes: [{ file: built.file, text: built.text, what: `the About manifest (${built.same ? 'unchanged' : 'rebuilt'})` }],
  };
}
