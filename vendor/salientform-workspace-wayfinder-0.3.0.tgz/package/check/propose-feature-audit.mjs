/**
 * The feature audit's first-run proposals (spec WW-M1 §5): the dead-code sweep's settings (`areas.audit.unusedExports`)
 * read off the repository's build and test configs, and a draft feature audit holding the sweep's findings, one
 * `dead-code` finding per file. `assess-feature-audit` rewrites the draft's wording and adds what only reading the
 * product finds: `unreachable`, `todo` and `recommendation` findings.
 */
import path from 'node:path';
import { globMatcher } from './features.mjs';
import { fixtureRoots, underAny } from './propose-audit.mjs';
import { packageDirs, packageJsons, readJsonFile, readText, testRunners, unique, within } from './repo-files.mjs';
import { DEFAULT_ENTRIES, findUnusedExports } from './unused-exports.mjs';

const CODE = /\.([cm]?[jt]sx?|css)$/;
const BARREL = /(^|\/)index\.[cm]?[jt]sx?$/;
/** A tool's config (`drizzle.config.ts`, `vitest.config.mts`): nothing imports it, the tool reads it. */
const TOOL_CONFIG = /(^|\/)[\w.-]+\.config\.[cm]?[jt]s$/;
/** A bundler's config, which names the entries it builds (`entry`, `input`, `entryPoints`). */
const BUNDLER_CONFIG = /(^|\/)(tsdown|tsup|rollup|rolldown|esbuild|unbuild|build)\.config\.[cm]?[jt]s$/;

/** The group the draft files the sweep's findings in. */
export const DEAD_CODE_GROUP = {
  id: 'dead-code',
  title: 'Dead code',
  blurb: 'Exports and files nothing in the product uses, found by the dead-code sweep.',
};

/** The local files an `index.html` loads (`src="/src/main.tsx"`, `href="./styles.css"`), repository-relative. */
function htmlEntries(root, html) {
  const dir = path.posix.dirname(html);
  return [...(readText(root, html) ?? '').matchAll(/\b(?:src|href)=["'](?!https?:|\/\/|#|data:)([^"'?#]+)["']/g)].map((m) =>
    path.posix.normalize(path.posix.join(dir, m[1].replace(/^\//, ''))),
  );
}

/**
 * The entry files a bundler's config names, repository-relative: every quoted path in its `entry`, `input` or
 * `entryPoints` value (a string, a list or an object of them), relative to the config's directory.
 */
function bundlerEntries(root, config) {
  const dir = path.posix.dirname(config);
  const text = readText(root, config) ?? '';
  const values = [...text.matchAll(/\b(?:entry|input|entryPoints)\s*:\s*(\[[^\]]*\]|\{[^}]*\}|['"][^'"]+['"])/g)].map((m) => m[1]);
  return values.flatMap((value) =>
    [...value.matchAll(/['"]([^'"]+\.[cm]?[jt]sx?)['"]/g)].map((m) => path.posix.normalize(path.posix.join(dir, m[1]))),
  );
}

/** The source files a package's `package.json` names: `main`, `module`, `bin`, and every `<runner> <file>` its scripts run. */
function packageEntries({ dir, json }) {
  const named = [json.main, json.module, ...(typeof json.bin === 'string' ? [json.bin] : Object.values(json.bin ?? {}))];
  for (const command of Object.values(json.scripts ?? {}))
    for (const m of String(command).matchAll(/\b(?:node|tsx|ts-node|bun|vite-node)\s+(?:--?[\w-]+(?:=\S+)?\s+)*([\w./-]+\.[cm]?[jt]sx?)\b/g))
      named.push(m[1]);
  return named.filter((f) => typeof f === 'string').map((f) => path.posix.normalize(path.posix.join(dir || '.', f)));
}

/**
 * The proposal for `areas.audit.unusedExports`: `ctx` is `{ root, files, settings, workspaceDir }`.
 * - `roots`: the top-level directories holding the repository's packages, else `src`.
 * - `entries`: the kit's defaults, then each file under the roots that a build or test config, a bundler's config
 *   (`tsdown`, `tsup`, Rollup), an `index.html` or a package names (setup files, global setup, scripts, `bin`), and each
 *   tool config (`*.config.ts`), that no default matches; a barrel (`index.*`) is never an orphan, so none is listed.
 * - `ignore`: the workspace app and the fixture directories under the roots.
 * The draft feature audit: one `dead-code` finding per file the sweep reports.
 */
export function proposeUnusedExports({ root, files, workspaceDir }) {
  const fixtures = fixtureRoots(files);
  const packages = packageDirs(files).filter((dir) => !within(dir, workspaceDir) && !underAny(`${dir}/`, fixtures));
  const roots = packages.length > 0 ? unique(packages.map((dir) => dir.split('/')[0])).sort() : files.some((f) => f.startsWith('src/')) ? ['src'] : [];
  const underRoots = (file) => roots.some((r) => file.startsWith(`${r}/`));
  const isDefault = (file) => DEFAULT_ENTRIES.some((glob) => globMatcher(glob)(file));
  const named = [
    ...files.filter((f) => TOOL_CONFIG.test(f)),
    ...files.filter((f) => BUNDLER_CONFIG.test(f) && !within(f, workspaceDir)).flatMap((config) => bundlerEntries(root, config)),
    ...testRunners(root, files, { exclude: workspaceDir }).flatMap((r) => r.setupFiles),
    ...files.filter((f) => f.endsWith('index.html')).flatMap((html) => htmlEntries(root, html)),
    ...packageJsons(root, files).filter((p) => !within(p.dir, workspaceDir)).flatMap(packageEntries),
  ];
  const fileSet = new Set(files);
  const extra = unique(named)
    .filter((file) => fileSet.has(file) && CODE.test(file) && !BARREL.test(file) && underRoots(file) && !isDefault(file) && !within(file, workspaceDir) && !underAny(file, fixtures))
    .sort();
  const ignore = [
    ...(workspaceDir && underRoots(`${workspaceDir}/`) ? [`${workspaceDir}/`] : []),
    ...fixtures.filter(underRoots),
  ];
  return { roots, entries: [...DEFAULT_ENTRIES, ...extra], ignore, extra };
}

const slugOf = (file) => file.replace(/\.[^.]+$/, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

/**
 * The sweep's report as draft findings: one per file, its exports used nowhere or its having no importer. An export
 * used only in its own file or only by tests is not dead code, and makes no finding.
 */
export function deadCodeFindings({ exports, orphans }) {
  const byFile = new Map();
  for (const { file, name, use = 'nowhere' } of exports) if (use === 'nowhere') byFile.set(file, [...(byFile.get(file) ?? []), name]);
  const findings = [];
  for (const file of orphans)
    findings.push({
      slug: `dead-${slugOf(file)}`,
      title: `${path.posix.basename(file)} is imported by nothing`,
      kind: 'dead-code',
      group: DEAD_CODE_GROUP.id,
      status: 'open',
      summary: 'The dead-code sweep finds no file that imports it by relative path, and it is no entry file.',
      files: [file],
      action: 'Delete the file, or import it where it belongs.',
    });
  for (const [file, names] of byFile) {
    if (orphans.includes(file)) continue;
    findings.push({
      slug: `dead-${slugOf(file)}`,
      title: `${path.posix.basename(file)}: ${names.length === 1 ? 'an unused export' : `${names.length} unused exports`}`,
      kind: 'dead-code',
      group: DEAD_CODE_GROUP.id,
      status: 'open',
      summary: `The dead-code sweep finds no reference to ${names.map((n) => `\`${n}\``).join(', ')} but its declaration: not in another file, a test or its own file.`,
      files: [file],
      action: names.length === 1 ? 'Delete the export, or use it.' : 'Delete the exports, or use them.',
    });
  }
  findings.sort((a, b) => a.files[0].localeCompare(b.files[0]));
  // Two files whose paths slugify alike (`a.ts`, `a.tsx`) get numbered slugs.
  const seen = new Set();
  for (const finding of findings) {
    let slug = finding.slug;
    for (let n = 2; seen.has(slug); n++) slug = `${finding.slug}-${n}`;
    finding.slug = slug;
    seen.add(slug);
  }
  return findings;
}

/**
 * The proposal for the feature audit: the sweep's settings, and the feature audit itself. Without a feature audit file
 * `--write` writes the draft; with one, the run lists the files the sweep reports that no finding names, and the
 * `dead-code` findings whose files it no longer reports, for the skill to reconcile.
 */
export function proposeFeatureAudit({ root, files, settings, workspaceDir, today }) {
  const audit = settings?.areas?.audit ?? {};
  const proposal = proposeUnusedExports({ root, files, workspaceDir });
  const entries = [
    { setting: 'areas.audit.unusedExports.roots', value: proposal.roots, from: proposal.roots.length > 0 ? 'the directories holding the packages' : 'no source directory' },
    { setting: 'areas.audit.unusedExports.entries', value: proposal.entries, from: `the whole list, which replaces the kit's: its defaults${proposal.extra.length > 0 ? ', and the files the configs, index.html files and package scripts name' : ''}` },
    { setting: 'areas.audit.unusedExports.ignore', value: proposal.ignore, from: 'the workspace app when it sits under a root, and the fixtures under the roots; none when neither does' },
  ];
  const notes = [];
  const writes = [];
  const file = audit.featureAudit ?? (workspaceDir ? `${workspaceDir}/src/feature-audit.json` : 'feature-audit.json');
  if (!audit.featureAudit) {
    entries.push({ setting: 'areas.audit.featureAudit', value: file, from: 'beside the About manifest' });
    entries.push({ setting: 'areas.audit.todoSources', value: ['feature-audit:'], from: 'added to the list: a todo finding\'s TODO entry names it' });
  }
  if (proposal.roots.length === 0) {
    notes.push('no source directory to sweep: the feature audit starts empty');
  }
  const sweepSettings = { areas: { audit: { unusedExports: audit.unusedExports ?? proposal } } };
  const found = proposal.roots.length > 0 || audit.unusedExports ? findUnusedExports(sweepSettings, { root }) : { exports: [], orphans: [] };
  const findings = deadCodeFindings(found);
  const kept = { 'own-file': found.exports.filter((e) => e.use === 'own-file').length, tests: found.exports.filter((e) => e.use === 'tests').length };
  if (kept['own-file'] + kept.tests > 0)
    notes.push(
      `not drafted: ${kept['own-file']} exports used only in their own file and ${kept.tests} used only by tests, which are not dead code (scripts/find-unused-exports.mjs lists them)`,
    );
  const existing = readJsonFile(root, file);
  if (existing === undefined) {
    const draft = { reviewedAt: today, groups: [DEAD_CODE_GROUP], findings };
    writes.push({ file, text: `${JSON.stringify(draft, null, 2)}\n`, what: `the draft feature audit: ${findings.length} dead-code findings` });
  } else {
    const named = new Set((existing.findings ?? []).flatMap((f) => f.files ?? []));
    const reported = new Set(findings.flatMap((f) => f.files));
    for (const finding of findings) if (!named.has(finding.files[0])) notes.push(`new: ${finding.files[0]} — ${finding.title}`);
    for (const finding of existing.findings ?? [])
      if (finding.kind === 'dead-code' && !(finding.files ?? []).some((f) => reported.has(f) || [...reported].some((r) => r.startsWith(f.endsWith('/') ? f : `${f}/`))))
        notes.push(`gone: ${finding.slug} — the sweep no longer reports ${(finding.files ?? []).join(', ')}`);
  }
  return {
    summary: `${found.exports.filter((e) => e.use === 'nowhere').length} exports used nowhere and ${found.orphans.length} orphan files under ${proposal.roots.join(', ') || 'no root'}`,
    entries,
    judged: [
      { setting: 'findings', rule: 'each draft finding\'s title, summary, action and group, after confirming it; unreachable, todo and recommendation findings come from reading the product' },
      { setting: 'findings.status', rule: 'open, or known and planned with the ref where the repository already records it' },
    ],
    notes,
    writes,
  };
}
