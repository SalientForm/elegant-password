/**
 * The check runner (spec M12.11 §6.3): every skill's check script is `await runCheck('<name>')`. It loads the workspace
 * config and the repository's hooks file (package.json `wayfinder.config` and `wayfinder.hooks`), runs the named check
 * with what the hooks return, appends the problems `extraChecks` returns under that name, prints the notes, and
 * exits 1 on any problem or prints the OK line, then the placeholders the check found: what cannot be
 * generated yet, never a failure unless the script runs with `--strict`.
 *
 * Checks: about, audit, feature-audit, features, api, platform-docs. Each check's own header lists what
 * fails it.
 */
import { checkAbout } from './about.mjs';
import { checkApi } from './api.mjs';
import { checkAuditImplementation } from './audit-implementation.mjs';
import { checkAuditLedger } from './audit-ledger.mjs';
import { checkFeatureAudit } from './feature-audit.mjs';
import { checkFeatureCatalogue } from './feature-catalogue.mjs';
import { exists, finish, loadWorkspaceHooks, loadWorkspaceSettings, readRepo, repoRoot } from './index.mjs';
import { checkPlatformDocs } from './platform-docs.mjs';
import { describeSettingsPlaceholder } from './settings-defaults.mjs';

/** Each check: (settings, hooks, ctx) → { problems, ok, notes?, placeholders? }, a placeholder `{ where, reason, toFill }`. */
export const CHECKS = {
  about: (settings) => {
    const r = checkAbout(settings);
    return { problems: r.problems, ok: `about OK — ${r.summary}` };
  },
  audit: (settings) => {
    const implementation = checkAuditImplementation(settings);
    const ledger = checkAuditLedger(settings, { implementation });
    return {
      problems: [...implementation.problems, ...ledger.problems],
      placeholders: implementation.placeholders,
      // The implementation summary names only the configured files, and is empty without any.
      ok: `audit registries OK — ${[ledger.summary, implementation.summary].filter(Boolean).join('; ')}`,
    };
  },
  'feature-audit': (settings) => {
    const r = checkFeatureAudit(settings);
    return { problems: r.problems, ok: `feature-audit registry OK — ${r.summary}` };
  },
  features: (settings, hooks, ctx) => {
    const r = checkFeatureCatalogue(settings, { router: hooks.productRoutes?.(ctx) });
    // Each unclaimed file is named, so a first run can claim or explain it before the app's Gaps page loads.
    const notes = r.gaps.unclaimed.flatMap((root) => root.files.map((file) => `unclaimed: ${file}`));
    return { problems: r.problems, placeholders: r.placeholders, notes, ok: `feature catalogue OK — ${r.summary}` };
  },
  api: (settings, hooks, ctx) => {
    const r = checkApi(settings, { fetched: hooks.fetchSites?.(ctx) });
    return { problems: r.problems, placeholders: r.placeholders, ok: `API registry OK — ${r.summary}` };
  },
  'platform-docs': (settings, hooks, ctx) => {
    const labels = hooks.navLabels?.(ctx);
    const r = checkPlatformDocs(settings, { mentions: labels ?? [] });
    return {
      problems: r.problems,
      placeholders: r.placeholders,
      notes: r.unmentioned.map((label) => `unmentioned: ${label}`),
      ok: `platform docs OK — ${r.summary}${labels ? `, ${labels.length} navigation labels checked` : ''}`,
    };
  },
};

/** Runs check `name` in the repository the process runs in, then exits (see the header). */
export async function runCheck(name) {
  const check = CHECKS[name];
  if (!check) throw new Error(`wayfinder: no check ${name} (${Object.keys(CHECKS).join(', ')})`);
  const settings = await loadWorkspaceSettings();
  const hooks = await loadWorkspaceHooks();
  const ctx = { settings, repoRoot, readRepo, exists };
  const { problems, ok, notes = [], placeholders = [] } = check(settings, hooks, ctx);
  const extra = hooks.extraChecks?.(ctx)?.[name] ?? [];
  for (const note of notes) console.log(note);
  const lines = placeholders.map((p) => describeSettingsPlaceholder(p.where, p));
  const strict = process.argv.includes('--strict') ? lines.map((line) => `${line} (--strict)`) : [];
  finish([...problems, ...extra, ...strict], ok);
  for (const line of lines) console.log(line);
}
