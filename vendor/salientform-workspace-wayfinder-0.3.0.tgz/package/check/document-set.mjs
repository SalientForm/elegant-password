/**
 * The document set's paths and the placeholder format (`docs/formats.md`, "The document set" and "Placeholders"), with
 * no node dependency: the document check (`documents.mjs`) and About's Placeholders page both read them.
 */

/** Where the documents live, unless the Audit area names its three elsewhere. */
export const DOCUMENTS_DIR = 'docs';

/** The document set, in the order ABOUT.md lists it. `audit` names the Audit setting that may move the file. */
export const DOCUMENTS = [
  { key: 'about', file: 'ABOUT.md', holds: 'what the repository is, who it is for, its state, and where each document is' },
  { key: 'skills', file: 'SKILLS.md', holds: 'the agent skills the repository keeps' },
  { key: 'architecture', file: 'ARCHITECTURE.md', audit: 'architecture', holds: 'how it is built: layout, stack, running, deployment, planned migrations' },
  { key: 'roadmap', file: 'ROADMAP.md', audit: 'roadmap', holds: 'planned work: milestones, phases and their order' },
  { key: 'features', file: 'FEATURES.md', holds: 'what the product does, one section per feature' },
  { key: 'todo', file: 'TODO.md', audit: 'todo', holds: 'ideas and small items not yet planned' },
  { key: 'setup', file: 'SETUP.md', holds: 'how to install, configure, run, test, build and release it' },
  { key: 'issues', file: 'ISSUES.md', holds: 'known problems and limits, with workarounds and what would fix them' },
];

export const PLACEHOLDER_REASON = '> **Not generated yet.**';
export const PLACEHOLDER_TO_FILL = '> **To fill:**';

/** Each document's repository path: `docs/<FILE>`, or the Audit area's own path for its three. */
export function documentPaths(settings) {
  const audit = settings?.areas?.audit ?? {};
  return DOCUMENTS.map((doc) => ({ ...doc, path: (doc.audit && audit[doc.audit]) || `${DOCUMENTS_DIR}/${doc.file}` }));
}

/**
 * The placeholders in `markdown`: `{ line, reason, toFill }` each (1-based line of its reason), and the problems of
 * any that is malformed, each prefixed with `label`. A fenced code block is an example, never a placeholder.
 */
export function parsePlaceholders(markdown, label = 'document') {
  const lines = markdown.split('\n');
  const placeholders = [];
  const problems = [];
  // The open fence (its backticks or tildes): CommonMark closes it only with the same character, at least as many.
  let fence;
  lines.forEach((text, i) => {
    const marker = /^ {0,3}(`{3,}|~{3,})/.exec(text)?.[1];
    if (marker && (!fence || (marker[0] === fence[0] && marker.length >= fence.length))) {
      fence = fence ? undefined : marker;
      return;
    }
    if (fence) return;
    if (text.startsWith(PLACEHOLDER_REASON)) {
      const reason = text.slice(PLACEHOLDER_REASON.length).trim();
      const next = lines[i + 1] ?? '';
      const toFill = next.startsWith(PLACEHOLDER_TO_FILL) ? next.slice(PLACEHOLDER_TO_FILL.length).trim() : '';
      if (!reason) problems.push(`${label}:${i + 1}: a placeholder with no reason after "Not generated yet."`);
      if (!next.startsWith(PLACEHOLDER_TO_FILL)) problems.push(`${label}:${i + 1}: a placeholder with no "To fill:" line after its reason`);
      else if (!toFill) problems.push(`${label}:${i + 2}: a placeholder whose "To fill:" line is empty`);
      placeholders.push({ line: i + 1, reason, toFill });
    } else if (text.startsWith(PLACEHOLDER_TO_FILL) && !(lines[i - 1] ?? '').startsWith(PLACEHOLDER_REASON))
      problems.push(`${label}:${i + 1}: a "To fill:" line with no "Not generated yet." line before it`);
  });
  return { placeholders, problems };
}
