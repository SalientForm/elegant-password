/**
 * The Platform Docs area's first-run proposals (spec WW-M1 §5): the area's `directory`, found from pages already in
 * the format, and the navigation labels (the hooks file's `navLabels`) no page mentions yet, one page to draft for each.
 * `assess-platform-docs` writes the pages from the product's own text, each opening with the draft placeholder until a
 * person has read it (spec WW-M1 §7, question 4).
 */
import path from 'node:path';
import { fixtureRoots, underAny } from './propose-audit.mjs';
import { readText, unique } from './repo-files.mjs';

const PAGE = /^\d+-[a-z0-9-]+\.md$/;
/** A page's file slug: `Order history` → `order-history`. */
const slugify = (label) => label.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'page';
const FRONT = /^---\r?\n([\s\S]*?)\r?\n---/;

/** The placeholder every drafted page opens with, under its front matter (§7, question 4). */
export const DRAFT_PLACEHOLDER = {
  reason: 'This page was drafted by assess-platform-docs from the product\'s own text and has not been read by a person.',
  toFill: 'Read it against the product, correct what is wrong, then delete these two lines.',
};

/**
 * The proposal for `areas['platform-docs']`: `ctx` is `{ root, files, settings, hooks, workspaceDir }`.
 * - `directory`: the configured one, else the directory holding the most `<order>-<slug>.md` pages with a title, an
 *   order and a summary in their front matter.
 * - The pages to draft: one per navigation label no page mentions, `<order>-<slug>.md` after the last page's order.
 */
export function proposePlatformDocs({ root, files, settings, hooks = {}, workspaceDir }) {
  const area = settings?.areas?.['platform-docs'];
  const configured = area && !area.placeholder ? area.directory : undefined;
  const skip = [...fixtureRoots(files), ...(workspaceDir ? [`${workspaceDir}/`] : [])];
  const pages = files.filter((file) => {
    if (underAny(file, skip) || !PAGE.test(path.posix.basename(file))) return false;
    const front = FRONT.exec(readText(root, file) ?? '')?.[1] ?? '';
    return ['title', 'order', 'summary'].every((key) => new RegExp(`^${key}:\\s*\\S`, 'm').test(front));
  });
  const counts = new Map();
  for (const file of pages) counts.set(path.posix.dirname(file), (counts.get(path.posix.dirname(file)) ?? 0) + 1);
  const found = [...counts].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0]?.[0];
  const directory = configured ?? found;
  const entries = [];
  const notes = [];
  if (directory) entries.push({ setting: "areas['platform-docs'].directory", value: directory, from: configured ? 'the config' : `${counts.get(found)} pages in the format` });

  const inDir = directory ? files.filter((f) => path.posix.dirname(f) === directory && f.endsWith('.md')) : [];
  const bodies = inDir.map((f) => (readText(root, f) ?? '').toLowerCase()).join('\n');
  const labels = hooks.navLabels
    ? unique(hooks.navLabels({ settings, repoRoot: root, readRepo: (file) => readText(root, file), exists: (file) => readText(root, file) !== undefined }))
    : [];
  const last = Math.max(0, ...inDir.map((f) => Number(/^(\d+)-/.exec(path.posix.basename(f))?.[1] ?? 0)));
  const toDraft = labels.filter((label) => !bodies.includes(label.toLowerCase()));
  toDraft.forEach((label, i) => notes.push(`draft: ${directory ?? 'docs/platform'}/${String(last + 10 * (i + 1)).padStart(2, '0')}-${slugify(label)}.md — ${label}`));
  if (!hooks.navLabels) notes.push('no navLabels hook: write one in the hooks file that reads the product\'s navigation labels, to list the pages to draft');

  const generated = directory !== undefined || toDraft.length > 0;
  return {
    summary: `${pages.length} pages in the format, ${labels.length} navigation labels, ${toDraft.length} pages to draft${generated ? '' : ': nothing for the area yet, keep its placeholder'}`,
    entries,
    judged: [
      { setting: 'pages', rule: 'each drafted page from the product\'s own text (labels, headings, empty states), opening with the draft placeholder' },
      { setting: "areas['platform-docs'].directory", rule: directory ? 'keep it' : 'docs/platform, once the user asks for pages or the product has navigation to describe' },
    ],
    notes,
    writes: [],
  };
}
