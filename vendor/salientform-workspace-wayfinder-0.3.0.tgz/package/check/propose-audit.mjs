/**
 * The Audit area's first-run proposals (spec WW-M1 §5): the settings of `areas.audit` a script reads off the
 * repository. `assess-audit` writes them into the workspace config; `linkExempt` it judges, from the files listed.
 */
import path from 'node:path';
import { brokenLinks } from './links.mjs';
import { SPEC_STATES } from './audit-registries.mjs';
import { AUDIT_DEFAULTS } from './settings-defaults.mjs';
import { readText, unique } from './repo-files.mjs';

/** The values a roadmap's phases and a TODO list's entries take when the repository's own use none. */
export const DEFAULT_PHASE_KINDS = ['feature', 'infrastructure', 'migration'];
export const DEFAULT_TODO_AREAS = ['app', 'docs', 'repo'];
export const DEFAULT_SPEC_DIRS = ['docs/specs', 'docs/plans'];

/** A directory whose files are test data or an agent's scratch copy, never the repository's own documents. */
const FIXTURE_DIR = /^(__)?(test-)?fixtures?(__)?$|^__mocks__$/;
const SCRATCH_DIRS = ['.claude/worktrees', '.worktrees'];

/**
 * The directories, each ending in `/`, under which `files` holds test fixtures or agents' scratch worktrees: the first
 * `fixtures`, `test-fixtures`, `__fixtures__` or `__mocks__` segment of a path, and `.claude/worktrees/`.
 */
export function fixtureRoots(files) {
  const roots = files.flatMap((file) => {
    const scratch = SCRATCH_DIRS.find((dir) => file.startsWith(`${dir}/`));
    if (scratch) return [`${scratch}/`];
    const segments = file.split('/');
    const at = segments.slice(0, -1).findIndex((segment) => FIXTURE_DIR.test(segment));
    return at === -1 ? [] : [`${segments.slice(0, at + 1).join('/')}/`];
  });
  return unique(roots).sort();
}

/** True when `file` sits under one of `prefixes`. */
export const underAny = (file, prefixes) => prefixes.some((prefix) => file.startsWith(prefix));

const STATE = /^---\r?\n(?:[^\n]*\r?\n)*?state:\s*([\w-]+)\s*\r?\n(?:[^\n]*\r?\n)*?---/;

/** The values `- **<label>:** <value>` lines take in `markdown`, in first-use order. */
function labelled(markdown, label) {
  return unique([...(markdown ?? '').matchAll(new RegExp(`^- \\*\\*${label}:\\*\\* *(\\S[^\\n]*?)\\s*$`, 'gm'))].map((m) => m[1]));
}

/**
 * The proposal for `areas.audit`: `ctx` is `{ root, files, settings }` (`settings` may be undefined).
 * - `specDirs`: the directories holding markdown with a spec or plan `state` in its front matter (specs first, by a
 *   `spec` in their path), else the defaults.
 * - `phaseKinds`: the defaults, the roadmap format's own kinds, then any other `Kind:` value the roadmap uses, so the
 *   next phase may be of any of them; `todoAreas`: the `Area:` values the TODO list uses, in the order it first uses
 *   them (the Todo page's filters follow it), else the defaults.
 * - `todoSources`: `idea`, then each `Source:` value that is not a repository path (a `name:` prefix for a value with
 *   a colon), and `feature-audit:` with a feature audit.
 * - `ignore`: the fixture and scratch directories that hold tracked markdown.
 * Judged: `linkExempt`, from the files whose links are broken.
 */
export function proposeAudit({ root, files, settings }) {
  const audit = settings?.areas?.audit ?? {};
  const markdown = files.filter((file) => file.endsWith('.md'));
  const ignore = fixtureRoots(markdown);
  const own = markdown.filter((file) => !underAny(file, [...ignore, ...(audit.ignore ?? [])]));
  const reviewCount = own.filter((file) => underAny(file, [audit.reviews ?? AUDIT_DEFAULTS.reviews])).length;
  const entries = [];
  const notes = [];

  const stated = own.filter((file) => {
    const state = STATE.exec(readText(root, file) ?? '')?.[1];
    return state !== undefined && SPEC_STATES.includes(state);
  });
  const dirs = unique(stated.map((file) => path.posix.dirname(file))).sort();
  const outer = dirs.filter((dir) => !dirs.some((other) => other !== dir && dir.startsWith(`${other}/`)));
  const specDirs = [...outer.filter((d) => /spec/i.test(d)), ...outer.filter((d) => !/spec/i.test(d))];
  entries.push(
    specDirs.length > 0
      ? { setting: 'areas.audit.specDirs', value: specDirs, from: `${stated.length} documents with a spec or plan state` }
      : { setting: 'areas.audit.specDirs', value: DEFAULT_SPEC_DIRS, from: 'no document has a spec state: the defaults' },
  );

  const roadmapFile = audit.roadmap ?? 'docs/ROADMAP.md';
  const todoFile = audit.todo ?? 'docs/TODO.md';
  const roadmap = readText(root, roadmapFile);
  const todo = readText(root, todoFile);
  const kinds = labelled(roadmap, 'Kind');
  entries.push({
    setting: 'areas.audit.phaseKinds',
    value: unique([...DEFAULT_PHASE_KINDS, ...kinds]),
    from: kinds.some((k) => !DEFAULT_PHASE_KINDS.includes(k)) ? `the defaults, and the other Kind: values ${roadmapFile} uses` : 'the defaults, the roadmap format\'s kinds',
  });
  const areas = labelled(todo, 'Area');
  entries.push({
    setting: 'areas.audit.todoAreas',
    value: areas.length > 0 ? areas : DEFAULT_TODO_AREAS,
    from: areas.length > 0 ? `the Area: values ${todoFile} uses` : `${todoFile} uses none: the defaults`,
  });
  const fileSet = new Set(files);
  const sources = labelled(todo, 'Source')
    .filter((source) => !fileSet.has(source.replace(/#.*$/, '')) && !/^[\w.-]+\/[\w./-]+$/.test(source))
    .map((source) => (source.includes(':') ? `${source.slice(0, source.indexOf(':'))}:` : source));
  const featureAudit = audit.featureAudit ? ['feature-audit:'] : [];
  entries.push({
    setting: 'areas.audit.todoSources',
    value: unique(['idea', ...sources, ...featureAudit]),
    from: `the Source: values of ${todoFile} that are not paths${featureAudit.length ? ', and the feature audit' : ''}`,
  });

  entries.push({
    setting: 'areas.audit.ignore',
    value: ignore,
    from: ignore.length > 0 ? 'test fixtures and agents\' scratch copies holding markdown' : 'no fixture or scratch directory holds markdown',
  });

  const exists = (file) => fileSet.has(file) || files.some((f) => f.startsWith(`${file}/`));
  const broken = own.flatMap((file) => brokenLinks(file, readText(root, file) ?? '', exists).map((link) => `${file}:${link.line} → ${link.href}`));
  for (const link of broken) notes.push(`broken link: ${link}`);

  return {
    // Labelled so it reads against the audit check's count, which leaves the reviews out.
    summary: `${own.length} markdown files: ${own.length - reviewCount} outside the reviews folder and ${reviewCount} reviews; ${specDirs.length} spec directories`,
    entries,
    judged: [
      {
        setting: 'areas.audit.linkExempt',
        rule: broken.length > 0
          ? 'fix each broken link listed below; exempt a path prefix only when its links are broken on purpose (a fixture)'
          : 'no link is broken: leave it unset',
      },
    ],
    notes,
    writes: [],
  };
}
