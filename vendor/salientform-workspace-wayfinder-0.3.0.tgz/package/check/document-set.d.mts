/** One document of the document set. */
export interface DocumentEntry {
  key: string;
  file: string;
  /** The Audit setting that may move the file (`roadmap`, `todo`, `architecture`). */
  audit?: string;
  holds: string;
}
export const DOCUMENTS_DIR: string;
export const DOCUMENTS: readonly DocumentEntry[];
export const PLACEHOLDER_REASON: string;
export const PLACEHOLDER_TO_FILL: string;
/** Each document's repository path: `docs/<FILE>`, or the Audit area's own path for its three. */
export function documentPaths(settings: { areas?: Readonly<Record<string, unknown>> } | undefined): (DocumentEntry & { path: string })[];
/** A document placeholder: the 1-based line of its reason, the reason and what would fill it. */
export interface DocumentPlaceholder {
  line: number;
  reason: string;
  toFill: string;
}
/** The placeholders in `markdown`, outside fenced code, and the problems of any that is malformed. */
export function parsePlaceholders(markdown: string, label?: string): { placeholders: DocumentPlaceholder[]; problems: string[] };
