/**
 * Hosted workspaces (WW-M1.6, docs/specs/2026-11-20-hosted-workspaces-design.md): an instance of Wayfinder for another
 * repository, kept in the kit's own repository at `.workspaces/<name>/` and built from the kit's working copy, which
 * reads that repository's files and never writes them.
 *
 * The instance's folder reads as the repository with the instance installed. It holds the instance's own files (what
 * the onboarding writes or changes, at the repository's paths), and the copies `refreshHosted` makes of everything
 * else:
 *  - each file of the repository that its git lists (tracked, and untracked but not ignored), and each ignored file
 *    the settings `include` (coverage summaries the Features area reads, say), except below `.git`, `node_modules`
 *    and the paths the settings `hide` (the repository's own install of Wayfinder, say);
 *  - the kit's skills at the settings' `skillsDir`, so the instance runs the working copy's skills.
 * Two things are not copies: `node_modules/<the kit's name>`, a link to the kit's checkout, so the app, the hooks file
 * and the checks import the working copy, and every other package resolves from the kit's own `node_modules`, two
 * directories up; and a `.git` file naming no repository, so git run in the folder fails instead of reading the kit's.
 *
 * Every file in the folder is a real file, so writing one never reaches the repository or the kit. What a refresh
 * copied is recorded in `.wayfinder-hosted-copies.json` with the copy's size and time: a later refresh brings an
 * untouched copy up to date with its source, or removes it when its source is gone, and leaves a copy that was
 * changed, which is the instance's own from then on. Deleting such a file gives the path back to the repository.
 *
 * The settings, `.wayfinder-hosted.json` at the folder's root:
 *   { "repository": "<path, absolute or from the folder>", "skillsDir": ".agents/skills", "hide": ["workspace"],
 *     "include": ["test-output/**\/coverage-summary.json"] }
 */
import { execFileSync } from 'node:child_process';
import {
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  readlinkSync,
  renameSync,
  rmdirSync,
  statSync,
  symlinkSync,
  unlinkSync,
  writeFileSync,
} from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { globMatcher } from './features.mjs';

/** The settings file at a hosted folder's root: its presence makes a folder a hosted instance. */
export const HOSTED_FILE = '.wayfinder-hosted.json';
/** What the last refresh copied: `{ copies: { <path>: { from, size, mtimeMs, fromSize, fromMtimeMs } } }`. */
export const HOSTED_COPIES = '.wayfinder-hosted-copies.json';
/** The record of the links an earlier version made, removed by the first refresh that finds it. */
const HOSTED_LINKS = '.wayfinder-hosted-links.json';
/** Held while a refresh runs, so two at once (two servers starting together) take turns. */
const HOSTED_LOCK = '.wayfinder-hosted.lock';
/** Where the kit keeps its hosted instances, one folder per name, under its own repository's root. */
export const HOSTED_DIR = '.workspaces';
/** The `.git` file a hosted folder holds: it names no repository, so git fails there. */
export const GIT_STUB = 'gitdir: .wayfinder-hosted: a hosted workspace is not a git repository\n';

const KIT_NAME = JSON.parse(readFileSync(fileURLToPath(new URL('../package.json', import.meta.url)), 'utf8')).name;
const NAME = /^[a-z0-9][a-z0-9-]*$/;
/** The folder's own bookkeeping at its root: never a copy, never the instance's file. */
const OWN = [HOSTED_FILE, HOSTED_COPIES, HOSTED_LINKS, HOSTED_LOCK, '.git', 'node_modules'];

const lstat = (file) => {
  try {
    return lstatSync(file);
  } catch {
    return undefined;
  }
};
const under = (rel, prefix) => rel === prefix || rel.startsWith(`${prefix}/`);

/** Whether `name` can name a hosted instance: lower-case letters, digits and hyphens. */
export function isHostedName(name) {
  return NAME.test(name);
}

/**
 * The hosted folder `name` names in the kit's checkout `kit` (`WAYFINDER_WORKSPACE`, the active workspace); throws
 * when there is none, since hosted instances are kept only in the kit's own repository.
 */
export function namedHosted(kit, name) {
  if (!isHostedName(name)) throw new Error(`wayfinder: WAYFINDER_WORKSPACE=${name} is not an instance's name (lower-case letters, digits and hyphens)`);
  const folder = path.join(kit, HOSTED_DIR, name);
  if (!existsSync(path.join(folder, HOSTED_FILE))) {
    throw new Error(`wayfinder: WAYFINDER_WORKSPACE=${name}, but ${kit} has no ${HOSTED_DIR}/${name}/${HOSTED_FILE}: hosted workspaces are kept in the kit's own repository (pnpm hosted new)`);
  }
  return folder;
}

/** The hosted folder `dir` is in (it, or the nearest directory above it with the settings file), or undefined. */
export function findHosted(dir = process.cwd()) {
  for (let at = path.resolve(dir); ; at = path.dirname(at)) {
    if (existsSync(path.join(at, HOSTED_FILE))) return at;
    // A repository's root ends the search: nothing above a checkout of its own makes it hosted.
    if (existsSync(path.join(at, '.git')) || path.dirname(at) === at) return undefined;
  }
}

function relativePath(value, label) {
  if (typeof value !== 'string' || value === '' || path.isAbsolute(value) || value.split('/').some((s) => s === '..' || s === '.' || s === '')) {
    throw new Error(`wayfinder: ${HOSTED_FILE} ${label} must be a path inside the repository (${JSON.stringify(value)})`);
  }
  return value;
}

/**
 * A hosted folder's settings: `{ root, repository, skillsDir, hide, include, kit }`, the paths absolute but
 * `skillsDir`, `hide` and `include`, which are the repository's. `kit` is the kit's checkout holding the folder
 * (`<kit>/.workspaces/<name>`).
 */
export function readHosted(folder) {
  const root = path.resolve(folder);
  const file = path.join(root, HOSTED_FILE);
  const raw = JSON.parse(readFileSync(file, 'utf8'));
  if (typeof raw.repository !== 'string') throw new Error(`wayfinder: ${file} has no repository (the path of the checkout it hosts)`);
  const repository = path.resolve(root, raw.repository);
  if (!existsSync(path.join(repository, '.git'))) throw new Error(`wayfinder: ${file}: ${repository} is not a git checkout`);
  const kit = path.resolve(root, '..', '..');
  const manifest = path.join(kit, 'package.json');
  if (path.basename(path.dirname(root)) !== HOSTED_DIR || !existsSync(manifest) || JSON.parse(readFileSync(manifest, 'utf8')).name !== KIT_NAME) {
    throw new Error(`wayfinder: ${root} is not in ${HOSTED_DIR}/ of the kit's own repository (${KIT_NAME})`);
  }
  const skillsDir = relativePath(raw.skillsDir ?? '.agents/skills', 'skillsDir');
  const hide = (raw.hide ?? []).map((p, i) => relativePath(p, `hide[${i}]`));
  const include = (raw.include ?? []).map((p, i) => relativePath(p, `include[${i}]`));
  return { root, repository, skillsDir, hide, include, kit };
}

/** The repository's files as its git lists them, tracked only or with untracked files that are not ignored. */
function repositoryFiles(repository, others) {
  const args = ['ls-files', '-z', '--cached', ...(others ? ['--others', '--exclude-standard'] : [])];
  const listed = execFileSync('git', args, { cwd: repository, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 }).split('\0').filter(Boolean);
  return [...new Set(listed)];
}

/** The repository's ignored files the settings `include` (globs), or none. */
function includedFiles(h) {
  if (h.include.length === 0) return [];
  const matchers = h.include.map(globMatcher);
  const args = ['ls-files', '-z', '--others', '--ignored', '--exclude-standard'];
  const ignored = execFileSync('git', args, { cwd: h.repository, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 }).split('\0').filter(Boolean);
  return ignored.filter((file) => !under(file, 'node_modules') && !file.includes('/node_modules/') && matchers.some((m) => m(file)));
}

function walkFiles(dir, rel, out, skip) {
  for (const entry of readdirSync(path.join(dir, rel), { withFileTypes: true })) {
    const at = rel ? `${rel}/${entry.name}` : entry.name;
    if (skip(at, entry)) continue;
    if (entry.isDirectory()) walkFiles(dir, at, out, skip);
    else if (entry.isFile() || entry.isSymbolicLink()) out.push(at);
  }
  return out;
}

/** What the folder should hold copied: a Map of folder path → the absolute path it is copied from. */
function sources(h) {
  const want = new Map();
  const hidden = (file) => OWN.some((p) => under(file, p)) || h.hide.some((p) => under(file, p)) || under(file, h.skillsDir);
  for (const file of [...repositoryFiles(h.repository, true), ...includedFiles(h)]) {
    // A submodule is listed as a path and is a directory: its files are its own repository's.
    const st = lstat(path.join(h.repository, file));
    if (!hidden(file) && st && !st.isDirectory()) want.set(file, path.join(h.repository, file));
  }
  const skills = path.join(h.kit, 'skills');
  for (const file of walkFiles(skills, '', [], () => false)) want.set(`${h.skillsDir}/${file}`, path.join(skills, file));
  return want;
}

function readRecord(root) {
  try {
    return JSON.parse(readFileSync(path.join(root, HOSTED_COPIES), 'utf8')).copies ?? {};
  } catch {
    return {};
  }
}

function writeRecord(root, copies) {
  const sorted = Object.fromEntries(Object.entries(copies).sort(([a], [b]) => (a < b ? -1 : 1)));
  const tmp = path.join(root, `${HOSTED_COPIES}.${process.pid}.tmp`);
  writeFileSync(tmp, `${JSON.stringify({ copies: sorted }, null, 2)}\n`);
  renameSync(tmp, path.join(root, HOSTED_COPIES));
}

/** Whether the file at `abs` is still the copy `entry` recorded: the same size and time, or for a link the same target. */
function untouched(abs, entry) {
  const st = lstat(abs);
  if (!st) return false;
  if (entry.link !== undefined) return st.isSymbolicLink() && readlinkSync(abs) === entry.link;
  return st.isFile() && st.size === entry.size && st.mtimeMs === entry.mtimeMs;
}

/** Copies `from` (a file, or a link as a link) to `abs`, and returns its record. */
function copy(from, abs) {
  mkdirSync(path.dirname(abs), { recursive: true });
  const st = lstatSync(from);
  if (lstat(abs)) unlinkSync(abs);
  if (st.isSymbolicLink()) {
    const link = readlinkSync(from);
    symlinkSync(link, abs);
    return { from, link };
  }
  copyFileSync(from, abs);
  const made = statSync(abs);
  return { from, size: made.size, mtimeMs: made.mtimeMs, fromSize: st.size, fromMtimeMs: st.mtimeMs };
}

/** Removes `abs` and each directory above it, up to `root`, that is left empty. */
function remove(root, abs) {
  try {
    unlinkSync(abs);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  for (let dir = path.dirname(abs); dir !== root && dir.startsWith(root); dir = path.dirname(dir)) {
    try {
      rmdirSync(dir);
    } catch {
      return;
    }
  }
}

/** Removes the links an earlier version made (its record, `.wayfinder-hosted-links.json`), leaving real files. */
function removeLinks(root) {
  const file = path.join(root, HOSTED_LINKS);
  if (!existsSync(file)) return;
  let record = {};
  try {
    record = JSON.parse(readFileSync(file, 'utf8'));
  } catch {
    // An unreadable record: nothing to remove by it.
  }
  for (const at of Object.keys(record.links ?? {}).sort((a, b) => b.length - a.length)) {
    if (lstat(path.join(root, at))?.isSymbolicLink()) unlinkSync(path.join(root, at));
  }
  for (const at of [...(record.dirs ?? [])].sort((a, b) => b.length - a.length)) {
    try {
      rmdirSync(path.join(root, at));
    } catch {
      // Not empty: the instance's files are in it.
    }
  }
  unlinkSync(file);
}

/**
 * Brings the folder's copies up to date with the repository and the kit, and makes the kit's link and the `.git`
 * file. A copy nobody changed follows its source (updated when the source changes, removed when it is gone or hidden);
 * a changed copy, and any file the refresh did not copy, is the instance's own and is never touched. Two refreshes at
 * once (two servers starting together) take turns: a copy written by one must not look changed to the other. Returns
 * `{ copies }`, the record.
 */
export function refreshHosted(folder) {
  const h = readHosted(folder);
  const release = lock(h.root);
  try {
    return refresh(h);
  } finally {
    release();
  }
}

/** Takes the folder's lock, waiting for a refresh beside this one; a lock older than a minute is a crashed run's. */
function lock(root) {
  const at = path.join(root, HOSTED_LOCK);
  const wait = new Int32Array(new SharedArrayBuffer(4));
  for (let tries = 0; ; tries++) {
    try {
      mkdirSync(at);
      return () => rmdirSync(at);
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
      const st = lstat(at);
      if (st && Date.now() - st.mtimeMs > 60_000) {
        try {
          rmdirSync(at);
        } catch {
          // Removed by another run.
        }
      } else if (tries > 1200) throw new Error(`wayfinder: ${at} has been held for a minute; remove it if no refresh is running`);
      Atomics.wait(wait, 0, 0, 50);
    }
  }
}

function refresh(h) {
  const { root } = h;
  removeLinks(root);
  const old = readRecord(root);
  const want = sources(h);
  const copies = {};
  for (const [rel, entry] of Object.entries(old)) {
    const abs = path.join(root, rel);
    if (!untouched(abs, entry)) continue; // changed or removed by the instance: no longer a copy
    const from = want.get(rel);
    if (from === undefined) {
      remove(root, abs);
      continue;
    }
    const src = lstat(from);
    const same = entry.link !== undefined
      ? src?.isSymbolicLink() && readlinkSync(from) === entry.link
      : src?.isFile() && src.size === entry.fromSize && src.mtimeMs === entry.fromMtimeMs;
    copies[rel] = same ? entry : copy(from, abs);
  }
  for (const [rel, from] of want) {
    if (copies[rel] !== undefined || old[rel] !== undefined) continue; // a copy, or one the instance has made its own
    const abs = path.join(root, rel);
    if (lstat(abs)) continue; // the instance's own file
    copies[rel] = copy(from, abs);
  }
  // The kit's link, through which everything the folder imports by the kit's name is the working copy.
  const link = path.join(root, 'node_modules', KIT_NAME);
  mkdirSync(path.dirname(link), { recursive: true });
  const st = lstat(link);
  if (st?.isSymbolicLink() && readlinkSync(link) !== h.kit) unlinkSync(link);
  if (!lstat(link)) {
    try {
      symlinkSync(h.kit, link);
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
    }
  }
  if (!existsSync(path.join(root, '.git'))) writeFileSync(path.join(root, '.git'), GIT_STUB);
  writeRecord(root, copies);
  return { copies };
}

/**
 * The instance's own files, sorted: every file in the folder that is not a copy it still matches (what the
 * onboarding and the skills wrote, and copies changed since), never the settings, the record, the `.git` file or
 * `node_modules` (the kit's link and Vite's cache), nor a file the repository's ignore rules ignore (the app's build
 * output).
 */
export function overlayFiles(folder) {
  const h = readHosted(folder);
  const record = readRecord(h.root);
  const skip = (at, entry) => (!at.includes('/') && OWN.includes(at)) || entry.name.startsWith(`${HOSTED_COPIES}.`) || entry.name.endsWith('.wayfinder-hosted.lock');
  const files = walkFiles(h.root, '', [], skip).filter((file) => !(record[file] && untouched(path.join(h.root, file), record[file])));
  return ignoredBy(h.repository, files, false).sort();
}

/**
 * The folder's files as git would list them in the repository with the instance installed, sorted: the repository's
 * files the folder holds (`git ls-files`, with its untracked files that are not ignored when `others`), the instance's
 * own (`overlayFiles`; each counts as tracked, since the onboarding stages what it writes) and the kit's skills.
 */
export function hostedFiles(folder, { others = true } = {}) {
  const h = readHosted(folder);
  const record = readRecord(h.root);
  const files = new Set();
  for (const file of repositoryFiles(h.repository, others)) if (lstat(path.join(h.root, file))) files.add(file);
  for (const [file, entry] of Object.entries(record)) if (under(file, h.skillsDir) && untouched(path.join(h.root, file), entry)) files.add(file);
  for (const file of overlayFiles(h.root)) files.add(file);
  return [...files].sort();
}

/** `files` (repository paths, which need not exist there) that the repository's ignore rules do (`ignored`) or do not ignore. */
function ignoredBy(repository, files, ignored) {
  if (files.length === 0) return [];
  let out = '';
  try {
    out = execFileSync('git', ['check-ignore', '--no-index', '-z', '--stdin'], { cwd: repository, input: files.join('\0'), encoding: 'utf8' });
  } catch (error) {
    // Status 1: none is ignored.
    if (error.status !== 1) throw error;
  }
  const matched = new Set(out.split('\0').filter(Boolean));
  return files.filter((file) => matched.has(file) === ignored);
}

/** `git ls-files` pathspec matching: a wildcard matches across `/`; a plain path matches itself and what is below it. */
export function matchesPathspec(spec, file) {
  if (/[*?[]/.test(spec)) {
    const source = spec.replace(/[.+^${}()|\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.');
    return new RegExp(`^${source}$`).test(file);
  }
  return under(file, spec.replace(/\/$/, ''));
}

/**
 * `git ls-files <args>` at `root`, which may be a hosted folder: there, the folder's files (`hostedFiles`, with
 * `--others`), narrowed by the pathspecs among `args`. Lines, without the trailing empty one.
 */
export function lsFiles(root, args = []) {
  if (findHosted(root) !== path.resolve(root)) {
    return execFileSync('git', ['ls-files', ...args], { cwd: root, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 }).split('\n').filter(Boolean);
  }
  const specs = args.filter((a) => !a.startsWith('-'));
  const files = hostedFiles(root, { others: args.includes('--others') });
  return specs.length === 0 ? files : files.filter((file) => specs.some((spec) => matchesPathspec(spec, file)));
}

/** The checkout git commands about the repository run in: the hosted repository for a hosted folder, else `root`. */
export function gitRoot(root) {
  return findHosted(root) === path.resolve(root) ? readHosted(root).repository : root;
}
