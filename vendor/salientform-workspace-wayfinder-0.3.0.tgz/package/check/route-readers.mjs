/**
 * Route readers a hooks file's `productRoutes` hook can call (spec WW-M1 §5.1: the route mirror is derived by the route
 * reader in the hooks file). Each reads a router's source as text and returns its absolute paths, `:param` for a
 * parameter, so the hook is a few lines. A router no reader here knows keeps a reader of the repository's own.
 */

/**
 * The absolute paths of every TanStack Router `createRoute` in `source` (code-based routing): each
 * `const name = createRoute({ getParentRoute: () => parent, path: '…' })` is resolved through its parent chain, a pathless
 * layout route (`id: '…'`) adds no segment and is not a page, an index route (`path: '/'`) is its parent's path, and
 * `$param` becomes `:param`. In source order, each path once.
 */
export function tanstackRoutes(source) {
  const parentOf = {};
  const pathOf = {};
  const re = /const (\w+) = createRoute\(\{\s*getParentRoute: \(\) => (\w+),\s*(?:id: ['"][^'"]+['"]|path: ['"]([^'"]+)['"])/g;
  for (const [, name, parent, own] of source.matchAll(re)) {
    parentOf[name] = parent;
    pathOf[name] = own ?? '';
  }
  const absolute = (name, seen = new Set()) => {
    const parent = parentOf[name];
    const own = (pathOf[name] ?? '').replace(/^\/+|\/+$/g, '');
    if (!parent || !(parent in parentOf) || seen.has(parent)) return own ? `/${own}` : '/';
    seen.add(name);
    const base = absolute(parent, seen);
    const joined = `${base === '/' ? '' : base}${own ? `/${own}` : ''}`;
    return joined || '/';
  };
  // An index route (`path: '/'` under a parent) is its parent's path again: listed once.
  return [...new Set(Object.keys(pathOf)
    .filter((name) => pathOf[name] !== '')
    .map((name) => absolute(name).replace(/\$(\w+)/g, ':$1')))];
}
