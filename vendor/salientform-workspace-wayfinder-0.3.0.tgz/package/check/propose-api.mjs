/**
 * The API area's first-run proposals (spec WW-M1 §5, §5.1): the settings of `areas.api` a script reads off the
 * repository, and a draft consumer registry with its derivable fields filled: `method` and `path` from the OpenAPI
 * document, `example` from the path and its parameters, `handler` from the server's route modules, `consumer` from the
 * fetch sites under `callers.roots`, and `status` from whether a consumer was found. `group` starts from the document's
 * tags and `description` from its summary; `assess-api` rewrites both, and writes `note` and `pages`. A later run keeps
 * the judged fields of the registry it finds and recomputes the derivable ones.
 */
import path from 'node:path';
import { documentOperations, tagGroups } from './api-operations.mjs';
import { fixtureRoots, underAny } from './propose-audit.mjs';
import { packageDirs, readJsonFile, readText, unique } from './repo-files.mjs';

const CODE = /\.[cm]?[jt]sx?$/;
const TEST = /\.(test|spec)\.[cm]?[jt]sx?$/;
const isObject = (value) => typeof value === 'object' && value !== null && !Array.isArray(value);

/** The tracked JSON files that are OpenAPI 3 documents (`"openapi": "3…"` near the top). */
export function findOpenApiDocuments(root, files) {
  return files.filter((file) => file.endsWith('.json') && /"openapi"\s*:\s*"3\./.test((readText(root, file) ?? '').slice(0, 2000)));
}

/** The prefix every path of `paths` shares, as whole segments (`/api`), else `/`. */
export function commonBasePath(paths) {
  if (paths.length === 0) return '/';
  const split = paths.map((p) => p.split('/').filter(Boolean));
  const shared = [];
  for (let i = 0; split.every((s) => s.length > i + 1 && s[i] === split[0][i] && !/[{:]/.test(s[i])); i++) shared.push(split[0][i]);
  return shared.length > 0 ? `/${shared.join('/')}` : '/';
}

/** True when a fetched path (a literal, perhaps with `${…}` segments) is the document path `template` (`{id}` segments). */
export function pathMatches(fetched, template) {
  const a = fetched.replace(/\/$/, '').split('/');
  const b = template.replace(/\/$/, '').split('/');
  return a.length === b.length && a.every((seg, i) => seg === b[i] || /^\{[^}]+\}$/.test(b[i]) || /^\$\{[^}]+\}$/.test(seg) || /^:\w+$/.test(seg));
}

/** The name of the function or constant a fetch site at `index` of `source` sits in, or undefined. */
function enclosingName(source, index) {
  const before = source.slice(0, index);
  const re = /(?:^|\n)\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?(?:function\*?\s+([A-Za-z_$][\w$]*)|(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=)/g;
  let name;
  for (const m of before.matchAll(re)) name = m[1] ?? m[2];
  return name;
}

/**
 * The fetch sites in `files`: each `fetch('…')` and `<client>.GET|POST|PUT|PATCH|DELETE('…')` whose path starts with
 * `basePath` (the API check's scan), with its file, its method (a `fetch` call's `method:` option, else GET) and the
 * function it sits in.
 */
export function fetchSiteFiles(root, files, basePath = '/') {
  const base = basePath.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const call = new RegExp(`(?:\\.(GET|POST|PUT|PATCH|DELETE)|\\bfetch)\\(\\s*[\`'"](${base}[^\`'"?]*)`, 'g');
  const sites = [];
  for (const file of files.filter((f) => CODE.test(f) && !TEST.test(f))) {
    const source = readText(root, file) ?? '';
    for (const m of source.matchAll(call)) {
      const option = m[1] ? undefined : /^[^;]*?method\s*:\s*['"`](\w+)['"`]/.exec(source.slice(m.index, m.index + 300))?.[1];
      sites.push({ file, path: m[2], method: m[1] ?? option?.toUpperCase() ?? 'GET', name: enclosingName(source, m.index) });
    }
  }
  return sites;
}

/** A document path with its `{param}`s filled from the parameters' examples, enums or types (`1` for a number). */
export function examplePath(document, apiPath, method) {
  const item = document.paths?.[apiPath] ?? {};
  const params = [...(item.parameters ?? []), ...(item[method.toLowerCase()]?.parameters ?? [])].filter((p) => isObject(p) && p.in === 'path');
  return apiPath.replace(/\{([^}]+)\}/g, (_, name) => {
    const param = params.find((p) => p.name === name) ?? {};
    const schema = param.schema ?? {};
    const value =
      param.example ??
      schema.example ??
      schema.enum?.[0] ??
      (schema.type === 'integer' || schema.type === 'number' ? 1 : schema.format === 'uuid' ? '00000000-0000-0000-0000-000000000000' : name);
    return encodeURIComponent(String(value));
  });
}

/**
 * The file under `candidates` that registers `method` on `apiPath`: a `.<method>('<literal>'` call (Express, Hono,
 * Fastify) or a route object with `method: '<method>'` and `path: '<literal>'` (`createRoute` of `@hono/zod-openapi`),
 * whose literal ends the path, `:param` and `{param}` alike (a router mounted under a prefix registers the tail). The
 * longest literal wins; a tie is no answer.
 */
export function findHandler(root, candidates, method, apiPath) {
  const target = apiPath.replace(/\{(\w+)\}/g, ':$1');
  const m = method.toLowerCase();
  const q = `['"\`]`;
  const patterns = [
    new RegExp(`\\.${m}\\(\\s*${q}([^'"\`]+)${q}`, 'g'),
    new RegExp(`method\\s*:\\s*${q}${m}${q}\\s*,\\s*path\\s*:\\s*${q}([^'"\`]+)${q}`, 'gi'),
    new RegExp(`path\\s*:\\s*${q}([^'"\`]+)${q}\\s*,\\s*method\\s*:\\s*${q}${m}${q}`, 'gi'),
  ];
  let best = { length: 0, files: [] };
  for (const file of candidates) {
    const source = readText(root, file) ?? '';
    for (const [, found] of patterns.flatMap((re) => [...source.matchAll(re)])) {
      const literal = found.replace(/\{(\w+)\}/g, ':$1');
      const tail = literal.replace(/\/$/, '') || '/';
      const matches = tail === '/' ? false : target === tail || target.endsWith(tail.startsWith('/') ? tail : `/${tail}`);
      if (!matches) continue;
      if (tail.length > best.length) best = { length: tail.length, files: [file] };
      else if (tail.length === best.length && !best.files.includes(file)) best.files.push(file);
    }
  }
  return best.files.length === 1 ? best.files[0] : undefined;
}

/** The directory every one of `files` sits in, or undefined. */
function commonDir(files) {
  if (files.length === 0) return undefined;
  const dirs = files.map((f) => path.posix.dirname(f).split('/'));
  const shared = [];
  for (let i = 0; dirs.every((d) => d[i] !== undefined && d[i] === dirs[0][i]); i++) shared.push(dirs[0][i]);
  return shared.length > 0 ? shared.join('/') : undefined;
}

/** The source root a file belongs to: its package's `src`, its package, or its top-level directory. */
function rootOf(file, packages) {
  const pkg = packages.filter((dir) => file.startsWith(`${dir}/`)).sort((a, b) => b.length - a.length)[0];
  if (pkg) return file.startsWith(`${pkg}/src/`) ? `${pkg}/src` : pkg;
  return file.includes('/') ? file.split('/')[0] : '.';
}

/**
 * The draft registry: one row per operation of `document`, in document order, then the existing registry's
 * `outsideDocument` rows. Derived: `method`, `path`, `example`, `handler`, `consumer`, `status`. Kept from `existing`
 * when it has the row: `group`, `description`, `note`, `pages` (only while the row is `used`), and a `stub` status.
 */
export function draftApiRegistry({ root, document, existing, sites, handlerFiles, handlerRoot }) {
  const operations = documentOperations(document);
  const old = new Map((isObject(existing) && Array.isArray(existing.endpoints) ? existing.endpoints : []).map((e) => [`${e.method} ${e.path}`, e]));
  const { groups: tagGroupList, groupOf } = tagGroups(document, operations);
  const groups = isObject(existing) && Array.isArray(existing.groups) ? [...existing.groups] : [];
  const handlers = [];
  const endpoints = operations.map((op) => {
    const before = old.get(op.key);
    const consumers = sites.filter((s) => s.method === op.method && pathMatches(s.path, op.path));
    const handler = findHandler(root, handlerFiles, op.method, op.path) ?? before?.handler;
    if (handler) handlers.push(handler);
    const group = before?.group ?? groupOf(op);
    if (!groups.some((g) => g.id === group)) groups.push(tagGroupList.find((g) => g.id === group) ?? { id: group, label: group });
    const status = consumers.length > 0 ? 'used' : before?.status === 'stub' ? 'stub' : 'unused';
    const row = {
      method: op.method,
      path: op.path,
      ...(handler ? { handler } : {}),
      group,
      description: before?.description ?? op.summary ?? `${op.method} ${op.path}`,
      ...(consumers.length > 0
        ? { consumer: unique(consumers.map((c) => (c.name ? `${c.name}() — ${c.file}` : c.file))).join('; ') }
        : {}),
      ...(status === 'used' && before?.pages ? { pages: before.pages } : {}),
      status,
      ...(before?.note ? { note: before.note } : {}),
      example: examplePath(document, op.path, op.method),
    };
    return row;
  });
  const outside = [...old.values()].filter((e) => e.outsideDocument === true);
  for (const row of outside) if (!groups.some((g) => g.id === row.group)) groups.push({ id: row.group, label: row.group });
  const usedGroups = new Set([...endpoints, ...outside].map((e) => e.group));
  const root_ = existing?.handlerRoot ?? handlerRoot ?? (handlers.length > 1 ? commonDir(handlers) : undefined);
  return {
    ...(root_ ? { handlerRoot: root_ } : {}),
    groups: groups.filter((g) => usedGroups.has(g.id)),
    endpoints: [...endpoints, ...outside],
  };
}

/**
 * The proposal for `areas.api`: `ctx` is `{ root, files, settings, workspaceDir }`.
 * - `document`: the configured one, else the repository's OpenAPI 3 JSON file.
 * - `basePath`: the segments every path shares; `callers.roots`: the source roots of the files that fetch it.
 * - the registry (`--write`): `areas.api.registry`, else `consumer-registry` beside the About manifest.
 * Judged: `generated` (the commands that emit the document), the rows' groups, descriptions, notes and pages, and the
 * rows the document does not describe.
 */
export function proposeApi({ root, files, settings, workspaceDir }) {
  const api = settings?.areas?.api;
  const configured = api && !api.placeholder ? api : undefined;
  const skip = [...fixtureRoots(files), ...(workspaceDir ? [`${workspaceDir}/`] : []), 'node_modules/'];
  const own = files.filter((file) => !underAny(file, skip));
  const found = findOpenApiDocuments(root, own);
  const documentFile = configured?.document ?? found[0];
  const notes = found.length > 1 ? [`${found.length} OpenAPI documents: ${found.join(', ')}; the first is proposed`] : [];
  if (!documentFile)
    return {
      summary: 'no OpenAPI 3 JSON document: keep the placeholder',
      entries: [],
      judged: [{ setting: 'areas.api.placeholder', rule: 'say where an OpenAPI document was looked for (tracked *.json with "openapi": "3…")' }],
      notes,
      writes: [],
    };
  const document = readJsonFile(root, documentFile) ?? {};
  const operations = documentOperations(document);
  const basePath = configured?.basePath ?? commonBasePath(operations.map((op) => op.path));
  const packages = packageDirs(own);
  const code = own.filter((f) => CODE.test(f) && !TEST.test(f));
  const allSites = fetchSiteFiles(root, code, basePath);
  const roots = configured?.callers?.roots ?? unique(allSites.map((s) => rootOf(s.file, packages))).sort();
  const sites = allSites.filter((s) => roots.some((r) => s.file.startsWith(`${r}/`)));
  const existingFile = configured?.registry;
  const existing = existingFile ? readJsonFile(root, existingFile) : undefined;
  const handlerRoot = existing?.handlerRoot;
  // The server's route modules: under the registry's handlerRoot, else every file outside the callers' roots.
  const handlerFiles = code.filter((f) => (handlerRoot ? f.startsWith(`${handlerRoot}/`) : !roots.some((r) => f.startsWith(`${r}/`))));
  const registry = draftApiRegistry({ root, document, existing, sites, handlerFiles, handlerRoot });
  const registryFile = existingFile ?? (workspaceDir ? `${workspaceDir}/src/api-endpoints.json` : 'api-endpoints.json');
  const used = registry.endpoints.filter((e) => e.status === 'used').length;
  const entries = [
    { setting: 'areas.api.document', value: documentFile, from: configured?.document ? 'the config' : 'the OpenAPI 3 JSON document found' },
    { setting: 'areas.api.registry', value: registryFile, from: existingFile ? 'the config' : 'beside the About manifest' },
    { setting: 'areas.api.basePath', value: basePath, from: configured?.basePath ? 'the config' : 'the segments every path shares' },
    { setting: 'areas.api.callers.roots', value: roots, from: configured?.callers?.roots ? 'the config' : `the source roots of the ${allSites.length} fetch sites` },
  ];
  for (const row of registry.endpoints) if (!row.handler && !row.outsideDocument) notes.push(`no handler found: ${row.method} ${row.path}`);
  return {
    summary: `${operations.length} operations in ${documentFile}, ${used} used, ${sites.length} fetch sites`,
    entries,
    judged: [
      { setting: 'areas.api.generated', rule: 'the commands that emit the document and any wire types generated from it, with the script that fixes each' },
      { setting: 'groups, description, note, pages', rule: 'the sections the page reads best in, one clause on what each row returns, and the pages reachable from navigation that use its consumer' },
      { setting: 'outsideDocument', rule: 'a row per route the server serves that the document does not describe (a health check, an auth library\'s routes)' },
    ],
    notes,
    writes: [{ file: registryFile, text: `${JSON.stringify(registry, null, 2)}\n`, what: `the consumer registry: ${registry.endpoints.length} rows, ${used} used` }],
  };
}
