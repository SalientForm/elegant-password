export const ABOUT_DEFAULTS: { readonly skillsDir: string; readonly skillLinks: readonly string[]; readonly checkScript: string };
export const AUDIT_DEFAULTS: {
  readonly specDirs: readonly string[];
  readonly reviews: string;
  readonly ignore: readonly string[];
  readonly linkExempt: readonly string[];
};
/** The problems of `skillLinks` beside `skillsDir`: repository-relative, not `skillsDir` or inside it, no repeats. */
export function skillLinksProblems(skillsDir: unknown, skillLinks: unknown, at?: string): string[];
/** `about` with its defaults applied; throws on a `skillsDir` or `skillLinks` that breaks `skillLinksProblems`. */
export function aboutSettings<T extends object>(
  about: T
): T & { skillsDir: string; skillLinks: readonly string[]; checkScript: string };
/** The Audit area's required settings, each with what it is. */
export const AUDIT_REQUIRED: readonly (readonly [setting: 'roadmap' | 'todo' | 'architecture' | 'phaseKinds' | 'todoAreas' | 'idPrefix', what: string])[];
/** `audit` with its defaults applied; throws on `ledger` or `documents`, and on a missing required setting. */
export function auditSettings<T extends object>(
  audit: T
): T & { specDirs: readonly string[]; reviews: string; ignore: readonly string[]; linkExempt: readonly string[] };
/** The command that runs a root package.json script, from its `packageManager` field. */
export function scriptCommand(packageJson: { packageManager?: string } | undefined, script: string): string;
/** The six areas every workspace has, by their keys in `settings.areas`, in header order. */
export const WORKSPACE_AREAS: readonly string[];
/** The areas that may be a placeholder: Features, API, Platform Docs. */
export const PLACEHOLDER_AREAS: readonly string[];
/** The problems of `value` as a placeholder (`{ reason, toFill }`, two non-empty strings); `at` names it. */
export function placeholderProblems(value: unknown, at: string): string[];
/** True when `area` is a placeholder area; throws on an invalid placeholder or one beside the real area's settings. */
export function isPlaceholderArea(area: unknown, at: string): boolean;
/** `placeholder: <where> — <reason> To fill: <toFill>`, as the checks print it. */
export function describeSettingsPlaceholder(where: string, placeholder: { reason: string; toFill: string }): string;
/** The Features area's coverage section without coverage settings. */
export const NO_COVERAGE: { readonly reason: string; readonly toFill: string };
/** The Audit area's Features page without a feature audit. */
export const NO_FEATURE_AUDIT: { readonly reason: string; readonly toFill: string };
