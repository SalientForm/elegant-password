export type PhaseStatus = 'not started' | 'specified' | 'planned' | 'in progress';

export interface Phase {
  /** `ACME-M2.4` */
  id: string;
  /** `ACME-M2` */
  milestoneId: string;
  title: string;
  status: PhaseStatus;
  /** One of the configured phase kinds (`settings.areas.audit.phaseKinds`). */
  kind: string;
  goal: string;
  notInScope?: string;
  /** Phase IDs and free-text external conditions, as written. */
  dependsOn: string[];
  spec?: string;
  /** The current plan: the first of `plans`. */
  plan?: string;
  /** Every plan the phase names, in the order they run (a phase may need several, one after another). */
  plans?: string[];
  /** The section's markdown minus the Status / Kind / Depends on / Spec / Plan bullets. */
  body: string;
}
export interface Milestone { id: string; title: string; summary: string; phases: Phase[] }
export interface CompletedPhase { id: string; title: string; shipped: string; ref?: string }
/** A row under "Outside the roadmap": work that aligns with no milestone. */
export interface OutsideRow { id: string; title: string; spec?: string; plan?: string }
export interface Roadmap {
  reviewedAt: string;
  sequence: string[];
  milestones: Milestone[];
  completed: CompletedPhase[];
  /** NaN when the "Outside the roadmap" section is absent. */
  nextX: number;
  outside: OutsideRow[];
}

export interface Todo {
  /** `ACME-12`: the prefix and the number. */
  id: string;
  /** 12: what `Next ID` counts. */
  number: number;
  title: string;
  /** One of the configured TODO areas (`settings.areas.audit.todoAreas`). */
  area: string;
  /** A repository path, or a value `isTodoPath` rejects (`idea`, a configured prefix such as `feature-audit:<slug>`). */
  source: string;
  added: string;
  body: string;
}
export interface TodoList { reviewedAt: string; nextId: number; todos: Todo[] }

export interface StackItem { area: string; item: string; planned: boolean; note?: string; ref?: string }
export interface StackSummary { reviewedAt: string; areas: string[]; items: StackItem[] }

/** A roadmap's house convention: the values a phase's `Kind:` may take. `settings.areas.audit` satisfies it. */
export interface RoadmapConventions {
  phaseKinds: readonly string[];
  /** The prefix every id carries (`settings.areas.audit.idPrefix`): `ACME` gives `ACME-M1`, `ACME-M1.2` and `ACME-X3`. */
  idPrefix: string;
  /** The file's name in error messages. Default 'ROADMAP.md'. */
  file?: string;
}
/** A TODO list's house convention: the values an entry's `Area:` may take. `settings.areas.audit` satisfies it. */
export interface TodoConventions {
  todoAreas: readonly string[];
  /** The prefix every id carries (`settings.areas.audit.idPrefix`): `ACME` gives `ACME-12`. */
  idPrefix: string;
  /** The file's name in error messages. Default 'TODO.md'. */
  file?: string;
}

export const PHASE_STATUSES: readonly PhaseStatus[];
/** An id prefix: upper-case letters and digits, starting with a letter. */
export const ID_PREFIX: RegExp;
/** The id forms of one prefix; each pattern matches a whole id and captures its numbers. */
export interface IdPatterns {
  prefix: string;
  /** `<P>-M<n>` */
  milestone: RegExp;
  /** `<P>-M<n>.<k>` */
  phase: RegExp;
  /** `<P>-X<n>` */
  x: RegExp;
  /** `<P>-<n>`, a TODO entry */
  todo: RegExp;
  /** A milestone, a phase or an X id. */
  roadmap: RegExp;
}
/** Throws a TypeError for a prefix that is not `ID_PREFIX`. */
export function idPatterns(prefix: string): IdPatterns;
/** Initials of `name`'s words (`workspace-wayfinder` → `WW`), or its first three letters when it is one word. */
export function suggestIdPrefix(name: string): string;

/** What the parsers throw: every problem of the file, so one run of a check names them all. */
export interface ParseProblems extends Error {
  problems: string[];
}

/**
 * Throws on malformed input or when validateRoadmap reports problems: one Error naming every problem of the file,
 * `<file>:<line>: …` for a line and `<file>: …` for the whole file, joined with '; ' in its message and listed in its
 * `problems` (`ParseProblems`). A TypeError when `phaseKinds` is missing or empty.
 */
export function parseRoadmap(markdown: string, conventions: RoadmapConventions): Roadmap;
/** Throws like parseRoadmap; a TypeError when `todoAreas` is missing or empty. */
export function parseTodos(markdown: string, conventions: TodoConventions): TodoList;
/** Throws like parseRoadmap. */
export function parseStackSummary(markdown: string, options?: { file?: string }): StackSummary;
/** Phase IDs named by the bullets under "## Planned migrations" in the architecture document. Throws like parseRoadmap. */
export function parsePlannedMigrations(markdown: string, options: { file?: string; idPrefix: string }): string[];
/** The text of the `## <title>` section (heading excluded; a leading "<n>. " allowed), or null when there is none. */
export function sectionText(markdown: string, title: string): string | null;
/**
 * Whether a TODO `Source:` names a repository path. `todoSources` are the values that do not: an exact value, or a
 * prefix ending in ':'. Default ['idea'].
 */
export function isTodoPath(source: string, todoSources?: readonly string[]): boolean;
export function validateRoadmap(roadmap: Roadmap, idPrefix: string): string[];
export function validateTodos(list: TodoList): string[];
