/**
 * The Features area's first-run proposals (spec WW-M1 §5): the settings of `areas.features` a script reads off the
 * repository, and the route mirror, built whole from the hooks file's `productRoutes`. `assess-features` writes the
 * settings into the workspace config and judges the rest: the catalogue, `tests.infrastructure`, the hook itself.
 */
import { globMatcher } from './features.mjs';
import { fixtureRoots, underAny } from './propose-audit.mjs';
import { matchingGlobs, packageDirs, readText, testRunners, unique, within } from './repo-files.mjs';

const CODE = /\.[cm]?[jt]sx?$/;
const TEST = /\.(test|spec)\.[cm]?[jt]sx?$/;

/** The route mirror's JSON, as the Features area reads it: `routes`, then `sidebar` when the hook returns one. */
export function routeMirrorText({ routes, sidebar }) {
  return `${JSON.stringify(sidebar === undefined ? { routes } : { routes, sidebar }, null, 2)}\n`;
}

/**
 * The proposal for `areas.features` and `productRoutes`: `ctx` is `{ root, files, settings, hooks, workspaceDir }`.
 * - `tests.include`: the globs of the repository's test runners (`testRunners`) that match a file (a file two globs
 *   match is listed once); `tests.playwright`: the files those globs give Playwright that do not import
 *   `@playwright/test`.
 * - `coverage.summaries`: each Vitest config's `json-summary` file; none without one, and the coverage is the kit's
 *   placeholder.
 * - `sourceRoots`: the `src` directory of each package (the root's included) that has code outside its tests.
 * - `directory`: the catalogue's directory, the config's when it names one, else `docs/features`.
 * - `productRoutes`: the mirror's path; with the hook, `--write` writes it from the hook.
 * Judged: `tests.infrastructure`, the catalogue's features, and a `productRoutes` hook where there is none.
 */
export function proposeFeatures({ root, files, settings, hooks = {}, workspaceDir }) {
  const skip = [...fixtureRoots(files), ...(workspaceDir ? [`${workspaceDir}/`] : [])];
  const own = files.filter((file) => !underAny(file, skip));
  const runners = testRunners(root, own, { exclude: workspaceDir });
  const entries = [];
  const notes = [];
  const writes = [];

  const tests = own.filter((file) => TEST.test(file));
  const include = matchingGlobs(unique(runners.flatMap((r) => r.include)), tests);
  for (const runner of runners)
    for (const glob of runner.include)
      if (!include.includes(glob)) notes.push(`${runner.config}: ${glob} matches no test file, so it is left out`);
  entries.push({
    setting: 'areas.features.tests.include',
    value: include,
    from: runners.length > 0 ? unique(runners.map((r) => r.config)).join(', ') : 'no test runner config',
  });
  const playwrightGlobs = runners.filter((r) => r.runner === 'playwright').flatMap((r) => r.include);
  if (playwrightGlobs.length > 0) {
    const matches = playwrightGlobs.map(globMatcher);
    const fixtures = tests.filter((file) => matches.some((m) => m(file)) && !/@playwright\/test/.test(readText(root, file) ?? ''));
    if (fixtures.length > 0)
      entries.push({ setting: 'areas.features.tests.playwright', value: fixtures, from: 'Playwright tests that import a fixtures module' });
  }

  const summaries = unique(runners.filter((r) => r.coverage).map((r) => r.coverage));
  if (summaries.length > 0)
    entries.push({ setting: 'areas.features.coverage.summaries', value: summaries, from: 'the Vitest configs\' json-summary reporters' });
  else notes.push('no test config writes a json-summary coverage report: leave coverage unset, and the kit shows it as a placeholder');

  const dirs = ['', ...packageDirs(own)].filter((dir) => !within(dir, workspaceDir));
  const sourceRoots = dirs
    .map((dir) => (dir ? `${dir}/src` : 'src'))
    .filter((src) => own.some((file) => file.startsWith(`${src}/`) && CODE.test(file) && !TEST.test(file)));
  entries.push({ setting: 'areas.features.sourceRoots', value: sourceRoots, from: 'each package\'s src directory' });
  const directory = settings?.areas?.features?.directory;
  entries.push({ setting: 'areas.features.directory', value: directory ?? 'docs/features', from: directory ? 'the config' : 'the kit\'s default: one markdown file per feature' });

  const mirror = settings?.productRoutes ?? (workspaceDir ? `${workspaceDir}/src/product-routes.json` : 'product-routes.json');
  if (hooks.productRoutes) {
    const read = hooks.productRoutes({ settings, repoRoot: root, readRepo: (file) => readText(root, file), exists: (file) => readText(root, file) !== undefined });
    entries.push({ setting: 'productRoutes', value: mirror, from: `the hooks file's productRoutes (${read.source ?? 'the router'})` });
    writes.push({ file: mirror, text: routeMirrorText(read), what: `the route mirror: ${read.routes.length} routes${read.sidebar ? `, ${read.sidebar.length} sidebar paths` : ''}` });
  } else
    notes.push(
      'no productRoutes hook: write one in the hooks file that reads the product\'s router (tanstackRoutes in the kit\'s check/route-readers.mjs reads a TanStack createRoute tree), then run this again',
    );

  const generated = include.length > 0 || hooks.productRoutes !== undefined;
  return {
    summary: `${runners.length} test runners, ${tests.length} test files, ${sourceRoots.length} source roots${generated ? '' : ': nothing for the area yet, keep its placeholder'}`,
    entries,
    judged: [
      { setting: 'areas.features.tests.infrastructure', rule: 'the tests of tooling, the platform and shared code, which no feature owns; never a feature\'s test' },
      { setting: 'the catalogue', rule: 'one file per feature in the directory: one per route group of the mirror, and one per feature without a route' },
      { setting: 'areas.features.reviewedAt', rule: 'today, once the catalogue is written' },
      { setting: 'areas.features.sourceRoots', rule: 'narrow each root to the product\'s pages and libraries where the package holds more' },
    ],
    notes,
    writes,
  };
}
