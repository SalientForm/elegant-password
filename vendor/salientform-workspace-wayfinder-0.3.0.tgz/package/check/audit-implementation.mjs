/**
 * The Audit implementation drift check (spec M12.8 §5.6): the roadmap, the TODO list and the architecture document's
 * Stack summary and Planned migrations, all named in settings.areas[slug] with the conventions they are parsed with.
 * Plain node; the kit's runner loads the settings, runs these rules and the spec ledger's (audit-ledger.mjs) over
 * the parsed data this returns.
 *
 * All three files are required; a rule that reads a file that did not parse is skipped, its problem
 * reported once.
 *
 * Fails when:
 *  - a file does not exist, does not parse, or breaks its structural rules (audit-markdown.mjs)
 *  - the architecture document lacks one of the sections ARCHITECTURE_SECTIONS names, or one is empty (a placeholder
 *    is content)
 *  - the roadmap has no open milestone and no placeholder saying why, or a placeholder in a Sequence that lists phases;
 *    the TODO list has a placeholder beside an entry
 *  - a phase Spec / Plan, a Completed ref, an Outside the roadmap Spec / Plan, a TODO path Source or a stack Ref path
 *    does not exist
 *  - a stack Ref or a Planned migrations bullet names an id that is not in the roadmap, or a planned stack row names a
 *    phase that is not open
 *  - a file's "Reviewed:" line fails the date rule
 */
import { exists, modifiedDateRule, readRepo } from './index.mjs';
import { NO_FEATURE_AUDIT, auditSettings } from './settings-defaults.mjs';
import {
  idPatterns,
  isTodoPath,
  parsePlannedMigrations,
  parseRoadmap,
  parseStackSummary,
  parseTodos,
  sectionText,
} from './audit-markdown.mjs';
import { PLACEHOLDER_REASON } from './document-set.mjs';

const PATH_KEYS = ['roadmap', 'todo', 'architecture'];

/**
 * The architecture document's sections besides Stack summary and Planned migrations (which its parsers require): each
 * must exist and hold something, a placeholder at the least (`docs/formats.md`, "The architecture document").
 */
export const ARCHITECTURE_SECTIONS = ['Overview', 'Repository layout', 'Running it', 'Deployment'];

/** True when `text` holds a placeholder's reason line. */
const hasPlaceholder = (text) => text.split('\n').some((l) => l.startsWith(PLACEHOLDER_REASON));

/**
 * Runs the implementation-page rules over `settings` (the workspace config's data half); `slug` is the area's key in
 * `settings.areas`. Returns { problems, paths, roadmap, todos, stack, plannedMigrations, summary }. A file that is
 * missing or does not parse is null, and the rules that need it are skipped (its problem is already reported).
 */
export function checkAuditImplementation(settings, { slug = 'audit' } = {}) {
  const raw = settings.areas[slug];
  if (!raw) throw new Error(`wayfinder: settings.areas.${slug} is not configured`);
  const area = auditSettings(raw);
  for (const key of PATH_KEYS)
    if (area[key] !== undefined && (typeof area[key] !== 'string' || area[key] === ''))
      throw new Error(`wayfinder: settings.areas.${slug}.${key} is not a repository path`);
  for (const key of ['phaseKinds', 'todoAreas'])
    if (area[key] !== undefined && !Array.isArray(area[key])) throw new Error(`wayfinder: settings.areas.${slug} has no ${key} list`);
  const paths = Object.fromEntries(PATH_KEYS.map((key) => [key, area[key]]));
  const problems = [];

  /** Parse a file, or record why not and return null. */
  const parsed = (file, parse) => {
    if (!exists(file)) {
      problems.push(`missing: ${file} does not exist`);
      return null;
    }
    try {
      return parse(readRepo(file));
    } catch (e) {
      // Every problem of the file, one line each (the parsers collect them all).
      for (const p of e.problems ?? [e.message]) problems.push(`malformed: ${p}`);
      return null;
    }
  };
  const roadmap = parsed(paths.roadmap, (md) => parseRoadmap(md, { ...area, file: paths.roadmap }));
  const todos = parsed(paths.todo, (md) => parseTodos(md, { ...area, file: paths.todo }));
  const stack = parsed(paths.architecture, (md) => parseStackSummary(md, { file: paths.architecture }));
  const plannedMigrations = parsed(paths.architecture, (md) => parsePlannedMigrations(md, { file: paths.architecture, idPrefix: area.idPrefix }));
  const ids = idPatterns(area.idPrefix);

  const openPhases = roadmap ? roadmap.milestones.flatMap((m) => m.phases) : [];
  const roadmapIds = new Set(
    roadmap ? [...roadmap.milestones.map((m) => m.id), ...openPhases.map((p) => p.id), ...roadmap.completed.map((c) => c.id)] : []
  );
  const ROADMAP = paths.roadmap, TODO = paths.todo, ARCH = paths.architecture;

  for (const p of openPhases) {
    for (const [label, file] of [['Spec', p.spec], ...(p.plans ?? []).map((f) => ['Plan', f])]) {
      if (file && !exists(file)) problems.push(`missing: ${ROADMAP} ${p.id} ${label} ${file} does not exist`);
    }
  }
  for (const c of roadmap ? roadmap.completed : []) {
    if (c.ref && !exists(c.ref)) problems.push(`missing: ${ROADMAP} Completed ${c.id} ref ${c.ref} does not exist`);
  }
  for (const o of roadmap ? roadmap.outside : []) {
    for (const [label, file] of [['Spec', o.spec], ['Plan', o.plan]]) {
      if (file && !exists(file)) problems.push(`missing: ${ROADMAP} ${o.id} ${label} ${file} does not exist`);
    }
  }
  for (const t of todos ? todos.todos : []) {
    if (isTodoPath(t.source, area.todoSources) && !exists(t.source)) problems.push(`missing: ${TODO} ${t.id} Source ${t.source} does not exist`);
  }
  for (const item of stack ? stack.items : []) {
    if (!item.ref || item.ref.startsWith('§')) continue;
    if (ids.phase.test(item.ref) || ids.milestone.test(item.ref)) {
      if (!roadmap) continue;
      if (!roadmapIds.has(item.ref)) problems.push(`stale: ${ARCH} stack row "${item.item}" Ref ${item.ref} is not in ${ROADMAP}`);
      else if (item.planned && !openPhases.some((p) => p.id === item.ref || p.milestoneId === item.ref)) {
        problems.push(`stale: ${ARCH} stack row "${item.item}" is planned but ${item.ref} is not open — mark it current`);
      }
    } else if (!exists(item.ref)) problems.push(`missing: ${ARCH} stack row "${item.item}" Ref ${item.ref} does not exist`);
  }
  for (const id of roadmap ? plannedMigrations ?? [] : []) {
    if (!openPhases.some((p) => p.id === id)) problems.push(`stale: ${ARCH} Planned migrations names ${id}, which is not an open phase in ${ROADMAP}`);
  }

  // The architecture document's other sections, and the placeholders of an empty roadmap and TODO list.
  if (stack) {
    const markdown = readRepo(ARCH);
    for (const title of ARCHITECTURE_SECTIONS) {
      const text = sectionText(markdown, title);
      if (text === null) problems.push(`missing: ${ARCH} has no "## ${title}" section (a placeholder, if nothing can be said yet)`);
      else if (text.trim() === '') problems.push(`missing: ${ARCH} "## ${title}" is empty (a placeholder, if nothing can be said yet)`);
    }
  }
  if (roadmap) {
    const sequence = sectionText(readRepo(ROADMAP), 'Sequence') ?? '';
    if (roadmap.milestones.length === 0 && !hasPlaceholder(sequence))
      problems.push(`missing: ${ROADMAP} has no open milestone and no placeholder under Sequence saying why`);
    if (roadmap.sequence.length > 0 && hasPlaceholder(sequence))
      problems.push(`stale: ${ROADMAP} Sequence lists phases beside a placeholder — remove the placeholder`);
  }
  if (todos && todos.todos.length > 0 && hasPlaceholder(readRepo(TODO)))
    problems.push(`stale: ${TODO} has entries beside a placeholder — remove the placeholder`);

  for (const file of [ROADMAP, TODO, ARCH]) {
    if (!exists(file)) continue;
    const m = /^Reviewed: (\d{4}-\d{2}-\d{2})$/m.exec(readRepo(file));
    if (!m) problems.push(`${file}: missing "Reviewed: YYYY-MM-DD" line`);
    else modifiedDateRule(problems, `${file}: Reviewed`, m[1]);
  }

  const summary = `${openPhases.length} open phases, ${todos ? todos.todos.length : 0} todos, ${stack ? stack.items.length : 0} stack rows`;
  // Audit's Features page is a placeholder without a feature audit.
  const placeholders = area.featureAudit === undefined ? [{ where: `${slug} Features`, ...NO_FEATURE_AUDIT }] : [];
  return { problems, placeholders, paths, roadmap, todos, stack, plannedMigrations, summary };
}
