/**
 * The test inventory (spec M13 §6.1, plan M13.2 § The inventory): every test file the Features area's
 * `tests.include` globs match, parsed statically with oxc-parser (whatever TypeScript the repository uses, 7
 * included) into describe paths, titles, lines, modifiers and Playwright tags. Plain node, so the area's Vite plugin and the
 * catalogue check build the same inventory; the browser never loads this file. Types: test-inventory.d.mts.
 */
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { parseSync } from 'oxc-parser';
import { scanFeatureSources } from './feature-scan.mjs';
import { globMatcher } from './features.mjs';

/** The identifiers a test or describe call starts from. */
const ROOTS = new Set(['describe', 'suite', 'it', 'test']);
const DESCRIBES = new Set(['describe', 'suite']);
const MODIFIERS = new Set(['skip', 'only', 'todo', 'fixme']);
/** Members that make a call something other than a test or describe: hooks, fixtures, steps and annotations. */
const NOT_TESTS = new Set([
  'step',
  'use',
  'extend',
  'configure',
  'info',
  'slow',
  'setTimeout',
  'beforeEach',
  'afterEach',
  'beforeAll',
  'afterAll',
  'expect',
]);
/** Array methods whose callback runs once per element: a test declared inside one is parameterised. */
const ITERATORS = new Set(['forEach', 'map', 'flatMap']);
const TITLE_TAG = /(?:^|\s)(@[\w:.-]+)/g;

/** A node's child nodes, in source order: every property holding a node or a list of nodes. */
function children(node) {
  const out = [];
  for (const key in node) {
    if (key === 'parent') continue;
    const value = node[key];
    if (Array.isArray(value)) {
      for (const item of value) if (item && typeof item.type === 'string') out.push(item);
    } else if (value && typeof value.type === 'string') out.push(value);
  }
  return out.sort((a, b) => a.start - b.start);
}

/** Calls `fn(node, parent)` on `node` and every node below it, parents first. */
function walkTree(node, fn, parent = undefined) {
  fn(node, parent);
  for (const child of children(node)) walkTree(child, fn, node);
}

const isString = (node) => node?.type === 'Literal' && typeof node.value === 'string';
const isPlainTemplate = (node) => node?.type === 'TemplateLiteral' && node.expressions.length === 0;
const isFunction = (node) => node?.type === 'ArrowFunctionExpression' || node?.type === 'FunctionExpression';
/** A member's name: `a.b` → 'b'; undefined for `a[b]`. */
const memberName = (node) => (node.type === 'MemberExpression' && !node.computed && node.property.type === 'Identifier' ? node.property.name : undefined);

/**
 * The member chain of a call's callee, root first (`test.describe.serial` → ['test', 'describe', 'serial']), and
 * whether it is curried (`test.each(table)(…)`, `it.skipIf(c)(…)`, `` it.each`…`(…) ``); null when it does not start
 * at an identifier.
 */
function chainOf(callee) {
  const names = [];
  let curried = false;
  let node = callee;
  for (;;) {
    if (node.type === 'MemberExpression') {
      const name = memberName(node);
      if (name === undefined) return null;
      names.unshift(name);
      node = node.object;
    } else if (node.type === 'CallExpression') {
      curried = true;
      node = node.callee;
    } else if (node.type === 'TaggedTemplateExpression') {
      curried = true;
      node = node.tag;
    } else if (node.type === 'Identifier') {
      names.unshift(node.name);
      return { names, curried };
    } else return null;
  }
}

/** A literal's text as written; any other expression as its source (a template keeps its `${…}`). */
function titleOf(node, source) {
  if (isString(node)) return node.value;
  if (isPlainTemplate(node)) return node.quasis[0].value.cooked ?? node.quasis[0].value.raw;
  const text = source.slice(node.start, node.end);
  return node.type === 'TemplateLiteral' ? text.slice(1, -1) : text;
}

/** The text of a string or a template without `${…}`; undefined for anything else. */
const literalText = (node) => (isString(node) ? node.value : isPlainTemplate(node) ? node.quasis[0].value.cooked ?? node.quasis[0].value.raw : undefined);

/** Tags from a Playwright details object's `tag`: a string or a list of strings. */
function optionTags(node) {
  if (node?.type !== 'ObjectExpression') return [];
  const tag = node.properties.find(
    (p) => p.type === 'Property' && ((p.key.type === 'Identifier' && p.key.name === 'tag') || literalText(p.key) === 'tag')
  );
  if (!tag) return [];
  const value = tag.value;
  const literal = (n) => (literalText(n) === undefined ? [] : [literalText(n)]);
  return value.type === 'ArrayExpression' ? value.elements.filter(Boolean).flatMap(literal) : literal(value);
}

/** `@tokens` in a title, which Playwright reads as tags. */
const titleTags = (title) => [...title.matchAll(TITLE_TAG)].map((m) => m[1]);

/**
 * What a call declares: a describe (with a body), a test (with a body, or `.todo` with a title), or nothing (a hook,
 * a step, `test.skip(condition)` inside a test, any other call).
 */
function classify(call) {
  const chain = chainOf(call.callee);
  if (!chain || !ROOTS.has(chain.names[0])) return null;
  const { names, curried } = chain;
  if (names.some((n) => NOT_TESTS.has(n))) return null;
  const describe = DESCRIBES.has(names[0]) || names.includes('describe');
  const modifier = names.find((n) => MODIFIERS.has(n));
  const args = call.arguments;
  const body = args.length > 0 && isFunction(args[args.length - 1]);
  const titled = args.length > 0 && !isFunction(args[0]);
  const parameterised = curried && (names.includes('each') || names.includes('for'));
  if (describe) return body ? { kind: 'describe', modifier, titled, parameterised } : null;
  if (!titled) return null;
  if (!body && !(modifier === 'todo' || args.length === 1)) return null;
  return { kind: 'test', modifier, parameterised };
}

const LOOPS = new Set(['ForStatement', 'ForOfStatement', 'ForInStatement', 'WhileStatement', 'DoWhileStatement']);

/** A node that runs its body more than once: a loop, or a callback of forEach, map or flatMap. */
function repeats(node, parent) {
  if (LOOPS.has(node.type)) return true;
  return isFunction(node) && parent?.type === 'CallExpression' && ITERATORS.has(memberName(parent.callee) ?? '');
}

/**
 * The path a `goto` argument opens (plan M13.3): a literal as written, a template's `${…}` as a `:param` segment,
 * without the query or fragment; undefined for anything else, or a path not starting with '/'.
 */
function visitedPath(node) {
  let text;
  if (isString(node)) text = node.value;
  else if (node.type === 'TemplateLiteral')
    text = node.quasis.map((q, i) => (i === 0 ? '' : ':param') + (q.value.cooked ?? q.value.raw)).join('');
  else return undefined;
  const opened = text.split(/[?#]/)[0];
  return opened.startsWith('/') ? opened : undefined;
}

/**
 * Where a Playwright file's code navigates: `visitsOf(node)` is every path a `*.goto(…)` under `node` opens, and those
 * of the same-file functions it calls by name, transitively. `hooksOf(statements)` is what the `beforeEach` hooks
 * among `statements` open.
 */
function navigation(program) {
  const direct = (node) => {
    const visits = [];
    const calls = [];
    walkTree(node, (n) => {
      if (n.type !== 'CallExpression') return;
      if (memberName(n.callee) === 'goto' && n.arguments[0]) {
        const opened = visitedPath(n.arguments[0]);
        if (opened) visits.push(opened);
      }
      if (n.callee.type === 'Identifier') calls.push(n.callee.name);
    });
    return { visits, calls };
  };
  const helpers = new Map();
  walkTree(program, (n) => {
    if (n.type === 'FunctionDeclaration' && n.id && n.body) helpers.set(n.id.name, direct(n.body));
    else if (n.type === 'VariableDeclarator' && n.id.type === 'Identifier' && isFunction(n.init)) helpers.set(n.id.name, direct(n.init.body));
  });
  const resolve = (name, seen) => {
    const helper = helpers.get(name);
    if (!helper || seen.has(name)) return [];
    seen.add(name);
    return [...helper.visits, ...helper.calls.flatMap((call) => resolve(call, seen))];
  };
  const visitsOf = (node) => {
    const { visits, calls } = direct(node);
    const seen = new Set();
    return [...visits, ...calls.flatMap((call) => resolve(call, seen))];
  };
  const hooksOf = (statements) =>
    statements.flatMap((statement) => {
      if (statement.type !== 'ExpressionStatement' || statement.expression.type !== 'CallExpression') return [];
      const chain = chainOf(statement.expression.callee);
      // test.beforeEach(…), or a bare beforeEach(…).
      if (!chain?.names.includes('beforeEach')) return [];
      return statement.expression.arguments.filter(isFunction).flatMap(visitsOf);
    });
  return { visitsOf, hooksOf };
}

const statementsOf = (fn) => (fn.body.type === 'BlockStatement' ? [...fn.body.body] : []);

/** The runner a file's imports name: Playwright, node:test, or Vitest by default. */
function runnerOf(program, playwright) {
  if (playwright) return 'playwright';
  const sources = program.body.filter((s) => s.type === 'ImportDeclaration').map((s) => s.source.value);
  if (sources.includes('@playwright/test')) return 'playwright';
  if (sources.includes('node:test')) return 'node';
  return 'vitest';
}

/** `offset` (UTF-16, as the parser gives it) → its 1-based line. */
function lineFinder(source) {
  const starts = [0];
  for (let i = 0; i < source.length; i += 1) if (source[i] === '\n') starts.push(i + 1);
  return (offset) => {
    let low = 0;
    let high = starts.length - 1;
    while (low < high) {
      const mid = (low + high + 1) >> 1;
      if (starts[mid] <= offset) low = mid;
      else high = mid - 1;
    }
    return low + 1;
  };
}

/**
 * One test file's tests, in source order, from `source`. `playwright` forces the Playwright runner, for a file that
 * imports its `test` from a fixtures module. A file that does not parse whole is read as far as the parser recovers.
 */
export function parseTestFile(file, source, { playwright = false } = {}) {
  const { program } = parseSync(file, source);
  const lineOf = lineFinder(source);
  const runner = runnerOf(program, playwright);
  // Only end-to-end tests record the paths they open (M13.3's routes visited).
  const nav = runner === 'playwright' ? navigation(program) : undefined;
  const tests = [];
  const visit = (node, parent, ctx) => {
    if (node.type === 'CallExpression') {
      const found = classify(node);
      if (found) {
        const args = node.arguments;
        const title = found.kind === 'describe' && !found.titled ? undefined : titleOf(args[0], source);
        // Playwright's details object sits between the title and the body: test('t', { tag }, fn).
        const tags = [
          ...ctx.tags,
          ...optionTags(args.length >= 3 ? args[1] : undefined),
          ...(runner === 'playwright' && title !== undefined ? titleTags(title) : []),
        ];
        const modifier = found.modifier ?? ctx.modifier;
        if (found.kind === 'describe') {
          const inner = {
            path: title === undefined ? ctx.path : [...ctx.path, title],
            tags,
            modifier,
            // A describe.each's tests repeat with it.
            repeated: ctx.repeated || found.parameterised,
            visits: nav ? [...ctx.visits, ...args.filter(isFunction).flatMap((fn) => nav.hooksOf(statementsOf(fn)))] : [],
          };
          for (const arg of args) if (isFunction(arg)) visit(arg, node, inner);
        } else {
          const visits = nav ? [...new Set([...ctx.visits, ...args.filter(isFunction).flatMap((fn) => nav.visitsOf(fn))])] : [];
          tests.push({
            path: ctx.path,
            title,
            line: lineOf(node.start),
            ...(modifier ? { modifier } : {}),
            ...(found.parameterised || ctx.repeated ? { parameterised: true } : {}),
            tags: [...new Set(tags)],
            ...(visits.length > 0 ? { visits } : {}),
          });
        }
        return;
      }
    }
    const next = !ctx.repeated && repeats(node, parent) ? { ...ctx, repeated: true } : ctx;
    for (const child of children(node)) visit(child, node, next);
  };
  visit(program, undefined, { path: [], tags: [], modifier: undefined, repeated: false, visits: nav ? nav.hooksOf([...program.body]) : [] });
  return { file, runner, tests };
}

/** The `name` of the nearest project.json, else package.json, from `dir` up to the repository root; '' for none. */
function projectFinder(repoRoot) {
  const cache = new Map();
  const find = (dir) => {
    if (cache.has(dir)) return cache.get(dir);
    let name;
    for (const manifest of ['project.json', 'package.json']) {
      const file = path.join(repoRoot, dir, manifest);
      if (name === undefined && existsSync(file)) {
        try {
          const parsed = JSON.parse(readFileSync(file, 'utf8'));
          if (typeof parsed.name === 'string') name = parsed.name;
        } catch {
          // An unreadable manifest names no project.
        }
      }
    }
    if (name === undefined) name = dir === '' ? '' : find(path.posix.dirname(dir) === '.' ? '' : path.posix.dirname(dir));
    cache.set(dir, name);
    return name;
  };
  return (file) => find(path.posix.dirname(file) === '.' ? '' : path.posix.dirname(file));
}

/**
 * Every test file `tests.include` matches under `repoRoot`, parsed, in path order. `parse(file, source, options)`
 * defaults to parseTestFile; the Vite plugin passes a cached one. The walk skips what the source scan skips.
 */
export function scanTests(repoRoot, tests, parse = parseTestFile) {
  const include = tests.include.map(globMatcher);
  const playwright = (tests.playwright ?? []).map(globMatcher);
  const { files } = scanFeatureSources(repoRoot, { globs: tests.include, includeTests: true });
  const projectOf = projectFinder(repoRoot);
  return {
    files: files
      .filter((file) => include.some((match) => match(file)))
      .map((file) => {
        const parsed = parse(file, readFileSync(path.join(repoRoot, file), 'utf8'), { playwright: playwright.some((match) => match(file)) });
        return { file, runner: parsed.runner, project: projectOf(file), tests: parsed.tests };
      }),
  };
}
