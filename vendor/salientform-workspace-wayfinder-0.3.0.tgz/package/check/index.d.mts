/** The repository the script runs in (the cwd's git top level). */
export const repoRoot: string;
/** Today as `YYYY-MM-DD` on the machine's calendar (its time zone, not UTC). */
export const today: string;
/** `date` as `YYYY-MM-DD` in the machine's time zone. */
export function localDate(date: Date): string;

/** Text of a repository-relative file. */
export function readRepo(file: string): string;
/** Whether a repository-relative path exists. */
export function exists(file: string): boolean;

/** Value of `export const NAME = 'YYYY-MM-DD'` in file, or null. */
export function readDate(file: string, exportName: string): string | null;

/** The date rule for a `export const NAME = 'YYYY-MM-DD'` reviewed-at date in file. */
export function dateRule(
  problems: string[],
  file: string,
  exportName: string
): void;

/**
 * The one rule for every "when was this last modified" date: a valid ISO date that is not after today.
 * `label` names the date in the problem text.
 */
export function modifiedDateRule(
  problems: string[],
  label: string,
  value: string | null | undefined
): void;

/** Prints the problems and exits 1, or prints `okMessage`. */
export function finish(problems: readonly string[], okMessage: string): void;

/** The workspace config's data half, from the path in the root package.json `wayfinder.config`. */
export function loadWorkspaceSettings(): Promise<
  import('../src/settings').WorkspaceSettings
>;

/** What every hook receives. */
export interface HookContext {
  settings: import('../src/settings').WorkspaceSettings;
  repoRoot: string;
  readRepo(file: string): string;
  exists(file: string): boolean;
}

/** The product's routes and navigation paths, read from its router, which the route mirror must equal. */
export interface ProductRouteSource {
  /** Absolute route paths, `:param` for parameters. */
  routes: string[];
  /** The navigation's paths; omit when the product has no navigation to mirror. */
  sidebar?: string[];
  /** Where the routes were read, named in the problems. */
  source: string;
  /** Where the navigation was read. Default `source`. */
  sidebarSource?: string;
}

/** A repository's hooks file: every export optional. */
export interface WorkspaceHooks {
  productRoutes?(ctx: HookContext): ProductRouteSource;
  navLabels?(ctx: HookContext): string[];
  fetchSites?(ctx: HookContext): string[];
  extraChecks?(ctx: HookContext): Partial<Record<string, string[]>>;
}

/** The functions a hooks file may export. */
export const WORKSPACE_HOOKS: readonly (keyof WorkspaceHooks)[];

/**
 * The repository's hooks, from the path in the root package.json `wayfinder.hooks` (or `wayfinder.rules`, its old
 * name); `{}` without it.
 */
export function loadWorkspaceHooks(): Promise<WorkspaceHooks>;
