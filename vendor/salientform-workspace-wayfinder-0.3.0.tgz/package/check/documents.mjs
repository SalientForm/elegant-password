/**
 * The document set: the eight documents the `document-repo` skill writes (About, Skills, Architecture, Roadmap,
 * Features, TODO, Setup, Issues), the placeholder a document holds where the repository has nothing for it yet, and
 * the inventory of skills `SKILLS.md` lists. The formats are `docs/formats.md`, "The document set". Plain node; it
 * needs no workspace config, and reads one when the root package.json names it (for the Audit area's three paths and
 * the skills directory).
 *
 * The check fails when:
 *  - a document does not exist
 *  - a document does not open with a `# ` title, or has no `Reviewed:` line before its first `## ` section, or that
 *    date is not a valid date or is after today
 *  - a placeholder's `> **Not generated yet.**` line has no reason, or is not followed by a `> **To fill:**` line with
 *    text; or a `> **To fill:**` line follows no reason
 *  - `SKILLS.md` does not list exactly the repository's own skills under "Repository skills" and the installed kit
 *    skills under "Wayfinder skills collection"; or, in the kit's own repository, has a collection section
 * It reports every placeholder after its OK line without failing; `--strict` fails on them.
 */
import { existsSync, readdirSync, readFileSync, realpathSync, statSync } from 'node:fs';
import path from 'node:path';
import { parseFrontMatter } from './front-matter.mjs';
import { KIT_SKILLS, kitSkillNames } from './install-skills.mjs';
import { aboutSettings } from './settings-defaults.mjs';
import { DOCUMENTS, DOCUMENTS_DIR, PLACEHOLDER_REASON, PLACEHOLDER_TO_FILL, documentPaths, parsePlaceholders } from './document-set.mjs';

export { DOCUMENTS, DOCUMENTS_DIR, PLACEHOLDER_REASON, PLACEHOLDER_TO_FILL, documentPaths, parsePlaceholders };

/** The kit's package name, from its own package.json. */
export const KIT_NAME = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).name;

/** Agent skill directories read besides the configured ones: the shared one, Claude Code's and opencode's. */
export const AGENT_SKILL_DIRS = ['.agents/skills', '.claude/skills', '.opencode/skills'];

/** The kit's own repository keeps the collection's source in `skills/`. */
export const KIT_SOURCE_SKILLS = 'skills';

export const REPOSITORY_SKILLS_HEADING = '## Repository skills';
export const COLLECTION_HEADING = '## Wayfinder skills collection';

/** Problems with a document's title and `Reviewed:` line. `today` is `YYYY-MM-DD`. */
export function headerProblems(markdown, label, today) {
  const problems = [];
  const body = bodyOf(markdown, label, problems);
  const lines = body.split('\n');
  const first = lines.findIndex((l) => l.trim() !== '');
  if (first === -1 || !/^# \S/.test(lines[first])) problems.push(`${label}: does not open with a "# " title`);
  const sectionAt = lines.findIndex((l) => l.startsWith('## '));
  const header = sectionAt === -1 ? lines : lines.slice(0, sectionAt);
  const reviewed = header.map((l) => /^Reviewed:\s*(.*)$/.exec(l)).find(Boolean);
  if (!reviewed) problems.push(`${label}: no "Reviewed:" line before its first section`);
  else {
    const value = reviewed[1].trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(value))) problems.push(`${label}: Reviewed: ${value || '(empty)'} is not a date`);
    else if (value > today) problems.push(`${label}: Reviewed: ${value} is in the future (today is ${today})`);
  }
  return problems;
}

/** `markdown` without its front matter; a broken block is a problem and the text is read as written. */
function bodyOf(markdown, label, problems) {
  try {
    return parseFrontMatter(markdown, label).body;
  } catch (error) {
    problems.push(error.message);
    return markdown;
  }
}

/**
 * True when the document says nothing but a placeholder: after its title, its `Reviewed:` line and any intro, the only
 * content is one placeholder and no `## ` section holds anything else.
 */
export function isPlaceholderFile(markdown) {
  const body = (() => {
    try {
      return parseFrontMatter(markdown).body;
    } catch {
      return markdown;
    }
  })();
  const { placeholders } = parsePlaceholders(body);
  if (placeholders.length !== 1) return false;
  return !body.split('\n').some((l) => l.startsWith('## '));
}

/** The skill names in a section of `SKILLS.md`: the first cell of each table row, a name in backticks. */
export function listedSkills(markdown, heading) {
  const lines = markdown.split('\n');
  const start = lines.findIndex((l) => l.trim() === heading);
  if (start === -1) return undefined;
  const names = [];
  for (const line of lines.slice(start + 1)) {
    if (line.startsWith('## ')) break;
    const m = /^\|\s*`([^`]+)`\s*\|/.exec(line);
    if (m) names.push(m[1]);
  }
  return names;
}

/** Names the root `skills-lock.json` records: skills installed from elsewhere (a vendor's), not the repository's. */
export function vendorSkillNames(root) {
  const lock = path.join(root, 'skills-lock.json');
  if (!existsSync(lock)) return [];
  try {
    return Object.keys(JSON.parse(readFileSync(lock, 'utf8')).skills ?? {}).sort();
  } catch {
    return [];
  }
}

/** True when `root` is the kit's own repository, where `skills/` is the collection's source. */
export function isKitRepository(root) {
  try {
    return JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8')).name === KIT_NAME;
  } catch {
    return false;
  }
}

/**
 * The skills a repository keeps, for `SKILLS.md`: `{ own, collection, vendor, outside, kitRepository }`. `own` and
 * `collection` are `{ name, dir, description, path, repositoryRules }` sorted by name; a skill is read once however many
 * agent directories link to it. In the kit's own repository every skill is `own` (`skills/` is the collection's
 * source); elsewhere a skill whose directory has a kit skill's name is in the `collection`. `vendor` names the
 * skills `skills-lock.json` records, and `outside` the links that resolve outside the repository (the user's or a
 * plugin's skills); neither is listed.
 */
export function skillInventory({ root, settings, kitDir = KIT_SKILLS, kitRepository = isKitRepository(root) } = {}) {
  const { skillsDir, skillLinks } = aboutSettings(settings?.areas?.about ?? {});
  const dirs = [...new Set([...(kitRepository ? [KIT_SOURCE_SKILLS] : []), skillsDir, ...skillLinks, ...AGENT_SKILL_DIRS])];
  const kitNames = kitSkillNames(kitDir);
  const vendorNames = vendorSkillNames(root);
  const realRoot = realpathSync(root);
  const seen = new Set();
  const own = [];
  const collection = [];
  const vendor = new Set();
  const outside = [];
  for (const dir of dirs) {
    const at = path.join(root, dir);
    if (!existsSync(at)) continue;
    for (const entry of readdirSync(at, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const skillDir = path.join(at, entry.name);
      let real;
      try {
        real = realpathSync(skillDir);
        if (!statSync(real).isDirectory() || !existsSync(path.join(real, 'SKILL.md'))) continue;
      } catch {
        continue;
      }
      const rel = path.relative(realRoot, real);
      if (rel.startsWith('..') || path.isAbsolute(rel)) {
        outside.push(`${dir}/${entry.name}`);
        continue;
      }
      if (seen.has(real)) continue;
      seen.add(real);
      if (vendorNames.includes(entry.name)) {
        vendor.add(entry.name);
        continue;
      }
      let data = {};
      try {
        data = parseFrontMatter(readFileSync(path.join(real, 'SKILL.md'), 'utf8')).data;
      } catch {
        // A malformed SKILL.md is still a skill the repository keeps; its description reads as empty.
      }
      const skill = {
        name: typeof data.name === 'string' ? data.name : entry.name,
        dir: entry.name,
        description: typeof data.description === 'string' ? data.description.trim() : '',
        path: rel.split(path.sep).join('/'),
        repositoryRules: existsSync(path.join(real, 'REPOSITORY.md')),
      };
      (!kitRepository && kitNames.includes(entry.name) ? collection : own).push(skill);
    }
  }
  const byName = (a, b) => a.name.localeCompare(b.name);
  return { own: own.sort(byName), collection: collection.sort(byName), vendor: [...vendor].sort(), outside: outside.sort(), kitRepository };
}

/** Problems with `SKILLS.md` against the inventory. */
export function skillsProblems(markdown, inventory, label = 'SKILLS.md') {
  const problems = [];
  const total = inventory.own.length + inventory.collection.length;
  if (isPlaceholderFile(markdown)) {
    if (total > 0) problems.push(`${label}: is a placeholder, but the repository keeps ${total} skill(s); list them`);
    return problems;
  }
  const compare = (heading, expected, what) => {
    const listed = listedSkills(markdown, heading);
    if (listed === undefined) {
      if (expected.length > 0) problems.push(`${label}: no "${heading}" section, but the repository has ${expected.length} ${what}`);
      return;
    }
    const names = expected.map((s) => s.name);
    for (const name of names.filter((n) => !listed.includes(n))) problems.push(`${label}: ${heading.slice(3)} does not list ${name}`);
    for (const name of listed.filter((n) => !names.includes(n))) problems.push(`${label}: ${heading.slice(3)} lists ${name}, which is not one of its ${what}`);
    const dupes = listed.filter((n, i) => listed.indexOf(n) !== i);
    for (const name of new Set(dupes)) problems.push(`${label}: ${heading.slice(3)} lists ${name} twice`);
  };
  compare(REPOSITORY_SKILLS_HEADING, inventory.own, 'skills of its own');
  if (inventory.kitRepository) {
    if (listedSkills(markdown, COLLECTION_HEADING) !== undefined)
      problems.push(`${label}: the kit's own repository has no "${COLLECTION_HEADING.slice(3)}" section; its skills are the repository's own`);
  } else compare(COLLECTION_HEADING, inventory.collection, 'installed kit skills');
  return problems;
}

/**
 * Checks the document set in `root`: `{ problems, placeholders, summary }`, `placeholders` being `{ file, line,
 * reason, toFill }` each. `today` is `YYYY-MM-DD`.
 */
export function checkDocuments({ root, settings, today, kitDir = KIT_SKILLS, kitRepository = isKitRepository(root) }) {
  const problems = [];
  const placeholders = [];
  let present = 0;
  let placeholderFiles = 0;
  for (const doc of documentPaths(settings)) {
    const at = path.join(root, doc.path);
    if (!existsSync(at)) {
      problems.push(`fatal: ${doc.path} does not exist (the ${doc.key} document; the document-repo skill writes it)`);
      continue;
    }
    present += 1;
    const markdown = readFileSync(at, 'utf8');
    problems.push(...headerProblems(markdown, doc.path, today));
    const found = parsePlaceholders(markdown, doc.path);
    problems.push(...found.problems);
    placeholders.push(...found.placeholders.map((p) => ({ file: doc.path, ...p })));
    if (isPlaceholderFile(markdown)) placeholderFiles += 1;
    if (doc.key === 'skills') problems.push(...skillsProblems(markdown, skillInventory({ root, settings, kitDir, kitRepository }), doc.path));
  }
  const summary = `${present} of ${DOCUMENTS.length} documents, ${placeholderFiles} a placeholder file, ${placeholders.length} placeholder(s)`;
  return { problems, placeholders, summary };
}

/** The workspace config when the root package.json names one, otherwise undefined: the documents need none. */
export async function optionalSettings(root) {
  let pointer;
  try {
    pointer = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8')).wayfinder?.config;
  } catch {
    return undefined;
  }
  if (typeof pointer !== 'string') return undefined;
  const { loadWorkspaceSettings } = await import('./index.mjs');
  return loadWorkspaceSettings();
}

/** A placeholder as the check prints it. */
export function describePlaceholder({ file, line, reason }) {
  return `placeholder: ${file}:${line} ${reason}`;
}

/** The inventory as the list-skills script prints it: a table per section, ready to copy into SKILLS.md. */
export function describeInventory(inventory) {
  const out = [];
  const table = (heading, skills, third, cell) => {
    // The SKILL.md description says when to use a skill: SKILLS.md says what it does, written fresh from it.
    out.push(`${heading} (${skills.length})`, '', `| Skill | When to use it (its description: write what it does from it) | ${third} |`, '| --- | --- | --- |');
    for (const s of skills) out.push(`| \`${s.name}\` | ${s.description.replace(/\|/g, '\\|').replace(/\s+/g, ' ')} | ${cell(s)} |`);
    out.push('');
  };
  table(REPOSITORY_SKILLS_HEADING, inventory.own, 'Path', (s) => `\`${s.path}\``);
  if (!inventory.kitRepository) table(COLLECTION_HEADING, inventory.collection, 'Repository rules', (s) => (s.repositoryRules ? `[REPOSITORY.md](../${s.path}/REPOSITORY.md)` : '—'));
  if (inventory.vendor.length > 0) out.push(`Not listed, a vendor's (skills-lock.json): ${inventory.vendor.join(', ')}`);
  if (inventory.outside.length > 0) out.push(`Not listed, outside the repository: ${inventory.outside.join(', ')}`);
  if (inventory.kitRepository) out.push(`The kit's own repository: ${KIT_SOURCE_SKILLS}/ is the Wayfinder skills collection's source, listed as the repository's own skills.`);
  return out.join('\n').trimEnd();
}
