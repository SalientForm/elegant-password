/** The settings file at a hosted folder's root: its presence makes a folder a hosted instance. */
export const HOSTED_FILE: string;
/** What the last refresh copied. */
export const HOSTED_COPIES: string;
/** Where the kit keeps its hosted instances, under its own repository's root. */
export const HOSTED_DIR: string;
/** The `.git` file a hosted folder holds. */
export const GIT_STUB: string;

/** A hosted folder's settings, its paths absolute but `skillsDir`, `hide` and `include`, which are the repository's. */
export interface HostedSettings {
  root: string;
  repository: string;
  skillsDir: string;
  hide: string[];
  include: string[];
  kit: string;
}

/** One copy: where it came from, and the copy's and the source's size and time when it was made (or a link's target). */
export interface HostedCopy {
  from: string;
  link?: string;
  size?: number;
  mtimeMs?: number;
  fromSize?: number;
  fromMtimeMs?: number;
}

export function isHostedName(name: string): boolean;
/** The hosted folder `name` names in the kit's checkout `kit`; throws when there is none. */
export function namedHosted(kit: string, name: string): string;
/** The hosted folder `dir` is in, or undefined. */
export function findHosted(dir?: string): string | undefined;
export function readHosted(folder: string): HostedSettings;
/** Brings the folder's copies up to date with the repository and the kit; a changed copy is the instance's own. */
export function refreshHosted(folder: string): { copies: Record<string, HostedCopy> };
/** The folder's files as git would list them in the repository with the instance installed. */
export function hostedFiles(folder: string, options?: { others?: boolean }): string[];
/** The instance's own files: every file in the folder but the copies it still matches. */
export function overlayFiles(folder: string): string[];
export function matchesPathspec(spec: string, file: string): boolean;
/** `git ls-files <args>` at `root`, which may be a hosted folder. */
export function lsFiles(root: string, args?: readonly string[]): string[];
/** The checkout git commands about the repository run in. */
export function gitRoot(root: string): string;
