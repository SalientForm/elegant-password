/**
 * The check library every workspace script imports (spec M12.3 §5.9): plain node, no dependencies, no build step.
 * Scripts import it by name: `@salientform/workspace-wayfinder/check`.
 */
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { findHosted, namedHosted, refreshHosted } from './hosted.mjs';

/**
 * The repository the script runs in: the hosted folder the cwd is in (`hosted.mjs`), else the cwd's git top level, or
 * in the kit's own repository the hosted instance `WAYFINDER_WORKSPACE` names. A hosted folder's copies are refreshed
 * first, so it shows its repository as it is now.
 */
function activeRoot() {
  const hosted = findHosted();
  if (hosted) {
    refreshHosted(hosted);
    return hosted;
  }
  const top = execFileSync('git', ['rev-parse', '--show-toplevel'], { encoding: 'utf8' }).trim();
  const name = process.env.WAYFINDER_WORKSPACE;
  if (!name) return top;
  const folder = namedHosted(top, name);
  refreshHosted(folder);
  return folder;
}
export const repoRoot = activeRoot();
/** Today as `YYYY-MM-DD` on this machine's calendar: the day a person writes, not UTC's, which is tomorrow in an American evening. */
export const today = localDate(new Date());

/** `date` as `YYYY-MM-DD` in the machine's time zone. */
export function localDate(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function readRepo(file) { return readFileSync(path.join(repoRoot, file), 'utf8'); }
export function exists(file) { return existsSync(path.join(repoRoot, file)); }

/** Value of `export const NAME = 'YYYY-MM-DD'` in file, or null. */
export function readDate(file, exportName) {
  const m = new RegExp(`export const ${exportName} = '(\\d{4}-\\d{2}-\\d{2})'`).exec(readRepo(file));
  return m ? m[1] : null;
}

/** The date rule for a `export const NAME = 'YYYY-MM-DD'` reviewed-at date in file. */
export function dateRule(problems, file, exportName) {
  modifiedDateRule(problems, `${file}: ${exportName}`, readDate(file, exportName));
}

/**
 * The one rule for every "when was this last modified" date: a valid ISO date that is not after today.
 * It records the day the change was actually made, written by whoever makes it. It is not derived
 * from git: when the change is committed, rebased or merged has no bearing on it.
 * `label` names the date in the problem text (e.g. `docs/reviews/index.md: reviewedAt` or `docs/reviews: docReviews README.md lastModified`).
 */
export function modifiedDateRule(problems, label, value) {
  if (!value || Number.isNaN(Date.parse(value))) { problems.push(`${label} missing or not an ISO date`); return; }
  if (value > today) problems.push(`${label}=${value} is in the future (today is ${today})`);
}

export function finish(problems, okMessage) {
  if (problems.length) { console.error(problems.join('\n')); console.error(`\n${problems.length} problem(s)`); process.exit(1); }
  console.log(okMessage);
}

/** The workspace config's data half, from the path in the root package.json `wayfinder.config` (spec §5.9, §7). */
export async function loadWorkspaceSettings() {
  const pointer = JSON.parse(readRepo('package.json')).wayfinder?.config;
  if (typeof pointer !== 'string') throw new Error('wayfinder: package.json has no wayfinder.config (the path of workspace.config.mts)');
  if (!exists(pointer)) throw new Error(`wayfinder: ${pointer} does not exist (package.json wayfinder.config)`);
  const settings = (await import(pathToFileURL(path.join(repoRoot, pointer)).href)).default;
  if (!settings || typeof settings.areas !== 'object') throw new Error(`wayfinder: ${pointer} has no default export with areas`);
  return settings;
}

/** The functions a repository's hooks file may export. */
export const WORKSPACE_HOOKS = ['productRoutes', 'navLabels', 'fetchSites', 'extraChecks'];

/**
 * The repository's hooks, from the path in the root package.json `wayfinder.hooks`: an ESM module whose named exports
 * from WORKSPACE_HOOKS are its hooks (other exports, helpers its tests import, are ignored). `{}` without the pointer;
 * throws on a missing file or a hook that is not a function. `wayfinder.rules`, the key's name before 0.3.0, is read
 * when `hooks` is absent, and naming both is an error.
 */
export async function loadWorkspaceHooks() {
  const pointers = JSON.parse(readRepo('package.json')).wayfinder ?? {};
  if (pointers.hooks !== undefined && pointers.rules !== undefined) {
    throw new Error('wayfinder: package.json names both wayfinder.hooks and wayfinder.rules (its old name): keep hooks');
  }
  const key = pointers.hooks !== undefined ? 'hooks' : 'rules';
  const pointer = pointers[key];
  if (pointer === undefined) return {};
  if (typeof pointer !== 'string') throw new Error(`wayfinder: package.json wayfinder.${key} is not a path`);
  if (!exists(pointer)) throw new Error(`wayfinder: ${pointer} does not exist (package.json wayfinder.${key})`);
  const module = await import(pathToFileURL(path.join(repoRoot, pointer)).href);
  const hooks = {};
  for (const name of WORKSPACE_HOOKS) {
    if (module[name] === undefined) continue;
    if (typeof module[name] !== 'function') throw new Error(`wayfinder: ${pointer} export ${name} is not a function`);
    hooks[name] = module[name];
  }
  return hooks;
}
