/**
 * What the first-run proposals read (spec WW-M1 §5): the repository's files and the configs of its test runners, read as
 * text and never run, so a proposal needs no install and no network. Every function takes the repository root, so the
 * proposals run on any directory.
 */
import { execFileSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { globMatcher } from './features.mjs';
import { findHosted, hostedFiles } from './hosted.mjs';

const SKIP_DIRS = new Set(['node_modules', 'dist', 'out-tsc', '.nx', '.git', 'coverage', 'test-output', 'build']);

function walk(root, dir, out) {
  for (const entry of readdirSync(path.join(root, dir), { withFileTypes: true })) {
    if (SKIP_DIRS.has(entry.name)) continue;
    const rel = dir ? `${dir}/${entry.name}` : entry.name;
    if (entry.isDirectory()) walk(root, rel, out);
    else out.push(rel);
  }
  return out;
}

/**
 * The repository's files, repository-relative and sorted: what git tracks and what it would track (untracked and not
 * ignored), so a file the run just wrote counts. Outside a git checkout, a walk that skips dependencies and build output.
 * In a hosted folder, what it shows of the repository, with its own files and the kit's skills.
 */
export function repoFiles(root) {
  // A hosted folder lists the repository's files it shows, its own and the kit's skills (hosted.mjs).
  if (findHosted(root) === path.resolve(root)) return hostedFiles(root);
  let listed;
  try {
    listed = execFileSync('git', ['ls-files', '-z', '--cached', '--others', '--exclude-standard'], {
      cwd: root,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      maxBuffer: 64 * 1024 * 1024,
    });
  } catch {
    return walk(root, '', []).sort();
  }
  const files = new Set(listed.split('\0').filter(Boolean));
  // A deleted file git still tracks is not there to read.
  return [...files].filter((file) => existsSync(path.join(root, file))).sort();
}

/** A repository file's text, or undefined when it is not a file. */
export function readText(root, file) {
  try {
    if (!statSync(path.join(root, file)).isFile()) return undefined;
    return readFileSync(path.join(root, file), 'utf8');
  } catch {
    return undefined;
  }
}

/** A repository JSON file, or undefined when it is missing or not JSON. */
export function readJsonFile(root, file) {
  const text = readText(root, file);
  if (text === undefined) return undefined;
  try {
    return JSON.parse(text);
  } catch {
    return undefined;
  }
}

/** `dir` joined to a relative path or glob, normalised and repository-relative (`./src` in `apps/web` → `apps/web/src`). */
export function underDir(dir, rel) {
  const joined = path.posix.normalize(path.posix.join(dir || '.', rel));
  return joined.replace(/^\.\//, '').replace(/\/$/, '') || '.';
}

/** The `{…}` block that follows `key:` in `source`, braces balanced, or undefined. */
export function blockAfter(source, key) {
  const m = new RegExp(`(?:^|[\\s,{])${key}\\s*:\\s*\\{`).exec(source);
  if (!m) return undefined;
  const start = m.index + m[0].length - 1;
  let depth = 0;
  for (let i = start; i < source.length; i++) {
    const char = source[i];
    if (char === "'" || char === '"' || char === '`') {
      const close = source.indexOf(char, i + 1);
      if (close === -1) return undefined;
      i = close;
    } else if (char === '{') depth++;
    else if (char === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  return undefined;
}

/** `block` with every nested `{…}` emptied, so a key is read at its own level only (`test.include`, not `test.coverage.include`). */
export function topLevel(block) {
  let out = '';
  let depth = 0;
  for (let i = 0; i < block.length; i++) {
    const char = block[i];
    if (char === "'" || char === '"' || char === '`') {
      const close = block.indexOf(char, i + 1);
      const end = close === -1 ? block.length : close;
      if (depth <= 1) out += block.slice(i, end + 1);
      i = end;
      continue;
    }
    if (char === '{') depth++;
    if (depth <= 1) out += char;
    if (char === '}') {
      depth--;
      if (depth === 1) out += '}';
    }
  }
  return out;
}

const quoted = (text) => [...text.matchAll(/'([^']*)'|"([^"]*)"|`([^`$]*)`/g)].map((m) => m[1] ?? m[2] ?? m[3]);

/** The string items of `key: [ … ]` (or a lone `key: '…'`) in `source`, or undefined when there is no such key. */
export function stringsAt(source, key) {
  const list = new RegExp(`(?:^|[\\s,{])${key}\\s*:\\s*\\[([^\\]]*)\\]`).exec(source);
  if (list) return quoted(list[1]);
  const one = new RegExp(`(?:^|[\\s,{])${key}\\s*:\\s*(['"\`])([^'"\`]*)\\1`).exec(source);
  return one ? [one[2]] : undefined;
}

/** The directories of the repository's packages other than the root (each `package.json` git knows of), sorted. */
export function packageDirs(files) {
  return files
    .filter((file) => file.endsWith('/package.json') && !file.split('/').includes('node_modules'))
    .map((file) => path.posix.dirname(file))
    .sort();
}

/** Every `package.json` git knows of, root first, with its directory (`''` for the root). */
export function packageJsons(root, files) {
  return ['', ...packageDirs(files)]
    .map((dir) => ({ dir, json: readJsonFile(root, dir ? `${dir}/package.json` : 'package.json') }))
    .filter((p) => p.json && typeof p.json === 'object');
}

const VITEST_CONFIG = /(^|\/)(vitest|vite)\.config\.[cm]?[jt]s$/;
const PLAYWRIGHT_CONFIG = /(^|\/)playwright\.config\.[cm]?[jt]s$/;
const VITEST_DEFAULT = '**/*.{test,spec}.{ts,tsx,js,jsx,mts,mjs}';
const PLAYWRIGHT_DEFAULT = '**/*.{test,spec}.{ts,tsx,js,jsx,mts,mjs}';

/** True when `dir` is `outer` or inside it. */
export const within = (dir, outer) => outer !== undefined && outer !== '' && (dir === outer || dir.startsWith(`${outer}/`));

/**
 * The repository's test runners, from their configs, read as text and never run (`exclude`: a directory whose configs
 * are not the product's, the workspace app's). Each is `{ runner, config, include, setupFiles, coverage? }`:
 *  - Vitest: every `vitest.config.*`, and every `vite.config.*` with a `test` block; `include` is its `test.include`
 *    (Vitest's default without one), under the config's directory; `coverage` is the `json-summary` the v8 or istanbul
 *    reporter writes (`<reportsDirectory>/coverage-summary.json`), when its reporters name it. A config whose `test`
 *    lists `projects` only gathers other configs: it is not a runner of its own.
 *  - Playwright: every `playwright.config.*`; `include` is its `testDir` with Playwright's default match, `setupFiles`
 *    its `globalSetup` and `globalTeardown`.
 *  - node:test: every `node --test <glob>` in a package's scripts.
 */
export function testRunners(root, files, { exclude } = {}) {
  const runners = [];
  for (const config of files) {
    const dir = path.posix.dirname(config) === '.' ? '' : path.posix.dirname(config);
    if (within(dir, exclude)) continue;
    if (VITEST_CONFIG.test(config)) {
      const source = readText(root, config) ?? '';
      const test = blockAfter(source, 'test');
      if (!test && !/(^|\/)vitest\.config\./.test(config)) continue;
      const block = test ?? '';
      const own = topLevel(block);
      if (/(?:^|[\s,{])projects\s*:/.test(own) && !/(?:^|[\s,{])include\s*:/.test(own)) continue;
      const include = (stringsAt(own, 'include') ?? [VITEST_DEFAULT]).map((glob) => underDir(dir, glob));
      const setupFiles = (stringsAt(own, 'setupFiles') ?? []).map((file) => underDir(dir, file));
      const runner = { runner: 'vitest', config, include, setupFiles };
      const coverage = blockAfter(block, 'coverage');
      if (coverage && /['"`]json-summary['"`]/.test(coverage)) {
        const reports = stringsAt(coverage, 'reportsDirectory')?.[0] ?? 'coverage';
        runner.coverage = underDir(dir, `${reports}/coverage-summary.json`);
      }
      runners.push(runner);
    } else if (PLAYWRIGHT_CONFIG.test(config)) {
      const source = readText(root, config) ?? '';
      const testDir = stringsAt(source, 'testDir')?.[0] ?? '.';
      const include = [underDir(underDir(dir, testDir), PLAYWRIGHT_DEFAULT)];
      const setupFiles = ['globalSetup', 'globalTeardown'].flatMap((key) => stringsAt(source, key) ?? []).map((file) => underDir(dir, file));
      runners.push({ runner: 'playwright', config, include, setupFiles });
    }
  }
  for (const { dir, json } of packageJsons(root, files)) {
    if (within(dir, exclude)) continue;
    for (const [name, command] of Object.entries(json.scripts ?? {})) {
      for (const m of String(command).matchAll(/\bnode\s+(?:--[\w-]+(?:=\S+)?\s+)*--test\b((?:\s+(?!&&|\|\||;)[^\s-][^\s]*)+)/g)) {
        const include = m[1].trim().split(/\s+/).map((glob) => underDir(dir, glob.replace(/^['"]|['"]$/g, '')));
        runners.push({ runner: 'node:test', config: `${dir ? `${dir}/` : ''}package.json scripts.${name}`, include, setupFiles: [] });
      }
    }
  }
  return runners;
}

/** The globs of `globs` that match at least one of `files`. */
export function matchingGlobs(globs, files) {
  return globs.filter((glob) => {
    const match = globMatcher(glob);
    return files.some(match);
  });
}

/** `items` without repeats, in first-seen order. */
export const unique = (items) => [...new Set(items)];
