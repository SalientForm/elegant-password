/**
 * Parsers for a roadmap (ROADMAP.md), a TODO list (TODO.md) and the Stack summary / Planned migrations sections of an
 * architecture document (ARCHITECTURE.md). Dependency-free ESM so the kit's Audit module (through Vite) and the check
 * scripts (through plain Node) read the same rules. Types: audit-markdown.d.mts.
 * Format: the kit's docs/formats.md. The house conventions, the phase kinds and the
 * TODO areas, are arguments: a repository's workspace config holds them (settings.areas.audit, spec M12.8 §5.3), and
 * so is the id prefix every id carries (`idPrefix`: `ACME` gives `ACME-M1`, `ACME-M1.2`, `ACME-X3` and `ACME-4`).
 */

export const PHASE_STATUSES = ['not started', 'specified', 'planned', 'in progress'];
/** An id prefix: upper-case letters and digits, starting with a letter (`ACME`, `ABA`, `EP2`). */
export const ID_PREFIX = /^[A-Z][A-Z0-9]*$/;

/**
 * The id forms of a repository whose prefix is `prefix`: a milestone `<P>-M<n>`, a phase `<P>-M<n>.<k>`, an Outside
 * the roadmap row `<P>-X<n>` and a TODO entry `<P>-<n>`. Each pattern matches a whole id and captures its numbers.
 * Throws a TypeError for a prefix that is not `ID_PREFIX`.
 */
export function idPatterns(prefix) {
  if (typeof prefix !== 'string' || !ID_PREFIX.test(prefix))
    throw new TypeError(`idPrefix ${JSON.stringify(prefix)} is not upper-case letters and digits starting with a letter (ACME, ABA)`);
  const p = `${prefix}-`;
  return {
    prefix,
    milestone: new RegExp(`^${p}M(\\d+)$`),
    phase: new RegExp(`^${p}M(\\d+)\\.(\\d+)$`),
    x: new RegExp(`^${p}X(\\d+)$`),
    todo: new RegExp(`^${p}(\\d+)$`),
    /** A milestone, a phase or an X id: what a spec's or plan's Milestone line may name. */
    roadmap: new RegExp(`^${p}(?:M\\d+(?:\\.\\d+)?|X\\d+)$`),
  };
}

/** The suggested id prefix for a repository named `name`: its words' initials (`workspace-wayfinder` → `WW`, `acme-billing-api` → `ABA`), or its first three letters when it is one word (`storefront` → `STO`). */
export function suggestIdPrefix(name) {
  const words = String(name)
    .replace(/^@[^/]+\//, '')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .split(/[^A-Za-z0-9]+/)
    .filter(Boolean);
  const letters = words.length > 1 ? words.map((w) => w[0]).join('') : (words[0] ?? '').slice(0, 3);
  const prefix = letters.toUpperCase().replace(/^[0-9]+/, '');
  return ID_PREFIX.test(prefix) ? prefix : 'R';
}

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const FIELD = /^- \*\*([^:*]+):\*\* ?(.*)$/;
const EMPTY = new Set(['', '—', '-']);

/**
 * A parse's problems, collected so one run names them all: `add(line, message)` records `file:line: message` and the
 * parse goes on past the line; `done(problems)` adds the whole-file problems as `file: problem` and throws them all as
 * one Error, its message every problem joined with '; ' and its `problems` the list, or returns when there are none.
 */
function collector(file) {
  const list = [];
  return {
    add(line, message) {
      list.push(`${file}:${line}: ${message}`);
    },
    done(problems = []) {
      const all = [...list, ...problems.map((p) => `${file}: ${p}`)];
      if (all.length) throw Object.assign(new Error(all.join('; ')), { problems: all });
    },
  };
}

/** The convention list `name` of `options`, or a throw naming the parser: a missing list is never "anything goes". */
function conventionList(options, name, parser) {
  const list = options?.[name];
  if (!Array.isArray(list) || list.length === 0 || !list.every((v) => typeof v === 'string' && v.trim() !== ''))
    throw new TypeError(`${parser}: ${name} must be a non-empty list of strings`);
  return list;
}

/**
 * Whether a TODO `Source:` names a repository path. `todoSources` are the values that do not: an exact value, or a
 * prefix ending in ':' (`feature-audit:` covers `feature-audit:<slug>`). Default ['idea'].
 */
export function isTodoPath(source, todoSources = ['idea']) {
  return !todoSources.some((tag) => (tag.endsWith(':') ? source.startsWith(tag) : source === tag));
}

/** Lines with a 1-based number and whether they sit inside a fenced code block. */
function scan(markdown) {
  let inFence = false;
  return markdown.split('\n').map((text, i) => {
    const fence = text.trimStart().startsWith('```');
    const fenced = inFence || fence;
    if (fence) inFence = !inFence;
    return { text, n: i + 1, fenced };
  });
}

function headerDate(lines, bad) {
  for (const l of lines) {
    if (l.text.startsWith('## ')) break;
    const m = /^Reviewed: (.+)$/.exec(l.text);
    if (m) {
      if (!ISO_DATE.test(m[1])) bad.add(l.n, `Reviewed date "${m[1]}" is not YYYY-MM-DD`);
      return m[1];
    }
  }
  bad.add(1, 'missing "Reviewed: YYYY-MM-DD" line before the first section');
  return undefined;
}

function value(raw) {
  const v = raw.trim();
  return EMPTY.has(v) ? undefined : v;
}

/** Cells of a markdown table row, or null when the line is not a row or is the --- separator. */
function tableCells(text) {
  const t = text.trim();
  if (!t.startsWith('|') || !t.endsWith('|')) return null;
  const cells = t
    .slice(1, -1)
    .split(/(?<!\\)\|/)
    .map((c) => c.trim().replace(/\\\|/g, '|'));
  if (cells.every((c) => /^:?-{3,}:?$/.test(c))) return null;
  return cells;
}

function trimBlank(lines) {
  const out = [...lines];
  while (out.length && out[0].trim() === '') out.shift();
  while (out.length && out[out.length - 1].trim() === '') out.pop();
  return out.join('\n');
}

// ───────────────────────── ROADMAP.md ─────────────────────────

const UI_FIELDS = new Set(['Status', 'Kind', 'Depends on', 'Spec', 'Plan']);

export function parseRoadmap(markdown, conventions) {
  const phaseKinds = conventionList(conventions, 'phaseKinds', 'parseRoadmap');
  const ids = idPatterns(conventions.idPrefix);
  const P = ids.prefix;
  const ROADMAP_FILE = conventions.file ?? 'ROADMAP.md';
  const lines = scan(markdown);
  const bad = collector(ROADMAP_FILE);
  const roadmap = { reviewedAt: headerDate(lines, bad), sequence: [], milestones: [], completed: [], nextX: NaN, outside: [] };
  let section = null; // 'sequence' | 'completed' | 'outside' | 'milestone'
  let milestone = null;
  let phase = null;
  let summary = [];
  let body = [];
  let sawCompletedHeader = false;
  let sawOutsideHeader = false;
  let sawOutside = false;
  // After a malformed heading, its lines are skipped until the next heading (`skip`), and after a malformed section
  // until the next section (`badSection`), whose own problem is enough.
  let skip = false;
  let badSection = false;

  const closePhase = () => {
    if (!phase) return;
    phase.body = trimBlank(body);
    body = [];
    phase = null;
  };
  const closeMilestone = () => {
    closePhase();
    if (milestone) milestone.summary = trimBlank(summary);
    summary = [];
    milestone = null;
  };

  for (const l of lines) {
    const h2 = !l.fenced && /^## (.+?)\s*$/.exec(l.text);
    const h3 = !l.fenced && /^### (.+?)\s*$/.exec(l.text);
    if (h2) {
      closeMilestone();
      skip = badSection = false;
      const m = /^(\S+)\. (.+)$/.exec(h2[1]);
      if (h2[1] === 'Sequence') section = 'sequence';
      else if (h2[1] === 'Completed') section = 'completed';
      else if (h2[1] === 'Outside the roadmap') { section = 'outside'; sawOutside = true; }
      else if (m && ids.milestone.test(m[1])) {
        section = 'milestone';
        milestone = { id: m[1], title: m[2], summary: '', phases: [] };
        roadmap.milestones.push(milestone);
      } else {
        bad.add(l.n, `unexpected section "${h2[1]}" — expected Sequence, Completed, Outside the roadmap or "${P}-M<n>. Title"`);
        section = null;
        skip = badSection = true;
      }
      continue;
    }
    if (h3) {
      closePhase();
      const m = /^(\S+) (.+)$/.exec(h3[1]);
      skip = badSection || section !== 'milestone' || !m || !ids.phase.test(m[1]);
      if (skip) {
        if (!badSection) bad.add(l.n, `unexpected heading "${h3[1]}" — expected "${P}-M<n>.<k> Title" inside a milestone`);
        continue;
      }
      phase = { id: m[1], milestoneId: milestone.id, title: m[2], dependsOn: [], body: '', line: l.n };
      milestone.phases.push(phase);
      continue;
    }
    if (skip) continue;
    if (section === 'sequence') {
      // A blank line, or a placeholder (a blockquote) where the roadmap has no open phase yet: the check pairs the two.
      if (l.text.trim() === '' || l.text.startsWith('>')) continue;
      const m = /^\d+\. (\S+)$/.exec(l.text.trim());
      if (m) roadmap.sequence.push(m[1]);
      else bad.add(l.n, `Sequence lines must be "<n>. ${P}-M<n>.<k>"`);
    } else if (section === 'completed') {
      const cells = tableCells(l.text);
      if (!cells) continue;
      if (!sawCompletedHeader) { sawCompletedHeader = true; continue; }
      if (cells.length !== 4) {
        bad.add(l.n, 'Completed rows need 4 cells: ID, Title, Shipped, Spec / plan');
        continue;
      }
      if (!ISO_DATE.test(cells[2])) bad.add(l.n, `Shipped date "${cells[2]}" is not YYYY-MM-DD`);
      const row = { id: cells[0], title: cells[1], shipped: cells[2] };
      if (value(cells[3])) row.ref = value(cells[3]);
      roadmap.completed.push(row);
    } else if (section === 'outside') {
      const next = /^Next X: (\d+)$/.exec(l.text.trim());
      if (next) { roadmap.nextX = Number(next[1]); continue; }
      const cells = tableCells(l.text);
      if (!cells) continue;
      if (!sawOutsideHeader) { sawOutsideHeader = true; continue; }
      if (cells.length !== 4) {
        bad.add(l.n, 'Outside the roadmap rows need 4 cells: ID, Title, Spec, Plan');
        continue;
      }
      const row = { id: cells[0], title: cells[1] };
      if (value(cells[2])) row.spec = value(cells[2]);
      if (value(cells[3])) row.plan = value(cells[3]);
      roadmap.outside.push(row);
    } else if (phase) {
      const f = !l.fenced && FIELD.exec(l.text);
      if (f) applyPhaseField(phase, f[1], f[2], l.n, phaseKinds, bad);
      if (!f || !UI_FIELDS.has(f[1])) body.push(l.text);
    } else if (milestone) {
      summary.push(l.text);
    }
  }
  closeMilestone();

  if (sawOutside && !Number.isInteger(roadmap.nextX)) bad.add(1, 'Outside the roadmap is missing its "Next X: <n>" line');
  bad.done(validateRoadmap(roadmap, P));
  for (const m of roadmap.milestones) for (const p of m.phases) delete p.line;
  return roadmap;
}

function applyPhaseField(phase, label, raw, n, phaseKinds, bad) {
  const v = value(raw);
  if (label === 'Status') {
    if (!PHASE_STATUSES.includes(v)) bad.add(n, `${phase.id} status "${raw.trim()}" is not one of ${PHASE_STATUSES.join(' | ')}`);
    phase.status = v;
  } else if (label === 'Kind') {
    if (!phaseKinds.includes(v)) bad.add(n, `${phase.id} kind "${raw.trim()}" is not one of ${phaseKinds.join(' | ')}`);
    phase.kind = v;
  } else if (label === 'Goal') phase.goal = v;
  else if (label === 'Not in scope') { if (v) phase.notInScope = v; }
  else if (label === 'Depends on') phase.dependsOn = v ? v.split(',').map((s) => s.trim()).filter(Boolean) : [];
  else if (label === 'Spec') { if (v) phase.spec = v; }
  else if (label === 'Plan') {
    // Several plans, comma-separated, in the order they run: the first is the current one.
    if (v) [phase.plan] = phase.plans = v.split(',').map((s) => s.trim()).filter(Boolean);
  }
}

export function validateRoadmap(roadmap, idPrefix) {
  const ids = idPatterns(idPrefix);
  const P = ids.prefix;
  const problems = [];
  const open = roadmap.milestones.flatMap((m) => m.phases);
  const outside = roadmap.outside ?? [];
  const seen = new Set();
  for (const id of [...roadmap.milestones.map((m) => m.id), ...open.map((p) => p.id), ...roadmap.completed.map((c) => c.id), ...outside.map((o) => o.id)]) {
    if (seen.has(id)) problems.push(`duplicate id ${id}`);
    seen.add(id);
  }
  for (const c of roadmap.completed) if (!ids.phase.test(c.id)) problems.push(`Completed id "${c.id}" is not ${P}-M<n>.<k>`);
  for (const o of outside) {
    const x = ids.x.exec(o.id);
    if (!x) problems.push(`Outside the roadmap id "${o.id}" is not ${P}-X<n>`);
    if (!o.title) problems.push(`${o.id} has no title`);
    if (!o.spec && !o.plan) problems.push(`${o.id} names neither a spec or plan`);
    if (Number.isInteger(roadmap.nextX) && x && Number(x[1]) >= roadmap.nextX) problems.push(`Next X ${roadmap.nextX} must be greater than ${o.id}`);
  }
  for (const m of roadmap.milestones) {
    if (m.phases.length === 0) problems.push(`${m.id} has no open phase — add one or delete the milestone`);
    if (!m.summary) problems.push(`${m.id} has no summary paragraph`);
    for (const p of m.phases) {
      if (!p.id.startsWith(`${m.id}.`)) problems.push(`${p.id} sits under ${m.id} but its id does not start with ${m.id}.`);
      if (!p.status) problems.push(`${p.id} is missing Status`);
      if (!p.kind) problems.push(`${p.id} is missing Kind`);
      if (!p.goal) problems.push(`${p.id} is missing Goal`);
      if (p.plans && new Set(p.plans).size !== p.plans.length) problems.push(`${p.id} names a plan twice`);
      if (p.status === 'not started' && (p.spec || p.plan)) problems.push(`${p.id} is not started but names a spec or plan`);
      if (p.status === 'specified' && (!p.spec || p.plan)) problems.push(`${p.id} is specified: needs a Spec and no Plan`);
      if ((p.status === 'planned' || p.status === 'in progress') && (!p.spec || !p.plan)) problems.push(`${p.id} is ${p.status}: needs both Spec and Plan`);
      for (const dep of p.dependsOn) if (ids.phase.test(dep) && !seen.has(dep)) problems.push(`${p.id} depends on unknown phase ${dep}`);
    }
  }
  const openIds = new Set(open.map((p) => p.id));
  const inSequence = new Set();
  for (const id of roadmap.sequence) {
    if (!openIds.has(id)) problems.push(`${id} is in Sequence but is not an open phase`);
    if (inSequence.has(id)) problems.push(`${id} appears twice in Sequence`);
    inSequence.add(id);
  }
  for (const id of openIds) if (!inSequence.has(id)) problems.push(`${id} is open but missing from Sequence`);
  return problems;
}

// ───────────────────────── TODO.md ─────────────────────────

export function parseTodos(markdown, conventions) {
  const todoAreas = conventionList(conventions, 'todoAreas', 'parseTodos');
  const ids = idPatterns(conventions.idPrefix);
  const TODO_FILE = conventions.file ?? 'TODO.md';
  const lines = scan(markdown);
  const bad = collector(TODO_FILE);
  const list = { reviewedAt: headerDate(lines, bad), nextId: NaN, todos: [] };
  let todo = null;
  let body = [];
  const close = () => {
    if (!todo) return;
    todo.body = trimBlank(body);
    body = [];
    todo = null;
  };
  for (const l of lines) {
    const h2 = !l.fenced && /^## (.+?)\s*$/.exec(l.text);
    if (h2) {
      close();
      const m = /^(\S+) (.+)$/.exec(h2[1]);
      const n = m && ids.todo.exec(m[1]);
      if (!n) {
        // The entry's lines are skipped: its heading is the problem.
        bad.add(l.n, `heading "${h2[1]}" is not "${ids.prefix}-<n> Title"`);
        continue;
      }
      todo = { id: m[1], number: Number(n[1]), title: m[2], body: '' };
      list.todos.push(todo);
      continue;
    }
    if (!todo) {
      const next = /^Next ID: (\d+)$/.exec(l.text);
      if (next) list.nextId = Number(next[1]);
      continue;
    }
    const f = !l.fenced && FIELD.exec(l.text);
    if (f && f[1] === 'Area') {
      if (!todoAreas.includes(f[2].trim())) bad.add(l.n, `${todo.id} area "${f[2].trim()}" is not one of ${todoAreas.join(' | ')}`);
      todo.area = f[2].trim();
    } else if (f && f[1] === 'Source') todo.source = f[2].trim();
    else if (f && f[1] === 'Added') {
      if (!ISO_DATE.test(f[2].trim())) bad.add(l.n, `${todo.id} Added "${f[2].trim()}" is not YYYY-MM-DD`);
      todo.added = f[2].trim();
    } else body.push(l.text);
  }
  close();
  bad.done(validateTodos(list));
  return list;
}

export function validateTodos(list) {
  const problems = [];
  if (!Number.isInteger(list.nextId)) problems.push('missing "Next ID: <n>" line');
  const seen = new Set();
  for (const t of list.todos) {
    if (seen.has(t.number)) problems.push(`duplicate id ${t.id}`);
    seen.add(t.number);
    for (const field of ['area', 'source', 'added']) {
      if (!t[field]) problems.push(`${t.id} is missing ${field[0].toUpperCase()}${field.slice(1)}`);
    }
    if (Number.isInteger(list.nextId) && t.number >= list.nextId) problems.push(`Next ID ${list.nextId} must be greater than ${t.id}`);
  }
  return problems;
}

// ───────────────────────── ARCHITECTURE.md ─────────────────────────

/** The text of the `## <title>` section of `markdown` (heading excluded), or null. A leading "<n>. " on the heading is allowed. */
export function sectionText(markdown, title) {
  const lines = sectionLines(scan(markdown), title);
  return lines === null ? null : lines.map((l) => l.text).join('\n');
}

/** Lines of the `## <title>` section (heading excluded), or null. A leading "<n>. " on the heading is allowed. */
function sectionLines(lines, title) {
  const start = lines.findIndex((l) => !l.fenced && new RegExp(`^## (?:\\d+\\. )?${title}\\s*$`).test(l.text));
  if (start === -1) return null;
  const rest = lines.slice(start + 1);
  const end = rest.findIndex((l) => !l.fenced && l.text.startsWith('## '));
  return end === -1 ? rest : rest.slice(0, end);
}

export function parseStackSummary(markdown, { file: ARCH_FILE = 'ARCHITECTURE.md' } = {}) {
  const lines = scan(markdown);
  const bad = collector(ARCH_FILE);
  const summary = { reviewedAt: headerDate(lines, bad), areas: [], items: [] };
  const section = sectionLines(lines, 'Stack summary');
  if (!section) {
    bad.add(1, 'missing "## Stack summary" section');
    bad.done();
  }
  let area = null;
  let sawHeader = false;
  for (const l of section) {
    const h3 = !l.fenced && /^### (.+?)\s*$/.exec(l.text);
    if (h3) {
      area = h3[1];
      sawHeader = false;
      summary.areas.push(area);
      continue;
    }
    const cells = tableCells(l.text);
    if (!cells) continue;
    if (!area) {
      bad.add(l.n, 'table row before the first "### <Area>" heading');
      continue;
    }
    if (!sawHeader) { sawHeader = true; continue; }
    if (cells.length !== 4) {
      bad.add(l.n, 'Stack summary rows need 4 cells: Item, Status, Note, Ref');
      continue;
    }
    const [item, status, note, ref] = cells;
    if (status !== 'current' && status !== 'planned') bad.add(l.n, `status "${status}" is not current | planned`);
    if (!item) bad.add(l.n, 'empty Item cell');
    const row = { area, item, planned: status === 'planned' };
    if (value(note)) row.note = value(note);
    if (value(ref)) row.ref = value(ref);
    summary.items.push(row);
  }
  if (summary.items.length === 0) bad.add(1, 'Stack summary has no rows');
  bad.done();
  return summary;
}

export function parsePlannedMigrations(markdown, { file: ARCH_FILE = 'ARCHITECTURE.md', idPrefix } = {}) {
  const phase = idPatterns(idPrefix).phase;
  const bad = collector(ARCH_FILE);
  const section = sectionLines(scan(markdown), 'Planned migrations');
  if (!section) {
    bad.add(1, 'missing "## Planned migrations" section');
    bad.done();
  }
  const ids = [];
  for (const l of section) {
    if (!l.text.startsWith('- ')) continue;
    const m = /^- \*\*(\S+) /.exec(l.text);
    if (m && phase.test(m[1])) ids.push(m[1]);
    else bad.add(l.n, `Planned migrations bullets must start "- **${idPrefix}-M<n>.<k> Title**"`);
  }
  bad.done();
  return ids;
}
