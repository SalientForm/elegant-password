/**
 * The onboarding's own proposals (spec WW-M1 §5, the table's last row): the top-level settings and the Readme area,
 * read off the repository before the workspace config exists. `wayfinder-onboard` writes them into the config; the
 * branch, the ports and the header links it judges (its §1).
 */
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { suggestIdPrefix } from './audit-markdown.mjs';
import { gitRoot } from './hosted.mjs';
import { fixtureRoots, underAny } from './propose-audit.mjs';
import { readJsonFile, readText, unique } from './repo-files.mjs';

/**
 * A git remote's URL as the https URL of its repository (`git@host:org/repo.git` → `https://host/org/repo`). `resolve`
 * turns an SSH host into its real name (an alias from `~/.ssh/config`); by default the host stays as written.
 */
export function httpsUrl(remote, resolve = (host) => host) {
  const url = remote.trim().replace(/\.git$/, '').replace(/\/$/, '');
  const scp = /^(?:[\w.-]+@)?([\w.-]+):(?!\/)(.+)$/.exec(url);
  if (scp && !/^[a-z]+:\/\//i.test(url)) return `https://${resolve(scp[1])}/${scp[2]}`;
  const m = /^(ssh|git|https?):\/\/(?:[^@/]+@)?([^/:]+)(?::\d+)?\/(.+)$/i.exec(url);
  if (!m) return undefined;
  return `https://${/^https?$/i.test(m[1]) ? m[2] : resolve(m[2])}/${m[3]}`;
}

/** An SSH host's real name: the `hostname` line of `ssh -G <host>` (local, no connection), else the host itself. */
function sshHostname(host) {
  try {
    const out = execFileSync('ssh', ['-G', host], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 5000 });
    return /^hostname (\S+)$/m.exec(out)?.[1] ?? host;
  } catch {
    return host;
  }
}

/** A package name in a README's title (`@acme/billing-api`): the name, as words (`Billing api`) — or the title as is. */
function productName(title) {
  if (!/^@?[\w.-]+(\/[\w.-]+)?$/.test(title) || !/[-_/@]/.test(title)) return title;
  return title.replace(/^@[^/]+\//, '').split(/[-_.]+/).filter(Boolean).map(titled).join(' ');
}

const git = (root, args) => {
  try {
    return execFileSync('git', args, { cwd: gitRoot(root), encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
  } catch {
    return undefined;
  }
};

/** A title for a directory name: `design-system` → `Design system`. */
const titled = (name) => name.charAt(0).toUpperCase() + name.slice(1).replace(/[-_]+/g, ' ');

/** The README's title, its first `# ` heading without markup, or undefined. */
export function readmeTitle(markdown) {
  const m = /^# +(.+?)\s*#*\s*$/m.exec(markdown ?? '');
  return m ? m[1].replace(/[*_`]/g, '').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').trim() || undefined : undefined;
}

/**
 * The proposal for the onboarding: `ctx` is `{ root, files, workspaceDir, skillsDir }`.
 * - `product`: the root README's title, else the root package's name without its scope; `title`: `<product> Workspace`.
 * - `repository.url`: the `origin` remote as https (an SSH host alias is the user's to resolve, the skill's §1).
 * - `areas.audit.idPrefix`: the initials of the repository's name (`suggestIdPrefix`), for the user to confirm.
 * - `areas.readme.sections`: one per top-level directory holding READMEs below the root (fixtures, the workspace app,
 *   the skills and agent directories aside), and the `readmes` collection covering them.
 * Judged: the branch, the ports and the header links.
 */
export function proposeOnboard({ root, files, workspaceDir, skillsDir = '.agents/skills' }) {
  const entries = [];
  const notes = [];
  const pkg = readJsonFile(root, 'package.json') ?? {};
  const title = readmeTitle(readText(root, 'README.md'));
  const name = typeof pkg.name === 'string' ? pkg.name : undefined;
  const product = title ? productName(title) : name ? productName(name) : path.basename(root);
  entries.push({ setting: 'product', value: product, from: title ? "README.md's title" : name ? 'package.json name' : 'the directory name' });
  entries.push({ setting: 'title', value: /\bworkspace\b/i.test(product) ? product : `${product} Workspace`, from: 'the product' });

  const remote = git(root, ['remote', 'get-url', 'origin']);
  const url = remote ? httpsUrl(remote, sshHostname) : undefined;
  if (url) entries.push({ setting: 'repository.url', value: url, from: `the origin remote (${remote}), its SSH host resolved by ssh -G` });
  else notes.push('no origin remote: ask the user for the repository\'s https URL');
  const head = git(root, ['symbolic-ref', '--short', 'refs/remotes/origin/HEAD']);
  const repoName = url ? url.split('/').pop() : path.basename(root);
  entries.push({ setting: 'areas.audit.idPrefix', value: suggestIdPrefix(repoName), from: `the initials of ${repoName}; ask the user to confirm` });

  const skip = [
    ...fixtureRoots(files),
    ...(workspaceDir ? [`${workspaceDir}/`] : []),
    `${skillsDir}/`,
    '.agents/',
    '.claude/',
    '.opencode/',
    'node_modules/',
  ];
  const readmes = files.filter((file) => /(^|\/)README\.md$/.test(file) && file.includes('/') && !underAny(file, skip));
  const tops = unique(readmes.map((file) => file.split('/')[0])).sort();
  const sections = tops.map((top) => ({ title: titled(top), prefix: `${top}/` }));
  entries.push({
    setting: 'areas.readme.sections',
    value: sections,
    from: sections.length > 0 ? `${readmes.length} READMEs below the root` : 'no README below the root',
  });
  entries.push({
    setting: 'content.readmes',
    value: ['README.md', ...tops.map((top) => `${top}/**/README.md`)],
    from: 'the root README and the sections',
  });
  entries.push({
    setting: 'areas.readme.description',
    value:
      sections.length > 0
        ? `The repository README and the READMEs under ${tops.map((t) => `${t}/`).join(', ')}, rendered from source.`
        : 'The repository README, rendered from source.',
    from: 'the sections',
  });

  return {
    summary: `${product}, ${readmes.length + 1} READMEs`,
    entries,
    judged: [
      { setting: 'repository.branch', rule: `the branch work integrates into; ask when unsure${head ? ` (origin's default is ${head.replace(/^origin\//, '')})` : ''}` },
      { setting: 'ports', rule: 'two free ports from the repository\'s port rules, else a ledger, else 20000–32767 (the skill\'s §1)' },
      { setting: 'links', rule: 'the repository\'s other front ends, with their dev ports and deployed paths' },
      { setting: 'areas.readme.sections', rule: 'drop a section whose READMEs are not the repository\'s packages or libraries' },
    ],
    notes,
    writes: [],
  };
}
