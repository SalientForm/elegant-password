/**
 * The first-run runner (spec WW-M1 §5): every skill's propose.mjs is `await runPropose('<name>')`, as every check script
 * is `runCheck('<name>')`. It reads the repository (and the workspace config and hooks file, where they exist), and
 * prints what a script can derive without judgement:
 *
 *  - the settings, as a table (Setting, Proposed, From) the skill writes into the workspace config, and opens its
 *    REPOSITORY.md with; no script edits the config, which is TypeScript with comments
 *  - what is left to judgement, each with the rule the skill applies, recorded in its REPOSITORY.md
 *  - the registries a script builds or drafts, which `--write` writes (the About manifest, the route mirror, the API
 *    registry, the feature audit)
 *
 * `--json` prints the proposal as JSON instead. Two runs on the same repository print the same.
 *
 * Proposals: onboard, audit, features, feature-audit, api, platform-docs, workspace.
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { proposeWorkspace } from './about-manifest.mjs';
import { exists, loadWorkspaceHooks, loadWorkspaceSettings, readRepo, repoRoot, today } from './index.mjs';
import { proposeApi } from './propose-api.mjs';
import { proposeAudit } from './propose-audit.mjs';
import { proposeFeatureAudit } from './propose-feature-audit.mjs';
import { proposeFeatures } from './propose-features.mjs';
import { proposeOnboard } from './propose-onboard.mjs';
import { proposePlatformDocs } from './propose-platform-docs.mjs';
import { readJsonFile, readText, repoFiles } from './repo-files.mjs';
import { aboutSettings } from './settings-defaults.mjs';

/** Each proposal: ctx → { summary, entries: { setting, value, from }[], judged: { setting, rule }[], notes, writes }. */
export const PROPOSALS = {
  onboard: proposeOnboard,
  audit: proposeAudit,
  features: proposeFeatures,
  'feature-audit': proposeFeatureAudit,
  api: proposeApi,
  'platform-docs': proposePlatformDocs,
  workspace: proposeWorkspace,
};

/**
 * The workspace app's directory, from the config's path: `<ws>/src/workspace.config.mts` → `<ws>` (the onboarding's
 * layout), else the config's directory.
 */
export function workspaceDirOf(configFile) {
  if (typeof configFile !== 'string') return undefined;
  const dir = path.posix.dirname(configFile);
  return path.posix.basename(dir) === 'src' ? path.posix.dirname(dir) : dir;
}

/** The context every proposal reads, for the repository at `root`. */
export async function proposalContext(root = repoRoot, { settings, hooks } = {}) {
  const packageJson = readJsonFile(root, 'package.json');
  const configFile = packageJson?.wayfinder?.config;
  if (settings === undefined && configFile !== undefined && root === repoRoot) {
    settings = await loadWorkspaceSettings();
    hooks = await loadWorkspaceHooks();
  }
  const workspaceDir = workspaceDirOf(configFile);
  const skillsDir = settings ? aboutSettings(settings.areas.about).skillsDir : undefined;
  return { root, files: repoFiles(root), settings, hooks: hooks ?? {}, packageJson, workspaceDir, skillsDir, today };
}

const cell = (text) => String(text).replace(/\|/g, '\\|');

/** The proposal as the runner prints it: its summary, the settings table, the judged settings, the notes and files. */
export function describeProposal(name, proposal, { written = [], root = repoRoot } = {}) {
  const lines = [`${name} proposals — ${proposal.summary}`];
  if (proposal.entries.length > 0) {
    lines.push('', '| Setting | Proposed | From |', '| --- | --- | --- |');
    for (const { setting, value, from } of proposal.entries) lines.push(`| \`${cell(setting)}\` | \`${cell(JSON.stringify(value))}\` | ${cell(from)} |`);
  }
  if (proposal.judged.length > 0) lines.push('');
  for (const { setting, rule } of proposal.judged) lines.push(`judged: ${setting} — ${rule}`);
  if (proposal.notes.length > 0) lines.push('');
  for (const note of proposal.notes) lines.push(note);
  if (proposal.writes.length > 0) lines.push('');
  for (const { file, text, what } of proposal.writes) {
    const same = readText(root, file) === text;
    lines.push(written.includes(file) ? `wrote: ${file} — ${what}` : same ? `up to date: ${file} — ${what}` : `would write: ${file} — ${what} (run with --write)`);
  }
  return lines.join('\n');
}

/** Writes each of `writes` that differs from the file, and returns the paths written. */
export function writeProposal(root, writes) {
  const written = [];
  for (const { file, text } of writes) {
    if (readText(root, file) === text) continue;
    mkdirSync(path.dirname(path.join(root, file)), { recursive: true });
    writeFileSync(path.join(root, file), text);
    written.push(file);
  }
  return written;
}

/** Runs proposal `name` in the repository the process runs in, and prints it (see the header). */
export async function runPropose(name, argv = process.argv.slice(2)) {
  const propose = PROPOSALS[name];
  if (!propose) throw new Error(`wayfinder: no proposal ${name} (${Object.keys(PROPOSALS).join(', ')})`);
  const ctx = await proposalContext();
  const proposal = propose({ ...ctx, readRepo, exists });
  if (argv.includes('--json')) {
    console.log(JSON.stringify({ name, ...proposal, writes: proposal.writes.map(({ file, what }) => ({ file, what })) }, null, 2));
    return;
  }
  const written = argv.includes('--write') ? writeProposal(ctx.root, proposal.writes) : [];
  console.log(describeProposal(name, proposal, { written, root: ctx.root }));
}
