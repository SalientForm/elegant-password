/**
 * The defaults of the optional settings that both the node checks and the browser modules read (spec M12.11 §6.1),
 * in one place so the two never disagree. Plain values; `settings.ts` documents each field.
 */
import { ID_PREFIX } from './audit-markdown.mjs';

/**
 * `settings.areas.<about>`: where the skills live (the agent-neutral `.agents/skills`, spec M12.11 §6.14), the agent
 * directories that hold a link per kit skill (`.claude/skills`, for Claude Code), and which root package.json script
 * runs the checks.
 */
export const ABOUT_DEFAULTS = { skillsDir: '.agents/skills', skillLinks: ['.claude/skills'], checkScript: 'workspace:check' };

/**
 * `settings.areas.<audit>`: the directories of specs and plans (the first holds specs, the others plans; a document
 * directly in one carries a Milestone line), the folder of the review files, tracked paths left out of the markdown set,
 * and paths whose links are not checked.
 */
export const AUDIT_DEFAULTS = { specDirs: ['docs/specs', 'docs/plans'], reviews: 'docs/reviews', ignore: [], linkExempt: [] };

/** A repository-relative directory: not absolute, no empty, '.' or '..' segment, no trailing slash. */
const isRepoDir = (dir) =>
  typeof dir === 'string' && dir !== '' && !dir.startsWith('/') && dir.split('/').every((s) => s !== '' && s !== '.' && s !== '..');

/**
 * The problems of `skillLinks` beside `skillsDir`: a list of repository-relative directories, none equal to
 * `skillsDir` or inside it, none repeated (`[]`: no links). `at` names the about settings in each problem.
 */
export function skillLinksProblems(skillsDir, skillLinks, at = 'settings.areas.about') {
  if (!isRepoDir(skillsDir)) return [`${at}.skillsDir ${JSON.stringify(skillsDir)} is not a repository-relative directory`];
  if (!Array.isArray(skillLinks)) return [`${at}.skillLinks is not a list of directories`];
  const problems = [];
  const seen = new Set();
  skillLinks.forEach((dir, i) => {
    const where = `${at}.skillLinks[${i}] ${JSON.stringify(dir)}`;
    if (!isRepoDir(dir)) problems.push(`${where} is not a repository-relative directory`);
    else if (dir === skillsDir) problems.push(`${where} is the skills directory itself`);
    else if (dir.startsWith(`${skillsDir}/`)) problems.push(`${where} is inside the skills directory ${skillsDir}`);
    else if (seen.has(dir)) problems.push(`${where} repeats`);
    seen.add(dir);
  });
  return problems;
}

/** `about` with its defaults applied; throws on a `skillsDir` or `skillLinks` that breaks `skillLinksProblems`. */
export function aboutSettings(about) {
  const settings = { ...ABOUT_DEFAULTS, ...about };
  const problems = skillLinksProblems(settings.skillsDir, settings.skillLinks);
  if (problems.length > 0) throw new Error(`wayfinder: ${problems.join('; ')}`);
  return settings;
}

/**
 * The Audit area's required settings: the roadmap, the TODO list and the architecture document, which
 * the `document-repo` skill writes, the vocabularies their entries take, and the prefix their ids carry.
 * `[setting, what]`.
 */
export const AUDIT_REQUIRED = [
  ['roadmap', 'the roadmap'],
  ['todo', 'the TODO list'],
  ['architecture', 'the architecture document'],
  ['phaseKinds', "the values a roadmap phase's Kind takes"],
  ['todoAreas', "the values a TODO entry's Area takes"],
  ['idPrefix', 'the prefix every roadmap and TODO id carries (ACME for ACME-M1.2 and ACME-4)'],
];


/**
 * `audit` with its defaults applied; throws on `ledger` or `documents`, which are markdown now (spec M12.11 §6.15), and
 * on a required setting that is missing (`AUDIT_REQUIRED`).
 */
export function auditSettings(audit) {
  for (const key of ['ledger', 'documents'])
    if (audit[key] !== undefined) throw new Error(`wayfinder: areas.audit.${key} is gone: the ledger is markdown since §6.15 (reviews)`);
  for (const [key, what] of AUDIT_REQUIRED)
    if (audit[key] === undefined)
      throw new Error(
        `wayfinder: areas.audit.${key} is required (${what}); the document-repo skill writes the roadmap, the TODO list and the architecture document`,
      );
  if (typeof audit.idPrefix !== 'string' || !ID_PREFIX.test(audit.idPrefix))
    throw new Error(
      `wayfinder: areas.audit.idPrefix ${JSON.stringify(audit.idPrefix)} is not upper-case letters and digits starting with a letter (ACME, ABA)`,
    );
  return { ...AUDIT_DEFAULTS, ...audit };
}

/** The six areas every workspace has, by their keys in `settings.areas`, in header order (WW-M1.3; Monitor left in 0.3.0). */
export const WORKSPACE_AREAS = ['readme', 'audit', 'features', 'api', 'platform-docs', 'about'];

/** The areas that may be a placeholder: Readme, Audit and About are always generated. */
export const PLACEHOLDER_AREAS = ['features', 'api', 'platform-docs'];

/**
 * The problems of `value` as a placeholder (`{ reason, toFill }`, two non-empty strings, nothing else); `at` names it in
 * each problem.
 */
export function placeholderProblems(value, at) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return [`${at} is not { reason, toFill }`];
  const problems = [];
  for (const key of ['reason', 'toFill'])
    if (typeof value[key] !== 'string' || value[key].trim() === '') problems.push(`${at}.${key} is not a non-empty sentence`);
  for (const key of Object.keys(value))
    if (key !== 'reason' && key !== 'toFill') problems.push(`${at}.${key} is not a placeholder field (reason, toFill)`);
  return problems;
}

/**
 * True when `area` (an entry of `settings.areas`) is a placeholder area; throws when its placeholder is invalid or
 * stands beside settings of the real area. `at` names the area in each problem.
 */
export function isPlaceholderArea(area, at) {
  if (area?.placeholder === undefined) return false;
  const problems = placeholderProblems(area.placeholder, `${at}.placeholder`);
  const extra = Object.keys(area).filter((key) => !['placeholder', 'title', 'description'].includes(key));
  if (extra.length > 0) problems.push(`${at} is a placeholder, so it takes no ${extra.join(', ')} (only title and description)`);
  if (problems.length > 0) throw new Error(`wayfinder: ${problems.join('; ')}`);
  return true;
}

/** The Features area's coverage section when the settings name no coverage summaries. */
export const NO_COVERAGE = {
  reason: 'No coverage summary is configured (areas.features.coverage).',
  toFill: 'Have the test runner write a json-summary coverage report, then run assess-features to set coverage.summaries.',
};

/** The Audit area's Features page when the repository keeps no feature audit (`areas.audit.featureAudit`). */
export const NO_FEATURE_AUDIT = {
  reason: 'No feature audit is kept (areas.audit.featureAudit): nothing has swept the product for dead code, unreachable pages or stale TODOs.',
  toFill: 'Run assess-feature-audit, which writes the feature audit and sets areas.audit.featureAudit.',
};

/** A placeholder as the checks print it: `placeholder: <where> — <reason> To fill: <toFill>`. */
export function describeSettingsPlaceholder(where, { reason, toFill }) {
  return `placeholder: ${where} — ${reason} To fill: ${toFill}`;
}

/**
 * The command that runs a root package.json script, from its `packageManager` field: `pnpm <script>`, `yarn <script>`,
 * `bun run <script>`, otherwise `npm run <script>`.
 */
export function scriptCommand(packageJson, script) {
  const manager = String(packageJson?.packageManager ?? '').split('@')[0];
  if (manager === 'pnpm' || manager === 'yarn') return `${manager} ${script}`;
  if (manager === 'bun') return `bun run ${script}`;
  return `npm run ${script}`;
}
