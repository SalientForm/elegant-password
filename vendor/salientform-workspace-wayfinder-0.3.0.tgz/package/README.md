# @salientform/workspace-wayfinder

Workspace Wayfinder: an engineering workspace a repository runs as its own small Vite app. Areas for the roadmap,
specs and every markdown file (Audit), READMEs, a feature catalogue with its tests and coverage, an API reference,
plain-language product docs and environments, each built from the repository's files at build time, and skills with check scripts that keep them true to the code. The kit holds the shell, the area contract, the
area modules, the Vite plugins, the check library, the skills and the default About prose; a repository supplies its
configuration, its registries and its theme mapping. It assumes JavaScript or TypeScript with Vite.

- **Releases are tarballs:** each version is a `.tgz` attached to a GitHub Release of the kit's repository (the
  `repository` in its `package.json`), with its sha256. There is no registry: a repository commits the tarball under
  `vendor/` and depends on it by that path, so installs need no token anywhere
- **Proprietary:** `LICENSE` grants no licence; the package is `private` and `UNLICENSED`, and is never published
- **Six areas, no Design System or Monitor:** a design system shows a product's look, so it is the repository's own
  app, and the workspace's header can link to it (`links`). Monitor, which showed each deployed environment's build,
  left in 0.3.0: a deployment's status is its host's to show

## In a repository

Start from the repository root of a git checkout, on Linux, macOS or WSL, with Node 22.18 or later. Download the
release's tarball into `vendor/` (from the Releases page of the kit's repository, or with the GitHub CLI), then:

```bash
gh release download v<version> --repo <owner>/workspace-wayfinder --pattern '*.tgz' --dir vendor
pnpm add -D file:vendor/salientform-workspace-wayfinder-<version>.tgz
pnpm exec wayfinder init   # installs the wayfinder-onboard skill alone, linked from .claude/skills
```

The onboarding skill installs the rest the app needs (TanStack Router, and any peer the repository lacks:
"What the workspace app needs beside the kit", below).

**Commit the tarball.** `vendor/salientform-workspace-wayfinder-<version>.tgz` is committed with `package.json` and the
lockfile, which name it by that relative path (`file:vendor/…`) with its integrity hash. So `pnpm install
--frozen-lockfile` works in every checkout, in CI and in an image built from the repository, with no registry and no
token. Keep `vendor/` and `*.tgz` out of the ignore files of anything that builds from the repository (`.gitignore`,
`.dockerignore`, a deploy tool's own). The release's `.sha256` file checks the download (`sha256sum -c`, run in
`vendor/`).

**Exclude the kit from pnpm's release-age policy.** pnpm 11 checks a lockfile's entries against `minimumReleaseAge`
on an install it has not verified before (CI, an image build), asking the registry when each version was published.
The registry has no such package, so the install fails (`ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION`, a 404). Name the
kit in `pnpm-workspace.yaml` (a single-package repository can have one for settings alone):

```yaml
minimumReleaseAgeExclude:
  - '@salientform/workspace-wayfinder'
```

**Upgrading.** Download the new version's tarball into `vendor/`, then:

```bash
pnpm add -D file:vendor/salientform-workspace-wayfinder-<new>.tgz
git rm vendor/salientform-workspace-wayfinder-<old>.tgz
pnpm skills:install         # the kit's skills as the new version ships them
pnpm workspace:check        # or the repository's areas.about.checkScript
```

Commit the new tarball, `package.json`, the lockfile and the skills' changes together. A release changes the installed
skills only through `skills:install`; review its diff like any other.

**Upgrading from 0.2.0 to 0.3.0.** It changes what a valid workspace is, in three steps that ship together: the
roadmap, the TODO list and the architecture document become required (the document pattern), every area is present
(a placeholder where the repository cannot support one yet), and the skills build the registries, the detailed settings
and the About manifest. A workspace that misses one stops loading, or fails its checks, until it has it:

- `areas.audit` names `roadmap`, `todo`, `architecture`, `phaseKinds` and `todoAreas`; without one the workspace
  throws at load (`areas.audit.<setting> is required`) and the config fails to typecheck.
- Run the `document-repo` skill: it writes whichever of the eight documents (`docs/formats.md`, "The document set") the
  repository lacks, from what it already says, and moves an existing roadmap or TODO list into the format. The
  architecture document gains four required sections, `Overview`, `Repository layout`, `Running it` and `Deployment`
  (a placeholder where there is nothing to say yet).
- Every spec and plan in `specDirs` needs its `**Milestone:**` line, now that there is always a roadmap.
- Add `node <skillsDir>/document-repo/scripts/check-documents.mjs` to the check script (`workspace:check`). The About
  manifest's ROADMAP.md, TODO.md and ARCHITECTURE.md rows belong in every manifest, and read the Audit module without
  `?.` now that all three always parse. `skills:install` installs the `todo` skill with every Audit area.
- Every roadmap and TODO id carries the repository's prefix (`docs/formats.md`, "Ids"): set `areas.audit.idPrefix`
  (upper-case letters and digits, starting with a letter; the initials of the repository's name are the usual choice)
  and rewrite every id in the repository's markdown in the same change: `M2.4` becomes `<P>-M2.4`, `X3` becomes
  `<P>-X3` and `#12` becomes `<P>-12`, in the roadmap's headings and rows, the TODO list's headings, every
  `**Milestone:**` line, every review's `tracked`, the architecture document's stack `Ref`s and Planned migrations
  (whose roadmap anchors gain the prefix too), and in prose. An id another repository owns keeps its own form. The
  parser and the checks refuse an id without the prefix.
- Every area is in every workspace: Readme, Audit, Features, API, Platform Docs and About. One the repository
  cannot support yet is a placeholder, `{ placeholder: { reason, toFill } }` in `areas`, which shows its reason and what
  would fill it in place of its pages. Add the missing areas to `areas` (as placeholders, or with their settings), to
  `workspace.tsx`, `router.tsx` and the About manifest (an empty entry for a placeholder), register the Features
  plugins `featureSources()`, `testInventory()` and `featureCoverage()` in the Vite config (each serves an empty module
  for a placeholder), and add the Features, API and Platform Docs checks to the check script: a placeholder area's
  check passes and prints the placeholder. The onboarding templates show every line. The About check fails while one
  of the six is missing from `areas`.
- `skills:install` installs all nine skills, whatever the areas. List each in the About manifest's `ABOUT_SKILLS`:
  the About check fails on a kit skill that is not installed or not listed.
- Monitor is gone, and with it the `@tanstack/react-query` peer. Delete `areas.monitor` from the config (the About
  check fails while it holds Monitor's settings), the `createMonitorArea` and `monitorRoute` lines from `workspace.tsx`
  and `router.tsx`, the `QueryClientProvider` from `main.tsx`, `query-client.ts`, and the router's `queryClient`
  context (`createWorkspaceRoutes<object>`, `context: {}`), then rebuild the About manifest. Keep
  `@tanstack/react-query` only if the app uses it itself.
- The checks print every placeholder after their OK line (`placeholder: <where> — <reason> To fill: <what>`) and pass;
  run one with `--strict` to fail on them. About's Placeholders page lists them all.
- The registries and detailed settings are built by the skills (`docs/formats.md`, "Registries built by the skills").
  Every skill but `todo` and `document-repo` gains `scripts/propose.mjs`, which `skills:install` installs: it prints the
  settings it reads off the repository and, with `--write`, writes the registries it builds or drafts.
- The About manifest is built, never written: run `node <skillsDir>/assess-workspace/scripts/propose.mjs --write` to
  replace a hand-written one, and again whenever the config, the check script or the installed skills change. The
  About check fails while the manifest differs from a fresh build. The build assumes the onboarding's layout: the
  manifest beside the app's `audit.ts` and `features.ts`, which create the two areas it reads for counts, and the app's
  `vite.config.ts` one directory up. A row the build does not make (a registry of the repository's own) has no place in
  it.
- The onboarding no longer has `templates/about-manifest.ts` or `templates/product-routes.json`: the manifest comes
  from that build and the route mirror from `assess-features`' `propose.mjs --write`, which writes it from the hooks
  file's `productRoutes` hook. A TanStack Router `createRoute` tree reads with the kit's `tanstackRoutes`
  (`@salientform/workspace-wayfinder/check/route-readers.mjs`).
- A Platform Docs page may open with a placeholder (one `assess-platform-docs` drafted opens with one until a person
  has read it): the Platform Docs check prints it after its OK line, About's Placeholders page lists it under the
  area, and a malformed one fails the check.

**What the workspace app needs beside the kit** (the onboarding skill's §3 step 1 installs those the repository lacks,
as dev dependencies in a single-package repository). The kit's peer dependencies: `react` and `react-dom` 19, `vite` 7
or 8, `@tanstack/react-router` and `@tanstack/router-core`; `vitest` 3 or 5 and
`@testing-library/react` only for tests that use the kit's `./testing` helpers; `typescript` 5 or 7, and 5 for the
Features area's test inventory, which parses test files with its compiler API (TypeScript 7's package has none: on 7
alone the area's tests are a placeholder: the kit loads the one package of that name, so a repository on 7 cannot
add 5 beside it). The app's own, which its templates
use but the kit does not import: `@vitejs/plugin-react`, and with Tailwind v4, `tailwindcss` and `@tailwindcss/vite`.

**The toolchain it is proved on:** Node 22.18 or later, React 19, Vite 7 and 8, Vitest 3 and 5, and TypeScript 5.9 and 7
typechecking the app against the kit's declarations; pnpm. **Tailwind is optional:** an app with Tailwind v4 imports
`./tailwind.css`, so its own build compiles the kit's classes with its theme; an app without it imports the compiled
`./styles.css` and installs no Tailwind. The onboarding skill writes either, from what it finds.

Then ask the repository's coding agent to run the `wayfinder-onboard` skill. `wayfinder init [--skills-dir <dir>]`
installs that one skill into the skills directory (`.agents/skills` by default) byte for byte as the installer would,
and links it from `.claude/skills`; run again, it updates it. The skill does the rest: it discovers the repository's
shape, decides which areas it can fill and which are placeholders, writes the files below from its templates, adds the root script `skills:install`
(`node node_modules/@salientform/workspace-wayfinder/check/install-skills.mjs`) and runs it to install the skills,
then runs each area's skill on its first run, which builds the area's registry from nothing and derives its detailed
settings from the repository (no registry is written by hand), the About manifest last. From then on that script owns the skills: once
`package.json` names `wayfinder.config`, `wayfinder init` installs nothing and points at it. What a repository holds:

| File | What it is |
| --- | --- |
| root `package.json` `wayfinder` | `config`: the workspace config's path; `hooks`: the hooks file's, when there is one (`rules`, its name before 0.3.0, is still read) |
| the workspace config (`workspace.config.mts`) | the data half: `WorkspaceSettings` (`dist/settings.d.ts` in the package documents every field), read by Vite, the browser and the checks; among them the workspace's `ports`, assigned at setup and never a default, and optional header `links` to the repository's other apps served beside the workspace (on the page's host at another port in development, at its `path` on the same origin in a build, and not at all in a build when it has none; an app on another origin is not linked) |
| the hooks file (`workspace.hooks.mjs`) | optional: functions the checks call for what they cannot read for themselves, the product's routes (`productRoutes`), its navigation labels (`navLabels`) and the API paths it calls (`fetchSites`), and for any checks of the repository's own (`extraChecks`); `check/index.d.mts` |
| the workspace app | `create…Area` per area (all six, a placeholder where the repository cannot support one yet), `createWorkspace`, the router, `WorkspaceShell`, the Vite plugins its areas need, and the theme: the kit's (`startTheme()` and `ThemeToggle`, below) or the repository's own |
| registries | the JSON and markdown files the areas read (the spec ledger and reviews, the feature audit, the API registry, the route mirror, the roadmap and TODO list, all in `docs/formats.md`'s formats), each built by its area's skill on its first run: the skill's `scripts/propose.mjs` prints the settings it reads off the repository and writes what a script can build or draft (`--write`), and the skill judges the rest |
| the About manifest | the workspace's own record of its areas' registries and skills, built whole by `assess-workspace` (`propose.mjs --write`) from the config and the installed skills; the About check fails while it differs from a fresh build |
| the document set | eight documents in the repository's `docs` folder, written by the `document-repo` skill from what the repository says, with a placeholder where it says nothing yet: about, skills, architecture, roadmap, features, TODO, setup and issues (`docs/formats.md`, "The document set"). The roadmap, the TODO list and the architecture document are required: Audit reads them |
| reviews (`areas.audit.reviews`, default `docs/reviews`) | a markdown folder: `index.md` (date, All markdowns sections, Documentation list) and one `<path>.review.md` per reviewed document. A content collection must cover it |
| About prose | `<areas.about.prose>/<name>.md`, only where the kit's default (`prose/`) says something untrue for the repository |
| skills | the kit's nine skills, copied into the skills directory (`areas.about.skillsDir`, default `.agents/skills`) by the root script `skills:install` (`node node_modules/@salientform/workspace-wayfinder/check/install-skills.mjs`), with a relative symlink per skill in each agent directory of `areas.about.skillLinks` (default `['.claude/skills']`); the repository's own rules for one go in `REPOSITORY.md` beside it, which the installer never touches |
| the check script | `workspace:check` (or `areas.about.checkScript`): one `node <skillsDir>/<skill>/scripts/<check>.mjs` per area that has a check, each a `runCheck('<name>')`, and the document set's `document-repo/scripts/check-documents.mjs`; each prints the placeholders it finds after its OK line, and fails on them only with `--strict` |

**With a task runner that caches.** The workspace's build and its checks read files outside the app's folder: the
documents and READMEs its content collections name, the reviews folder, the registries, the skills directory, the
workspace config and the hooks file, and the root `package.json`. A task runner that caches or skips tasks by their
inputs does not count those as the app's inputs unless it is told: declare them as inputs of the workspace's build,
preview, test and check tasks, or leave those tasks uncached. Otherwise a change to a document alone is answered from
the cache, and the build shows the old page.

### Light and dark

The kit's dark theme is the `dark` class on `<html>`, and `@salientform/workspace-wayfinder/theme` is what sets it in
a workspace without a theme system of its own; the onboarding templates wire both halves:

- `startTheme()`, called in the app's entry before it renders, so the first paint is right: it applies the reader's
  remembered choice, or their system setting (`prefers-color-scheme`) until they choose, and keeps following system
  changes while nothing is chosen, and choices made in other tabs.
- `ThemeToggle`, passed as the workspace's `headerActions`: the header's button, named for what it does ("Switch to
  dark theme"), which switches between light and dark and remembers the choice in localStorage (`ws:theme`; where
  storage is unavailable, for the session).

`useTheme()`, `setTheme()` and `resetTheme()` (back to the system setting) are there for a control of the repository's
own design. A repository whose product has a theme system uses none of this: it renders its provider around the shell,
sets the `dark` class from it and passes its own control as `headerActions`, so the workspace changes theme with the
product; it never loads this entry.

### Skills for any agent

The skills are in the shared skill format (a directory with a `SKILL.md`) that Claude Code, Codex and opencode all
read; only where each looks differs. The installer copies all nine into the skills directory, whatever the areas
(every area is present, and an area's skill is what fills its placeholder), by default the agent-neutral
`.agents/skills`, which Codex (from the working directory up to the repository root) and opencode read.
For every agent directory in `skillLinks` it makes `<dir>/<name>` → the relative path to `<skillsDir>/<name>`
(`.claude/skills/todo` → `../../.agents/skills/todo`, for Claude Code), so an agent directory keeps skills of its own
beside the kit's. It replaces a link that points elsewhere, removes a link into the skills directory whose skill is
gone, and moves a kit skill installed in an agent directory before the links (a real directory there) into the
skills directory, `REPOSITORY.md` with it; when both exist it stops and names the two. It touches no skill or link
that is not the kit's. The links are committed (git stores symlinks as such), so git must not ignore them: the
installer refuses and the About check fails while it does. A repository that ignores an agent directory whole (often
`.claude/`, for agents' scratch worktrees) narrows the rule to what stays local: `.claude/worktrees/`,
`.claude/settings.local.json`.

**Linux, macOS or WSL.** The links are symlinks, which a Windows checkout without symlink support turns into text
files, so the installer (and `wayfinder init`, which uses it) refuses to write unless `process.platform` is `linux`
or `darwin` (WSL reports `linux`). `--check` and the checks only read, and run anywhere. The About check fails while a copy
differs from the kit's, a link is missing, is a copy or points elsewhere, or the check script runs a kit skill through
an agent directory.

## Subpaths

| Subpath        | What it is                                                                        |
| -------------- | --------------------------------------------------------------------------------- |
| `.`            | the browser entry (`dist/index.js`)                                               |
| `./vite`       | the Vite plugins (node side; the browser entry never imports them): `wayfinder()`, the content manifest and the dev and preview ports (`WAYFINDER_E2E_PORTS=<dev>,<preview>` wins over the config's, for a browser test run), `featureSources()`, the Features source scan, `testInventory()`, the Features test inventory, and `featureCoverage()`, the Features coverage summaries |
| `./testing`    | render and router helpers for a consumer's tests, and `stubSystemScheme`, the reader's system colour scheme under jsdom |
| `./theme`      | the kit's light and dark theme, for a workspace without a theme system of its own: `startTheme()` for the app's entry, `ThemeToggle` for `headerActions`, and `useTheme()`, `setTheme()`, `resetTheme()` |
| `./check`      | the check library the drift scripts run on (plain-node ESM, no build step)        |
| `./check/*`    | single check files, such as the audit markdown parser                             |
| `./tailwind.css` | for an app with Tailwind v4: the `--ws-*` token contract and the kit's rules, with an `@source` on the kit's built JS, so the app's own build compiles the kit's classes with its theme |
| `./styles.css` | for an app without Tailwind: the same, compiled with Tailwind's theme, preflight and the kit's utilities |
| `./env`        | the declarations of the four `virtual:` modules the plugins serve; an app adds it to its tsconfig `types` |

## Modules

Each module below ships built in `dist/` (its `.js` and `.d.ts`; `dist/settings.d.ts` for `settings.ts`, say) unless
named otherwise; `check/`, `bin/`, `skills/`, `prose/` and `docs/formats.md` ship as they are, beside `dist/`.

| Path                                    | What it holds                                                                                                                                                                     |
| --------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `contract.ts`, `settings.ts`            | the area contract (`AreaDefinition` and the nav, search, title, redirect and link types) and `WorkspaceSettings`, a config's data half                                            |
| `workspace.ts`, `workspace-context.tsx` | `createWorkspace` (load-time checks over the settings and the definitions), `WorkspaceProvider` / `useWorkspace`, `AreaProvider` / `useArea`                                      |
| `redirects.ts`, `links.ts`              | the redirect table built from the config and each area's rows; `resolveLink`, which asks each area's resolver in header order and falls back to the repository's GitHub URL       |
| `router/`                               | `createWorkspaceRoutes` (the root route), `createWorkspaceRouter`, `WsLink` and the location seam                                                                                 |
| `shell/`                                | `WorkspaceShell` and the frame it draws: header, area frame and sidebar, search palette, not-found                                                                                |
| `markdown/`                             | `MarkdownDoc`, `MarkdownBody`, front matter, heading anchors and heading search entries                                                                                           |
| `components/`                           | `GithubLink`, `CopyButton`, `MarkdownDownloadLink`                                                                                                                                |
| `lib/`                                  | search and fuzzy matching, the search shortcut, the hash-arrival and filter-reset hooks, last-viewed memory, storage                                                              |
| `content/`, `vite/`                     | the content API (`readDoc`, `hasDoc`, `listDocs`, `listCollection`, `contentCollections`) over `virtual:workspace-content`, which `wayfinder()` builds from `settings.content`, with the app's `base` and `dev`; `featureSources()`, which serves `virtual:workspace-feature-sources` from the Features area's source roots and its features' `sources` globs; `testInventory()`, which serves `virtual:workspace-test-inventory`, every test file the Features area's `tests.include` globs match, parsed and cached by mtime; `featureCoverage()`, which serves `virtual:workspace-feature-coverage`, the v8 `json-summary` files its `coverage.summaries` globs match |
| `ui/`, `styles.css`                     | the primitives the kit renders with (not exported) and the `--ws-*` token contract                                                                                                |
| `about/`                                | About, the first kit module: `createAboutArea`, its pages, and the kit's own models (`SHELL_MODELS`, `ABOUT_MODELS`)                                                              |
| `readme/`                               | Readme Index: `createReadmeArea`, configured with a content collection and sidebar sections (`settings.areas.readme`); its `kitModels`                                            |
| `platform-docs/`                        | Platform Docs: `createPlatformDocsArea`, configured with a front-matter markdown directory and its reviewed date (`settings.areas['platform-docs']`) and `settings.product`; its `kitModels` |
| `api/`                                  | API: `createApiArea`, configured with an OpenAPI document and an optional JSON consumer registry with its reviewed date (`settings.areas.api`), the running API's URL and legacy redirects; its `kitModels` |
| `features/`                             | Features: `createFeaturesArea`, the feature catalogue from a front-matter markdown directory (`settings.areas.features`: `directory`, `reviewedAt`, `sourceRoots`, `tests`, `coverage`) joined with the route mirror (`settings.productRoutes`), the source scan, the test inventory and the coverage summaries; an index filterable by status and sortable by line coverage, a page per feature (links, prose, its unit and end-to-end tests by description, its coverage and E2E routes visited, the files each glob matches), Tests (every test by file: unassigned, by feature, infrastructure) and Gaps (unowned routes, features with no tests, empty globs, unclaimed source files); the product passes its links for specs and roadmap ids; its `kitModels` |
| `audit/`                                | Audit: `createAuditArea`, the whole area from four internal parts: the implementation pages (Architecture, Roadmap, Todo over three required markdown files, and their phase kinds and TODO areas), the spec ledger (unimplemented and implemented specs, All markdowns, the full-document view), the optional Documentation section and the optional feature audit: the ledger from each spec's and plan's front matter and the review files (`settings.areas.audit`: `reviews`, `specDirs`), the feature audit from JSON (`featureAudit`); the product passes its legacy redirects; its `kitModels` |
| `testing/`                              | `renderAt`, `routerAt`, `renderWorkspace`, `testWorkspace` and `stubSystemScheme`                                                                                                 |
| `theme/`                                | the `./theme` entry: the theme store over the `dark` class on `<html>` (`startTheme`, `setTheme`, `resetTheme`; the reader's choice in `ws:theme`), `useTheme`, and `ThemeToggle`, the header's light and dark button |
| `check/` (beside `dist/`)               | the check library (plain-node ESM): the repository root, the date rule, `finish`, `loadWorkspaceSettings` and `loadWorkspaceHooks` (`index.mjs`); the runner every skill script calls (`run.mjs`); the settings' defaults both sides read (`settings-defaults.mjs`); each area's rules (`about.mjs`, `audit-implementation.mjs`, `audit-ledger.mjs`, `feature-audit.mjs`, `feature-catalogue.mjs`, `api.mjs`, `platform-docs.mjs`) with the readers and builders they share with the modules; the ports and links rules `wayfinder()` and `createWorkspace` share (`ports.mjs`); hosted workspaces, the folder of the kit's checkout that reads as another repository (`hosted.mjs`); the dead-code sweep (`unused-exports.mjs`); the skills installer and linker (`install-skills.mjs`); the document set's check and skill inventory (`documents.mjs`); the first-run runner every `propose.mjs` calls (`propose.mjs`), each area's proposal (`propose-*.mjs`, the About manifest's build and the `content` proposal in `about-manifest.mjs`), the files and test configs they read (`repo-files.mjs`) and the route readers a hooks file may call (`route-readers.mjs`) |
| `bin/` (beside `dist/`)                 | the command line, the package's `bin` `wayfinder` (`bin/wayfinder.mjs`): `wayfinder init`, which starts a repository by installing the onboarding skill |
| `skills/`, `prose/`, `docs/formats.md` (beside `dist/`) | the skills a repository installs (the six `assess-*` skills, `document-repo` and `todo`, and `wayfinder-onboard`, each with its scripts and templates); the default About prose; `formats.md`, the roadmap, TODO, architecture, Milestone-line, ledger and document-set formats |

## Built

The package is built: no consumer aliases, references or scans the kit's source. `dist/` holds the four entries' JS,
one file per module, with their declarations and `env.d.ts`, and the two stylesheets, `styles.css` and `tailwind.css`;
dependencies, peers and the `virtual:` modules stay imports, and so do the `check/` modules, which ship beside
`dist/`. The JS reads nothing from `import.meta.env`: the app's base URL and dev flag come from
`virtual:workspace-content`'s `base` and `dev`, which `wayfinder()` writes in the app's build. `wayfinder()` also keeps
the kit out of Vite's dependency optimiser (its `virtual:` imports must reach the plugins) and pre-bundles the kit's
dependencies through it instead. Under Vitest, a test that imports the kit from `node_modules` needs it inlined
(`test.server.deps.inline: ['@salientform/workspace-wayfinder']`), for the same reason.

## The boundary

The kit is decoupled from any product. Nothing in the kit imports a product package, reads a product CSS variable or
palette class, or names a product or its paths. The consumer passes in its theme provider (or uses the kit's own light and dark theme, the `./theme` entry), and
any component library it wants; the kit renders with its own primitives over the `--ws-*` tokens, which the consumer
maps from its theme.

The kit renders no component library's providers either. `WorkspaceShell` provides only the tooltip provider the
kit's own `Tooltip` needs; a consumer whose own areas need its library's providers (toasts, tooltips)
renders them around the shell. `@radix-ui/react-toast` is not a kit dependency.

## Developing the kit

For the kit's maintainers, in this repository; nothing here is needed to install or use it.

- **Setup:** `pnpm install` (Node 22.18 or later, pnpm as `packageManager` names it). CI (`.github/workflows/ci.yml`)
  runs, on Node 22 and 24: `pnpm install --frozen-lockfile`, `pnpm lint`, `pnpm typecheck`, `pnpm build`, `pnpm test`,
  `pnpm test:check` and `pnpm tarball`.
- **Building:** `pnpm build` (`scripts/build.mjs`) writes `dist/`: the JS in Vite library mode (`vite.config.ts`), the
  declarations (`tsconfig.lib.json`), `env.d.ts` (`src/env.d.ts`) and the stylesheets (`src/build.css`, and
  `tailwind.css`). `pnpm test` reads `dist/`, so build first (the built-package tests are skipped without it).
  `prepack` builds too, so every tarball is packed from a fresh `dist/`. `build:watch` rebuilds on change.
- **Tooling:** `tsconfig.lib.json` (what is built) and `tsconfig.spec.json` (the tests), with `tsconfig.json` for
  editors; `eslint.config.mjs`; `vite.config.ts`, which holds the library build and the Vitest config; the scripts
  `build`, `typecheck`, `lint`, `test`, `test:check` (the `check/` specs, `node --test`) and `tarball` (`pnpm pack` into
  `pack/`). Tests sit beside their file in `src/`; they read only the fixture repository, `src/test-fixtures/`.
- **Against a repository that runs it:** build and pack straight into that repository's `vendor/`, then reinstall
  there:

  ```bash
  pnpm pack --pack-destination <repository>/vendor          # prepack builds first
  cd <repository> && pnpm add -D file:vendor/salientform-workspace-wayfinder-<version>.tgz
  ```

  The version is the one in this `package.json`, so a repack replaces the file in place. `pnpm add` again records the
  new integrity in the lockfile, but pnpm can keep the copy it installed before for an unchanged version, so remove
  that first: `rm -rf node_modules/.pnpm/@salientform+workspace-wayfinder@* node_modules/.pnpm-workspace-state-v1.json`
  in the repository, then `pnpm add`. Run its `skills:install`, its check script and its workspace build. Commit
  nothing there from a local pack; a repository commits only a released tarball.
- **Hosted in this repository:** an instance for another repository, built from the working copy with nothing
  installed there and nothing written to it. `pnpm hosted new <name> <repository>` makes `.workspaces/<name>/` (which
  git ignores), a folder of copies that reads as that repository with the instance installed, and the `wayfinder-onboard`
  skill's "Hosted" section fills it. Then `WAYFINDER_WORKSPACE=<name>` before `pnpm workspace:typecheck`, `:build`,
  `:dev` or `pnpm test:e2e` runs the kit's commands on it, and `pnpm hosted check <name>` runs its own check script:
  that is how a release is tested on each consumer before it is tagged ([SETUP](docs/SETUP.md), "Hosted workspaces").
- **Releasing:** bump `version` in `package.json` and the tag in `KIT_SOURCE` (`src/kit.ts`; a test keeps them equal),
  commit, tag `v<version>` and push the tag. `.github/workflows/release.yml` checks that the tag is the version, builds,
  tests, packs and creates the GitHub Release with the `.tgz` and its `.sha256`, using the workflow's own token. A
  given commit packs to the same bytes anywhere (`pnpm pack` fixes every entry's mtime).
- **The boundary's tests:** the kit names its own files by their source path (`src/settings.ts`), linked through
  `KIT_SOURCE` (`src/kit.ts`), this repository at the installed version's tag; a test fails on a product name in
  anything the kit ships, and `src/package.test.ts` on a package the kit imports that its `package.json` does not
  declare.
- **Documents:** `docs/` holds the kit's own document set, written by its `document-repo` skill: start at
  `docs/ABOUT.md`; the roadmap, the TODO list and the specs are there too. Only `docs/formats.md` is shipped.
- **History:** the kit was developed in the first repository that ran it, at `libs/workspace`, until version 0.1.0;
  its history came with it (`git subtree split`), so earlier commit messages cite that repository's specs and plans by
  milestone.
