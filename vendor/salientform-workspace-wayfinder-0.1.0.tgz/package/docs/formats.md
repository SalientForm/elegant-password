# Wayfinder formats

The formats the Audit area reads and the checks enforce: the roadmap, the TODO list, the architecture document's two
sections, the Milestone line on specs and plans, and the spec ledger and reviews. A repository adopting Wayfinder
adopts these. The paths are settings (`settings.areas.audit`: `roadmap`, `todo`, `architecture`, `reviews`, `specDirs`). The house
vocabularies are settings too: `phaseKinds` for a phase's `Kind`, `todoAreas` for a TODO's `Area`, and `todoSources`
for the `Source` values that are not paths.

The roadmap, the TODO list and the architecture document are each optional: a repository adopts the format of each one
it keeps, and configures only those. `phaseKinds` comes with `roadmap`, and `todoAreas` and `todoSources` with `todo`;
one without its file fails at load. Without a roadmap there is no Milestone line, and a review's `tracked` holds no
roadmap id; without a TODO list, no `#<id>`. The spec ledger and reviews are always there. This file is the normative description. The parser is
`check/audit-markdown.mjs`, and the rules are the headers of `check/audit-implementation.mjs` and
`check/audit-ledger.mjs`.

Every date is `YYYY-MM-DD`. A "Reviewed" or "last modified" date follows one rule: it must be a valid date and not
after today. It records the day the change was made, written by whoever made it, and is never derived from git.

## Ids

| Id | Is | Example |
| --- | --- | --- |
| `M<n>` | a milestone: one outcome | `M4` |
| `M<n>.<k>` | a phase: an independently shippable step towards its milestone | `M4.2` |
| `X<n>` | a spec or plan that aligns with no milestone (Outside the roadmap) | `X7` |
| `#<n>` | a TODO entry | `#12` |

No id is ever reused. A milestone or phase that is merged or dropped is listed on the roadmap's "Retired numbers"
line.

## The roadmap

```markdown
# Roadmap

Reviewed: 2026-01-01

<intro: the order is a forecast, not a commitment; the vocabulary>

Retired numbers (never reused): M7 — merged into M4 on 2026-01-01.

## Sequence

1. M2.4
2. M4.2

## M2. API rebuild

<one outcome paragraph>

### M2.4 Release versioning

- **Status:** not started
- **Kind:** migration
- **Goal:** …
- **Not in scope:** …
- **Depends on:** M2.1
- **Spec:** —
- **Plan:** —

<optional free text>

## Completed

| ID | Title | Shipped | Spec / plan |
| --- | --- | --- | --- |
| M2.1 | Framework swap | 2026-01-01 | docs/specs/2026-01-01-framework-swap-design.md |

## Outside the roadmap

Next X: 3

| ID | Title | Spec | Plan |
| --- | --- | --- | --- |
| X1 | Engineering workspace | docs/specs/… | docs/plans/… |
```

**Header and sections.**
- A `Reviewed:` line comes before the first section.
- The only sections are `Sequence`, the milestones (`## M<n>. Title`), `Completed` and `Outside the roadmap`.

**Milestones.**
- A milestone is followed by its outcome paragraph and its open phases (`### M<n>.<k> Title`).
- A milestone with no open phase is deleted: when its last phase ships or is dropped, its heading and paragraph go.

**Phase fields.** Each phase has these bullets, in this order:

| Field | Value |
| --- | --- |
| `Status` | `not started`, `specified`, `planned` or `in progress` |
| `Kind` | one of `phaseKinds` |
| `Goal` | required |
| `Not in scope` | optional |
| `Depends on` | a comma-separated list of phase ids and free-text conditions, or `—` |
| `Spec` | a repository path, or `—` |
| `Plan` | a repository path; several, comma-separated, in the order they run, the first being the current one; or `—` |

**The status follows the documents:**
- `not started`: no spec, no plan;
- `specified`: a spec and no plan;
- `planned` and `in progress`: both.

A named spec or plan must exist and be an active row of the ledger (`draft`, `under-review` or `blocked`).

**Sequence.** A numbered list of every open phase, exactly once each, in likely order. No completed id appears in it.

**Completed.** A table with four cells per row, and a `Shipped` date. When a phase ships, its section is deleted and
a row is added here.

**Outside the roadmap.**
- A `Next X: <n>` line, greater than every X id below it, then a four-cell table.
- To add a row, allocate `X<Next X>` and bump the counter.
- A row's Spec and Plan are exactly the ledger rows carrying its id.

## The TODO list

```markdown
# TODO

Reviewed: 2026-01-01
Next ID: 13

<intro: what belongs here, how to act on an entry>

## #12 Notification bell never shows a count

- **Area:** app
- **Source:** idea
- **Added:** 2026-01-01

<free markdown, may be empty>
```

**Ids.** Each entry is `## #<id> Title`.
- Ids are positive integers, unique and never reused.
- `Next ID` is greater than every id in the file.
- To add an entry, take `Next ID` and bump it.

**Fields.**
- `Area` is one of `todoAreas`.
- `Source` is a repository path that exists, or one of `todoSources` (an exact value, or a prefix ending in `:` such
  as `feature-audit:`).
- `Added` is a date.

**Lifecycle.**
- An entry lives only while the work is unplanned. Planning or finishing it deletes the entry; the spec, phase or
  commit carries it from there.
- File order is priority, highest first.

## The architecture document

Two sections, among any others the repository keeps.

**`## Stack summary`.** One `### <Area>` heading per area. Under each, a table:

```markdown
| Item | Status | Note | Ref |
| --- | --- | --- | --- |
| Vite 7 | current | | §8 |
| Kysely | planned | | M2.5 |
```

- `Status` is `current` or `planned`.
- `Ref` is one of:
  - a section of the same file (`§<n>`);
  - a roadmap phase or milestone id;
  - a repository path that exists;
  - empty.
- A `planned` row's phase must be open.

**`## Planned migrations`.** One bullet per open phase that changes the architecture:
`- **M2.4 Release versioning** — [ROADMAP.md](ROADMAP.md#m24-release-versioning)`. Its id must be on the roadmap.

The document also has a `Reviewed:` line under its title.

## The Milestone line

With a roadmap configured, every document directly in one of `specDirs` (default `docs/specs` and `docs/plans`; an `archive/` below them is
exempt) has exactly one `**Milestone:** <id>` line before its first `## ` heading.

**What the id can be:**
- an open or completed phase;
- an `X` id from Outside the roadmap;
- for a row already closed (`implemented` or `superseded`), a milestone.

**How the document and the ledger agree:**
- An active row's phase names the document as its Spec or one of its Plans. Every plan a phase names is active: a
  finished plan leaves the list.
- A plan carries its spec's id. When its spec spans several phases of one milestone, it may carry the phase it
  implements instead (`M4.2` under an `M4.1` spec).

## The spec ledger and reviews

The ledger is markdown: no JSON registry, no generated index. Each spec's and plan's state is its own front matter;
every other document has a review file under `reviews`; `reviews/index.md` holds the rest. They read and diff like the
documents they describe. CommonMark with YAML front matter and nothing else: no tool-specific syntax, no reader beyond
the kit is required; GitHub, an editor or Obsidian show them correctly.

**A spec or plan.** Every document in `specDirs` (the first holds specs, the others plans; read recursively, and a
document in a subdirectory, an `archive/` for instance, is a row only if it has front matter) opens with front matter
before its `# ` heading:

```markdown
---
state: draft
summary: >
  One paragraph: what the document decides or delivers.
followUps:
  - A later idea it names
evidence: Branch feat/… (2026-11-03), what proves it.
spec: docs/specs/2026-10-21-example-design.md   # plans only
blockedOn: What must land first   # when state is blocked
---

# Title

**Milestone:** M12.11
```

`state` and `summary` are required; `followUps`, `evidence`, `spec`, `blockedOn` are as the state calls for. A
document's title is its first `# ` heading, its kind its directory, its milestone its `**Milestone:**` line
(`milestone` is never front matter). `spec` is its spec's path, equal to the path on any body `**Spec:**` line.
`state` is one of `draft`, `under-review` or `blocked` (active); `implemented` or `superseded` (closed); `conflicting`.
A plan's `spec` is what links its card to the spec's card.

A value with `: `, `#`, a brace or a bracket is quoted (`'…'`), as YAML requires: a `{a,b}` glob, `#3`, a sentence with
a colon. Inside a one-line flow collection (`{ id: x, title: y }`, `[a, b]`) a comma ends the value too, so a value
there with a comma is quoted; block style, one key per line, avoids that, and is what the kit's templates use. A front
matter block that does not parse, or a flow entry split by a comma into an unknown key, stops the workspace from
loading, naming the file and the line or the key.

**A review**, one per reviewed markdown file, at `<reviews>/<path without .md>.review.md`, or per directory
`<dir>/`, at `<reviews>/<dir>/_directory.review.md` (a file name holds no `/`, so the path is the directories):

```markdown
---
path: docs/ARCHITECTURE.md
kind: documentation
lastModified: 2026-11-02
verdict: current
tracked: [M2.4, M3.3]
ref: docs/ROADMAP.md §M12
---

## Stale content

What is out of date and how that was verified.

## Future content

Future work, TODOs, roadmap items or open follow-ups the document carries.

## Recommendation

One imperative sentence.
```

A directory review's `path` is the directory with a trailing `/`, and its `lastModified` is the newest of its files':
`<reviews>/.agents/skills/_directory.review.md` holds

```markdown
---
path: .agents/skills/
kind: config
lastModified: 2026-11-02
verdict: current
---

## Recommendation

Change the skills only through the kit's installer.
```

A section's text is markdown, read as one paragraph (its line breaks fold to spaces) and rendered inline on the All
markdowns page: code spans, emphasis and links show as such, and raw HTML stays text.

`path`, `kind`, `lastModified`, `verdict` and `## Recommendation` are required; the others appear only when they have
text. `path` must equal the file's own name under the rule above; `kind` is an `id` from the index's `kinds`, the All
markdowns section the review sits in. With the onboarding template's kinds: `spec` and `plan` for the documents in
`specDirs` (the first directory specs, the others plans), `config` for agent and tooling configuration (a skills
directory, `CLAUDE.md` or `AGENTS.md`, a tool's settings), and `documentation` for every other markdown file. A
repository adds a kind to the index deliberately. A
`## Future content` needs `tracked` and the other way round: `#<id>` (the TODO list, when configured), a phase,
milestone or X id (the roadmap, when configured), or a spec or plan path. Every token must resolve. A review's `lastModified` follows the date rule; its
`verdict` is one of `current`, `partially-stale`, `stale`, `superseded`, `done`, `conflicting` or `wrong`.

Every markdown file `git ls-files` lists has a review, except paths under `ignore`, the review files and `index.md`.

**The index**, `<reviews>/index.md`:

```markdown
---
reviewedAt: 2026-11-03
kinds:
  - id: documentation
    label: Documentation
  - id: spec
    label: Specs
documents:
  - id: architecture
    title: Architecture (full document)
    path: docs/ARCHITECTURE.md
    description: Layering, boundaries, build and deploy.
---

# Reviews

What this folder is, for a reader who opens it.
```

`reviewedAt` is the date of the last review of anything in the folder. `kinds` are the All markdowns page's sections,
in page order. `documents` is the Documentation section, in nav order (`id` lowercase kebab, `anchor` optional); omit
it and the area has no Documentation section. A content collection must cover the folder.

The types are in `check/audit-registries.d.mts`.

**Links.** Every relative link in tracked markdown resolves, except under `linkExempt` and in the reviews folder, whose
files are not read as pages.
