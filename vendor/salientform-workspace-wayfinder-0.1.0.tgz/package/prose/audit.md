---
title: Audit
summary: Where the repository stands, from the roadmap and open specs to every markdown file and the key documents.
---

# Audit

## What Audit answers

Audit answers "where does the repository stand?" Which specs and plans are still open and which markdown files are
current or stale; and, where the repository keeps the files for them, what is planned and in what order, what the
architecture is, and which code is dead or unreachable.
Which features the product has is the Features area's question. It reads the repository's own planning files and
registries, so it is as current as the last time their skills were run. Each sidebar section shows its own reviewed
date.

## How to read Audit

The sidebar has up to three sections.

**Implementation Status** is the forward view, with a page for each planning file the repository keeps. Architecture
summarises the stack, Roadmap shows the milestones and their phases in sequence, Todo lists the numbered small items
that are not yet planned, and Features, where the repository keeps a feature audit, lists dead code, unreachable
features, stale TODOs and recommendations. A repository that keeps none of them has no such section.

**Spec ledger** tracks every spec and plan. Unimplemented specs is where to look for work that is designed but not
built, with the plan shown first where there is one. Implemented specs lists those marked implemented or superseded,
where the repository keeps its specs once they are built. All markdowns gives a verdict on every markdown file in the
repository: current, stale, partly stale, done or superseded, with what to do about it.

**Documentation**, where the repository lists documents, renders the key documents in full, such as the
architecture, roadmap and setup guide. Spec and
plan cards elsewhere link to a full-page view of their document, and offer it as a download.

Architecture, Roadmap and Todo are read from three markdown files in the formats the kit defines (its
`docs/formats.md`), each optional. The spec ledger and the Documentation list are markdown: each spec's and plan's state is its own
front matter, every other reviewed document has one review file in the reviews folder (`areas.audit.reviews`, by
default `docs/reviews`), and that folder's `index.md` holds the date, the All markdowns sections and the Documentation
list. The feature audit stays JSON with its own reviewed date. Which files, which phase kinds and which TODO areas the repository uses are set in the workspace config
(`areas.audit`). A file that does not follow its format, a registry row with a missing or unknown value, or a kind or
area the config does not list, stops the workspace from loading until it is fixed.
