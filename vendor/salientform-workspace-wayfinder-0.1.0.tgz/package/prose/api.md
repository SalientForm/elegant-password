---
title: API
summary: Every operation the API's OpenAPI document declares, whether the product calls it, and its request and response shapes.
---

# API

## What API answers

API answers "what routes does the API have, who calls them and what do they take and return?" It lists every
operation in the API's OpenAPI document and, with a consumer registry, marks whether the product actually calls it
and from which pages. It shows the request and response shapes from the document. It is the place to check before
adding a route, or before changing or removing one that something might depend on.

## How to read API

With a registry, routes are grouped as the registry says, and the sidebar jumps to each group; without one, by the
document's tags. Each row shows the method and path, a status and the pages that call it. The status is used when the
product calls the route, unused when nothing does, and stub when the route exists but returns placeholder data.
Expand a row to see its request and response fields. The reviewed date is the last time the registry was checked
against the API and against the product's calls. Which document the area reads, the registry that says who calls each
route, and that date are set in the workspace config (`areas.api`); a route the registry does not list yet appears in
a last group, "Not in the registry", until it is added.
