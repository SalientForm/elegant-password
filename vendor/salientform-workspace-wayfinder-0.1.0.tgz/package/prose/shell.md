---
title: Shell
summary: The frame every area plugs into, and what an area must declare to appear in it.
---

# Shell

## The workspace kit

The shell, the area contract and everything on this page come from Workspace Wayfinder, a library that knows nothing
about the product it documents. A repository configures it in two files: a settings file of plain data, which the
check scripts read as well, and a definitions file that hands the kit each area. A third, optional file holds the
repository's own rules for the checks. The kit draws with its own small set of components over colour tokens the
repository may map from its product's theme.

## The area contract

An area is one definition: a slug that becomes its URL, a title and an icon for the header, a one-line description,
its sidebar navigation and its routes. It may also contribute search entries, a landing page for when nothing is
remembered, a custom sidebar and its own page-title resolver.

## Header

The logo sits centred over the sidebar column, followed by the areas in header order, then any links to the
repository's other apps (marked with an arrow: they leave the workspace), then search and any actions the repository
adds, such as a theme toggle. In a narrow window each area shows its icon instead of its title; hovering it shows the title and the
description. When the window is wider than the workspace, lines mark the workspace's left edge and the header's right.

## Routes, navigation and titles

The shell mounts each area's routes under its slug and draws the sidebar from its navigation. The title above each
page, and the browser tab title, come from the sidebar item the reader is on, with the sidebar section shown as a
small eyebrow above it. Areas with a custom sidebar resolve their own titles. Old addresses that moved keep working
through redirects, which each area declares for its own pages.

## Search

Press `⌘K` (or `Ctrl K`) anywhere to search every area. Each area contributes entries from its own registries and
markdown headings; the shell adds one entry per sidebar item. Results are grouped by area, the current area first,
and can be filtered by kind. Choosing a result opens its page at the matching row or heading.

## Memory and arrival

Each area remembers the last page you viewed, so its header link and its root address take you back there. A
remembered page that no longer exists falls back to the area's landing page. When an address carries a `#` anchor,
the page scrolls to that row or heading and highlights it briefly.

## Markdown

Every repository file the workspace reads, markdown included, is listed in the content manifest: named collections in
the settings, bundled at build time, so a missing file fails loudly rather than rendering empty. Links between
documents become in-app routes where an area renders the target, and links to the repository host otherwise.

## Adding an area

1. Write the area definition in its own directory.
2. Add its slug to the settings in header order, and its definition to the workspace.
3. Write its prose file for this About area, with a title and summary, unless the kit ships one.
4. Add its registries and models to the About manifest.
5. Run the `assess-workspace` skill and the check script.
