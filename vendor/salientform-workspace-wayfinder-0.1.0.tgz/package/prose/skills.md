---
title: Skills
summary: How the workspace skills keep the registries true to the code, and when to run each one.
---

# Skills

## What a workspace skill is

A workspace skill is a repeatable procedure, written down in the repository, that keeps one or more registries true
to the code. It says what to read, what to compare and what to change, and it ends by running its check. An engineer
can follow it by hand; an agent follows the same text. Each skill owns its registries and the reviewed date beside
them, and no other skill or person bumps that date. The skills come with the kit and are installed into the
repository's skills directory, which any agent that reads the shared skill format can load; an agent that looks
elsewhere finds each skill through a link in its own directory. What one repository needs beyond them sits beside
each skill in its `REPOSITORY.md`.

## When to run one

Run a skill after the kind of change its description names: a new API route, a page added to the product, a spec
that shipped, a feature that gained a test. The description on each card below is that trigger, read straight
from the skill. When one change touches several areas, run each skill whose trigger it matches. A skill can also be
run on its own to refresh an area that has drifted.

## Checks

Most skills come with a check script that verifies their registries against the code: that every file a registry
names exists, that every route or feature it lists is real, that every date follows the date rule. The scripts are
fast and print one line per problem. The check script runs all of them in order: run it before a change is merged.
Where the repository runs it in CI on every pull request, a registry that has fallen behind blocks the merge until its
skill is run. A few scripts are helpers that
a skill runs by hand during its sweep, and they are marked as such below.
