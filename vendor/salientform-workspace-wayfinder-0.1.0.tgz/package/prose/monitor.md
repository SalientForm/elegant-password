---
title: Monitor
summary: The environment you are looking at, and what build is running there.
---

# Monitor

## What Monitor answers

Monitor answers "which environment am I looking at, and what is running there?" It lists the product's environments
and shows what the selected one reports about its running build, from a build-info endpoint every environment's API
is expected to serve. Until that endpoint exists the config marks it mocked, and every environment shows the same
sample: treat the Build section then as a preview of the layout, not as a fact about any deployment.

## How to read Monitor

The Environments section lists the environments as chips; choose one to make it the subject of the page. You can
add, edit and remove environments, and the list is kept in your browser, so your changes are yours alone and survive
a reload. Reset to defaults restores the built-in list. The Build section shows what the selected environment
reports about its running build. No skill owns this area, and nothing checks it, because the list is yours to edit.
The built-in list and the build-info endpoint it calls, with whether that endpoint is still mocked, are set in the
workspace config (`areas.monitor`); a malformed environment or endpoint there stops the workspace from loading until
it is fixed.
