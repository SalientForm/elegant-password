---
title: Readme Index
summary: The repository README, and any library or package READMEs, rendered from source.
---

# Readme Index

## What Readme Index answers

Readme Index answers "what is in this repository, and what does each part do?" It renders the root README, which
covers setup and the overall layout, and, where the repository has them, the READMEs of its libraries or packages,
each saying what it is for, what it exports and how to use it. They are the same files you would open on the repository host, rendered here so they sit
beside the rest of the workspace and can be searched together.

## How to read Readme Index

Start with the repository README at the top of the sidebar. Any sections below it list the other READMEs by their
path, so the sidebar doubles as a map of the repository. Which READMEs appear, and the sections they sit in, come from the
workspace config: a content collection and `areas.readme`. A README the collection picks up outside every section
stops the workspace from loading until it is given one. Links inside a README open the matching page in the workspace
where there is one, and the repository host otherwise. No skill owns this area: a README is kept current by whoever
changes its code, so check the source when a README looks out of date.
