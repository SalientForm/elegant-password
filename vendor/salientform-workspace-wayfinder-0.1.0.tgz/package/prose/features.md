---
title: Features
summary: Every feature of the product, with the routes it owns, its tests and coverage, the code it is built from and what the catalogue misses.
---

# Features

## What Features answers

Features answers "what does the product do, where is each part of it built, and how do we know it works?" Every
feature has a page: what it does and where its edges are, the routes it owns, its Platform section, the specs and
roadmap phases behind it, its unit and end-to-end tests listed by their descriptions, how much of its code those
tests reach, and the source files it is built from. The catalogue is one markdown file per feature, so the prose sits
next to the facts and changes in the same commit as the code.

## How to read Features

The sidebar's first section holds **All features**, a table of every feature with its status, routes, unit and
end-to-end test counts, the routes its end-to-end tests visit, its line coverage and its number of source files,
filterable by status and sortable by coverage (click the Lines header), then **Tests** and **Gaps**. Below it, one
section per status lists the features by name: Live features have a route and a way in, Partial ones are missing one
of the two, Parked ones are libraries nothing uses, and Planned ones are roadmap work with no screen yet.

A feature page's **Unit tests** and **End-to-end tests** list its tests as written in their source: the file, then
each describe, then the test titles, which are meant to read as a description of the feature's behaviour. Skipped and
to-do tests are counted apart, and a test written once per row of a table is marked `each`. A unit test belongs to a
feature when it sits beside a file the feature is built from; an end-to-end test when it is tagged `@feature:<id>`.
**Coverage** shows how many of the feature's routes its end-to-end tests open, and the share of its code's lines the
unit tests run, with statements, branches and functions beside it and a table per file. The line figures come from
the coverage summaries the test runs write: run the tests with coverage, then reload the workspace. Until they have
run, coverage reads "Not measured", never 0%. The numbers are shown, never enforced. The **Sources** section lists
each glob from the front matter with the files it matches when the workspace was built.

**Tests** lists every test the workspace found, by file: first the unassigned ones (a test no feature owns fails the
check), then those features own, with their features, then the infrastructure tests of tooling, the platform and
shared code. Searching for a test's title lands on its row there. **Gaps** shows what the catalogue leaves out:
product routes no feature owns, features with no tests, globs that match nothing, and source files under the source
roots that no feature claims. Unowned routes and empty globs fail the check; the rest are lists to work through, not
errors.

The reviewed date in the sidebar is the last time the catalogue was checked against the product. The directory, the
date, the source roots, the test globs and the coverage summaries are set in the workspace config (`areas.features`),
and the route mirror every feature's routes are checked against is `productRoutes`. A feature file with a missing
field or an unknown route stops the workspace from loading until it is fixed. The `assess-features` skill maintains
the catalogue and the mirror.
