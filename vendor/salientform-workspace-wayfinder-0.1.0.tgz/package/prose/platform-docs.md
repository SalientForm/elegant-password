---
title: Platform
summary: The plain-language guide to the product for readers who are not engineers.
---

# Platform

## What Platform answers

Platform answers "what does the product do, and how do I use it?" for readers who are not engineers: product, sales,
customers and anyone new to the team. It describes the product as it exists today, screen by screen, in plain
language, and says clearly where a feature is a placeholder or still to come. It does not describe code, data
models or how anything is built; the other areas cover that.

## How to read Platform

The sidebar lists the pages in reading order. Each page is a short guide with a summary at the top. Read them in
order the first time; after that, use `⌘K` to jump to a heading. The reviewed date in the header is the last time the
pages were checked against the product, page by page, so a recent date means the screens described here match what
you will see. Which directory the pages come from, and that date, are set in the workspace config
(`areas['platform-docs']`); a page missing its title, order or summary stops the workspace from loading until it is
fixed.
