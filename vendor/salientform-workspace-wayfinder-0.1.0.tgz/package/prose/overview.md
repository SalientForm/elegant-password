---
title: Overview
summary: What the Engineering Workspace is, who it is for and how its pieces fit together.
---

# Overview

## What the workspace is

The Engineering Workspace is this repository's internal engineering app. It puts the repository's state, its plans and
its documentation in one place, each in its own area along the header. Every area is built from files in this
repository, so what you read here is what the code says today, not a copy that someone keeps by hand.

## Who it is for

Engineers working on the product: to see which specs are still open, find where a document lives and whether it is
current, and, where the repository has those areas, read the roadmap, check an API route or see which feature owns a
page. Platform, where the repository has it, is the exception: it is written for readers who are not engineers and
explains what the product does in plain language.

## How the pieces fit

Most areas show a registry: a typed list, a JSON file or a markdown file that records something about the repository,
such as the state of every spec, the API routes and who calls them, or the features and their tests. The rest of the
workspace is four kinds of thing working together:

- **Registries** feed the pages. A page reads its registry when the workspace is built and renders it.
- **Skills** edit the registries. Each skill is a written procedure an engineer or an agent follows after a change.
- **Check scripts** verify the registries against the code, so a registry that no longer matches fails.
- **The check script** in the root package.json (`workspace:check` unless the config names another) runs every check
  together: before a change is merged, and in CI where the repository runs it there.

The tables below list every area, and each area's About page names its registries, the types behind them and the
skills that keep them current. The Shell page explains how an area plugs into the frame, and the Skills page how the
skills and checks are used.
