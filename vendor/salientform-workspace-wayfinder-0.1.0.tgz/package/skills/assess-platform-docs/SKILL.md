---
name: assess-platform-docs
description: Use when asked to review or refresh the non-technical Platform Docs (the markdown pages under the configured Platform Docs directory) shown in the workspace — after a page, feature, or navigation item is added, removed, or renamed in the product, or when the Platform Docs area needs its date refreshed.
---

# Assess Platform Docs

Read `REPOSITORY.md` beside this file first, if it exists: it holds this repository's own rules for this skill, and they take precedence over the examples here.

## Overview
The Platform Docs pages describe the product for non-engineers: what it is, how to use it, what exists today. The area is a Wayfinder module (`createPlatformDocsArea`, `src/platform-docs/` in the kit); everything this skill needs to know about the repository comes from the workspace config (the file the root `package.json` `wayfinder.config` names); `REPOSITORY.md` gives this repository's values:

| Setting | Means |
| --- | --- |
| `product` | the product the pages describe (Acme) |
| `areas['platform-docs'].directory` | one markdown file per page, `<order>-<slug>.md`, rendered at `/platform-docs/<slug>`; the menu comes from front-matter (`title`, `order`, `summary`) |
| `areas['platform-docs'].reviewedAt` | the area's reviewed date, an ISO date shown in its header; set only by this skill |

The rules file (the root `package.json` `wayfinder.rules`) may export `navLabels(ctx)`, returning the product's navigation labels; the check reports the ones no page mentions. Without it nothing is reported.

## Workflow
1. `node .agents/skills/assess-platform-docs/scripts/check-platform-docs.mjs` (`runCheck('platform-docs')` over the kit's `check/run.mjs`; the rules are the kit's `check/platform-docs.mjs`, which shares its page builder with the workspace) — fix every fatal line. An `unmentioned:` line names a navigation label no page mentions; cover it or say why not.
2. Read the product surface: its routes, its navigation (sidebar, top bar), its entry and selection pages, and the public entry of each feature library: the router and navigation files the rules file's `productRoutes` and `navLabels` hooks read, where it has them (`REPOSITORY.md` may name more).
3. For each page, check every claim against the surface: page names, sidebar labels, what opens automatically, which tabs have content, what is demonstration data. Fix wording; add a page when a new feature area appears; remove a page only when its feature is gone.
4. Update the what's-available page first, if there is one — it is the summary readers trust.
5. Voice: plain language, no code, no file paths, no component names. Write for the product's users (`REPOSITORY.md` may name who they are).
6. Bump `areas['platform-docs'].reviewedAt` in the workspace config; re-run the script; run the check script (`areas.about.checkScript`, default `workspace:check`) and whichever of lint, typecheck and tests the repository has (its root `package.json` scripts; a `REPOSITORY.md` beside this skill may add others) (the workspace loads every page at start-up and fails on a front-matter problem); then open the area on the workspace dev server (`/platform-docs`) and click every menu item.

**Date rule:** The owning `reviewedAt` is the date the registry was actually last updated: a valid ISO date, not after today. It is not tied to git: set it on the day you make the change, and leave it alone when the change is committed, rebased or merged on a later day. Only the owning skill writes it.

## Common Mistakes
| Mistake | Fix |
|---|---|
| Describing planned features as available | Say "planned" and point at the spec on the what's-available page |
| Technical vocabulary | Rewrite for the reader |
| Forgetting front-matter | `title`, numeric `order`, `summary` are required; the workspace will not load without them |
| Editing dates by hand elsewhere | Only `areas['platform-docs'].reviewedAt` moves, only from this skill |
| Putting a page in a subdirectory | Pages are the directory's direct `*.md` files; a file below it is not rendered |
| Adding, renaming or removing a registry export or model without telling About | Update the About manifest (`areas.about.manifest`) and run `assess-workspace` |
