/**
 * The spec ledger and documents drift check (spec M12.9 §5.8, spec M12.11 §6.15): the reviews folder
 * (settings.areas[slug].reviews) and each spec's and plan's front matter, read by the reader the Audit module shares
 * (audit-registries.mjs), against the repository and the roadmap and TODO list the implementation check parsed
 * (audit-implementation.mjs). Plain node; the product's wrapper loads the settings, runs the implementation check, then
 * this, and prints one line from the two summaries.
 *
 * Fails when:
 *  - the reviews index is missing, a review, spec or plan front matter or the index does not parse, or has a problem the
 *    reader reports (an unknown key or section, a review whose `path` differs from its file name, a missing required field)
 *  - a file in the reviews folder is neither the index nor a `.review.md`, or no content collection covers one (a glob
 *    enters a dot-directory only where its pattern names one, so a review under `.agents/` needs a pattern naming it)
 *  - a tracked markdown file (`git ls-files`, minus node_modules/, the area's `ignore` and the reviews folder) has no
 *    review (the exact path or a covering directory review ending in '/')
 *  - a reviewed, spec or documents path does not exist
 *  - a review's lastModified fails the date rule
 *  - a roadmap phase's Spec or Plan that exists is not an active (draft, under-review, blocked) row of that kind
 *  - a review has futureContent without `tracked`, or `tracked` without futureContent, or a tracked token ('#<id>',
 *    a roadmap id, an X id or a spec path) does not resolve: a '#<id>' needs a TODO list, a roadmap or X id a roadmap
 *  - a document directly in one of the area's `specDirs` (default docs/specs, docs/plans; a subdirectory apart) lacks
 *    front matter with a `state`
 *  - with a roadmap (the Milestone-line rule, skipped without one, as the summary says): such a document lacks exactly
 *    one "**Milestone:** <id>" line, or the id does not resolve (an open or completed phase, a milestone with a closed
 *    row, or an Outside the roadmap X row); a plan's id differs from its spec's; an active row's phase names it as
 *    neither Spec nor Plan; an X row's Spec / Plan and the rows carrying its id differ
 *  - a plan's `spec` differs from the path on its body's `**Spec:**` line
 *  - a relative link in tracked markdown (outside the area's `linkExempt`) points at nothing
 *  - the index's reviewedAt fails the date rule
 */
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { exists, modifiedDateRule, readRepo, repoRoot } from './index.mjs';
import { checkAuditImplementation } from './audit-implementation.mjs';
import { MILESTONE_ID, PHASE_ID, X_ID } from './audit-markdown.mjs';
import {
  ACTIVE_SPEC_STATES,
  CLOSED_SPEC_STATES,
  REVIEWS_INDEX,
  milestoneIds as documentMilestones,
  reviewFilePath,
  readAuditMarkdown,
} from './audit-registries.mjs';
import { globMatcher } from './features.mjs';
import { parseFrontMatter } from './front-matter.mjs';
import { brokenLinks } from './links.mjs';
import { auditSettings } from './settings-defaults.mjs';

const ID = /^(M\d+\.\d+|M\d+|X\d+)$/;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
/** The first path ending in `.md` on a plan's `**Spec:**` line; a line with none (no separate spec) names nothing. */
const SPEC_LINE = /^\*\*Spec:\*\*\s.*?((?:[\w@.-]+\/)*[\w@.-]+\.md)/m;

const dotSegment = (s) => s.startsWith('.') && s !== '.' && s !== '..';

/**
 * Whether a collection of `content` covers `file`, as the workspace's build does: a positive pattern matches, no
 * negative does, and a path through a dot-directory is matched only by a pattern that names a dot-directory. The kit's
 * `wayfinder()` globs such patterns exhaustively (every dot name then matches), and the others with dot-directories
 * skipped (`src/vite`'s `contentModule`).
 */
function contentCovers(content, file) {
  const throughDot = file.split('/').some(dotSegment);
  return Object.values(content ?? {}).some((patterns) => {
    const positive = patterns.filter((p) => !p.startsWith('!'));
    const negative = patterns.filter((p) => p.startsWith('!')).map((p) => p.slice(1));
    const hit = (p) => globMatcher(p)(file) && (!throughDot || p.split('/').some(dotSegment));
    return positive.some(hit) && !negative.some((p) => globMatcher(p)(file));
  });
}

/** A repository JSON registry through its reader, or a problem naming it and null. */
export function readRegistry(file, setting, reader, problems) {
  if (!exists(file)) {
    problems.push(`missing: ${file} (${setting}) does not exist`);
    return null;
  }
  let json;
  try {
    json = JSON.parse(readRepo(file));
  } catch (error) {
    problems.push(`malformed: ${file} (${setting}) is not JSON: ${error.message}`);
    return null;
  }
  const { value, problems: found } = reader(json, file);
  for (const problem of found) problems.push(`malformed: ${problem}`);
  return value;
}

/** The date rule on a registry's reviewedAt; a value that is not an ISO date is already its reader's problem. */
export function reviewedAtRule(problems, file, value) {
  if (ISO_DATE.test(value ?? '')) modifiedDateRule(problems, `${file}: reviewedAt`, value);
}

const gitFiles = (...patterns) =>
  execFileSync('git', ['ls-files', ...patterns], { cwd: repoRoot, encoding: 'utf8' }).split('\n').filter(Boolean);

/**
 * Runs the ledger and documents rules over `settings` (the workspace config's data half); `slug` is the area's key in
 * `settings.areas`. `implementation` is what `checkAuditImplementation` returned (run here, its problems dropped, when
 * omitted). The area's `ignore` drops tracked paths under a prefix from the markdown set (agent worktrees, say);
 * `linkExempt` skips the broken-link rule under a prefix (a fixture that links to a missing page on purpose); `specDirs`
 * are the directories whose documents carry a Milestone line. Returns { problems, ledger, documents, tracked, summary }; a registry that cannot be read
 * is null, and the rules that need it are skipped.
 */
export function checkAuditLedger(settings, { slug = 'audit', implementation } = {}) {
  const raw = settings.areas[slug];
  if (!raw) throw new Error(`wayfinder: settings.areas.${slug} is not configured`);
  const area = auditSettings(raw);
  const { ignore, linkExempt, specDirs, reviews: REVIEWS } = area;
  const at = `settings.areas.${slug}`;
  const problems = [];
  const { roadmap, todos, paths } = implementation ?? checkAuditImplementation(settings, { slug });
  // `undefined` when the area has no roadmap or TODO list (plan C); `roadmap` / `todos` null then, or when one did not parse.
  const ROADMAP = paths.roadmap;
  const TODO = paths.todo;

  const INDEX = `${REVIEWS}/${REVIEWS_INDEX}`;
  let ledger = null;
  let documents = null;
  if (!exists(INDEX)) {
    problems.push(`missing: ${INDEX} (${at}.reviews) does not exist`);
  } else {
    const files = (dir) => gitFiles('--cached', '--others', '--exclude-standard', '--', dir).filter((p) => p.endsWith('.md') && exists(p));
    const toDoc = (p) => ({ path: p, markdown: readRepo(p) });
    const specDocs = specDirs.flatMap(files).map(toDoc);
    const reviewFiles = files(REVIEWS);
    for (const file of reviewFiles)
      if (file !== INDEX && !file.endsWith('.review.md')) problems.push(`malformed: ${file} is neither ${REVIEWS_INDEX} nor a .review.md (${at}.reviews)`);
    const reviewDocs = reviewFiles.filter((p) => p.endsWith('.review.md')).map(toDoc);
    const built = readAuditMarkdown({ specDirs, reviews: REVIEWS, specDocs, reviewDocs, indexMarkdown: readRepo(INDEX) });
    for (const problem of built.problems) problems.push(`malformed: ${problem}`);
    ({ ledger, documents } = built);
    const uncovered = (file) => !contentCovers(settings.content, file);
    for (const file of [INDEX, ...reviewFiles.filter((p) => p.endsWith('.review.md'))])
      if (uncovered(file)) problems.push(`uncovered: ${file} is in no content collection (settings.content): a dot-directory needs a pattern naming it`);
    for (const { path: file } of ledger.specStatus)
      if (uncovered(file)) problems.push(`uncovered: ${file} is a spec or plan in no content collection (settings.content)`);
  }
  const reviews = ledger?.docReviews ?? [];
  const specRows = ledger?.specStatus ?? [];

  // 1. Every tracked markdown file has a review.
  const tracked = gitFiles('*.md', '**/*.md').filter(
    (p) => !p.includes('node_modules/') && !ignore.some((prefix) => p.startsWith(prefix)) && !p.startsWith(`${REVIEWS}/`)
  );
  if (ledger) {
    const reviewPaths = new Set(reviews.map((r) => r.path));
    const dirEntries = reviews.map((r) => r.path).filter((p) => p.endsWith('/'));
    for (const file of tracked)
      if (!reviewPaths.has(file) && !dirEntries.some((d) => file.startsWith(d)))
        problems.push(`unreviewed: ${file} has no review file (${reviewFilePath(REVIEWS, file)}, or a directory review covering it)`);
  }

  // 2. Every registry path exists.
  for (const { path } of reviews)
    if (!exists(path)) problems.push(`missing: ${reviewFilePath(REVIEWS, path)} reviews ${path}, which does not exist`);
  for (const { path } of documents?.documents ?? [])
    if (!exists(path)) problems.push(`missing: ${INDEX} documents entry ${path} does not exist`);

  // 3. lastModified follows the date rule for every file review (a missing path is reported in 2).
  for (const { path, lastModified } of reviews) {
    if (path.endsWith('/') || !exists(path)) continue;
    modifiedDateRule(problems, `${reviewFilePath(REVIEWS, path)}: lastModified`, lastModified);
  }

  // 4. A phase's Spec and every Plan it names are active ledger rows.
  const openPhases = roadmap ? roadmap.milestones.flatMap((m) => m.phases) : [];
  if (ledger)
    for (const p of openPhases)
      for (const [label, kind, file] of [['Spec', 'spec', p.spec], ...(p.plans ?? []).map((f) => ['Plan', 'plan', f])]) {
        if (!file || !exists(file)) continue; // a missing file is the implementation check's problem
        const row = specRows.find((s) => s.path === file && s.kind === kind);
        if (!row) problems.push(`stale: ${ROADMAP} ${p.id} ${label} ${file} has no front matter with a state as a ${kind} (in ${specDirs.join(' or ')})`);
        else if (!ACTIVE_SPEC_STATES.includes(row.state))
          problems.push(`stale: ${ROADMAP} ${p.id} is ${p.status} but ${file} has state ${row.state} — move the phase to Completed or fix the document's front matter`);
      }

  // 4b. Every review with futureContent says where that work is tracked, and every token resolves. A file that failed
  // to parse was already reported, so its tokens are not checked.
  const roadmapIds = new Set(
    roadmap ? [...roadmap.milestones.map((m) => m.id), ...openPhases.map((p) => p.id), ...roadmap.completed.map((c) => c.id)] : []
  );
  const todoIds = new Set(todos ? todos.todos.map((t) => `#${t.id}`) : []);
  const xIds = new Set(roadmap ? roadmap.outside.map((o) => o.id) : []);
  for (const r of reviews) {
    const tokens = r.tracked ?? [];
    if (r.futureContent !== undefined && tokens.length === 0)
      problems.push(`missing: ${reviewFilePath(REVIEWS, r.path)} has a ## Future content section but no tracked`);
    if (r.futureContent === undefined && tokens.length > 0)
      problems.push(`stale: ${reviewFilePath(REVIEWS, r.path)} has tracked but no ## Future content section`);
    for (const token of tokens) {
      const roadmapToken = PHASE_ID.test(token) || MILESTONE_ID.test(token) || X_ID.test(token);
      if (token.startsWith('#') && TODO === undefined) {
        problems.push(`stale: ${reviewFilePath(REVIEWS, r.path)} tracked "${token}" is a TODO id, but ${at} has no TODO list (todo)`);
        continue;
      }
      if (roadmapToken && ROADMAP === undefined) {
        problems.push(`stale: ${reviewFilePath(REVIEWS, r.path)} tracked "${token}" is a roadmap id, but ${at} has no roadmap`);
        continue;
      }
      const ok = token.startsWith('#')
        ? !todos || todoIds.has(token)
        : PHASE_ID.test(token) || MILESTONE_ID.test(token)
          ? !roadmap || roadmapIds.has(token)
          : X_ID.test(token)
            ? !roadmap || xIds.has(token)
            : specRows.some((s) => s.path === token);
      if (!ok)
        problems.push(`stale: ${reviewFilePath(REVIEWS, r.path)} tracked "${token}" does not resolve (TODO id, roadmap id, X id, or a spec or plan path)`);
    }
  }

  // 4c. Every spec and plan has front matter with a state and, with a roadmap, a Milestone line the roadmap resolves.
  const docs = tracked.filter((p) => p.endsWith('.md') && specDirs.some((dir) => path.posix.dirname(p) === dir.replace(/\/$/, '')));
  const completedIds = new Set(roadmap ? roadmap.completed.map((c) => c.id) : []);
  const milestoneIds = new Set(
    roadmap ? [...roadmap.milestones.map((m) => m.id), ...roadmap.completed.map((c) => c.id.split('.')[0])] : []
  );
  for (const file of ledger ? docs : []) {
    let body;
    try {
      body = parseFrontMatter(readRepo(file), file).body;
    } catch {
      continue; // already reported as malformed by the reader
    }
    const row = specRows.find((s) => s.path === file);
    if (!row) {
      problems.push(`milestone: ${file} has no front matter with a state`);
      continue;
    }
    if (ROADMAP === undefined) continue; // the Milestone-line rule needs the roadmap; the summary says it was skipped
    const ids = documentMilestones(body);
    if (ids.length !== 1) {
      problems.push(`milestone: ${file} needs exactly one "**Milestone:** <id>" line before its first section (found ${ids.length})`);
      continue;
    }
    const id = ids[0];
    if (!ID.test(id)) {
      problems.push(`milestone: ${file} id "${id}" is not M<n>.<k>, M<n> or X<n>`);
      continue;
    }
    if (!roadmap) continue;
    if (PHASE_ID.test(id)) {
      const phase = openPhases.find((p) => p.id === id);
      if (!phase && !completedIds.has(id)) problems.push(`milestone: ${file} names ${id}, which is neither an open nor a completed phase`);
      else if (phase && ACTIVE_SPEC_STATES.includes(row.state) && phase.spec !== file && !phase.plans?.includes(file))
        problems.push(`milestone: ${file} is ${row.state} under ${id} but ${id} names neither it as Spec nor as Plan`);
    } else if (MILESTONE_ID.test(id)) {
      if (!milestoneIds.has(id)) problems.push(`milestone: ${file} names ${id}, which is not a milestone in ${ROADMAP}`);
      if (!CLOSED_SPEC_STATES.includes(row.state))
        problems.push(`milestone: ${file} is ${row.state} but carries milestone-level ${id} — an open spec or plan needs a phase or X id`);
    } else if (!xIds.has(id)) {
      problems.push(`milestone: ${file} names ${id}, which is not under Outside the roadmap in ${ROADMAP}`);
    }
  }
  // A plan's front matter `spec` agrees with its body's `**Spec:**` line, when that names a file.
  for (const row of specRows) {
    if (!row.specPath) continue;
    const line = SPEC_LINE.exec(parseFrontMatter(readRepo(row.path), row.path).body);
    if (line && line[1] !== row.specPath)
      problems.push(`stale: ${row.path} front matter spec is ${row.specPath} but its **Spec:** line names ${line[1]}`);
  }
  for (const row of ROADMAP === undefined ? [] : specRows) {
    if (!row.specPath || !row.milestone) continue;
    const spec = specRows.find((s) => s.kind === 'spec' && s.path === row.specPath);
    // A plan carries its spec's id, or another phase of the same milestone when its spec spans several phases.
    const samePhaseFamily = (a, b) => PHASE_ID.test(a) && PHASE_ID.test(b) && a.split('.')[0] === b.split('.')[0];
    if (spec && spec.milestone !== row.milestone && !samePhaseFamily(spec.milestone, row.milestone))
      problems.push(`milestone: ${row.path} carries ${row.milestone} but its spec ${spec.path} carries ${spec.milestone} (another milestone)`);
  }
  for (const o of roadmap && ledger ? roadmap.outside : []) {
    const listed = new Set([o.spec, o.plan].filter(Boolean));
    const carrying = new Set(specRows.filter((s) => s.milestone === o.id).map((s) => s.path));
    for (const p of listed) if (!carrying.has(p)) problems.push(`milestone: ${ROADMAP} ${o.id} lists ${p}, whose **Milestone:** line does not carry ${o.id}`);
    for (const p of carrying) if (!listed.has(p)) problems.push(`milestone: ${p} carries ${o.id} but ${ROADMAP} ${o.id} does not list it`);
  }

  // 5. No broken links: every relative link in tracked markdown points at a tracked file or directory.
  const repoEntries = new Set(gitFiles().flatMap((f) => f.split('/').map((_, i, parts) => parts.slice(0, i + 1).join('/'))));
  let linksChecked = 0;
  for (const file of tracked) {
    if (linkExempt.some((prefix) => file.startsWith(prefix))) continue;
    linksChecked += 1;
    for (const { line, href, target } of brokenLinks(file, readRepo(file), (t) => repoEntries.has(t)))
      problems.push(`broken link: ${file}:${line} links to ${href}, but ${target} does not exist — fix the path or remove the link`);
  }

  // 6. Date rule.
  if (ledger) reviewedAtRule(problems, INDEX, ledger.reviewedAt);

  const milestones =
    ROADMAP === undefined
      ? `${docs.length} specs/plans, Milestone lines not checked (no roadmap)`
      : `${docs.length} specs/plans carry a milestone id`;
  const summary =
    `${reviews.length} reviews cover ${tracked.length} tracked markdown files; ` +
    `${milestones}; links in ${linksChecked} files resolve`;
  return { problems, ledger, documents, tracked, summary };
}
