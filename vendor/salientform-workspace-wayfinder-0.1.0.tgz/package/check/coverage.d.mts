/** One coverage measure: how many items there are and how many a test reached. */
export interface CoverageMetric {
  total: number;
  covered: number;
}

/** A file's (or a feature's) v8 coverage, as `json-summary` writes it. */
export interface CoverageMetrics {
  lines: CoverageMetric;
  statements: CoverageMetric;
  functions: CoverageMetric;
  branches: CoverageMetric;
}

/** Every coverage summary the Features area found. */
export interface CoverageReport {
  /** Each summary read: its repository path, when it was written (its mtime, ISO) and how many files it measures. */
  summaries: { path: string; producedAt: string; files: number }[];
  /** Per repository-relative source file, its metrics. */
  files: Record<string, CoverageMetrics>;
}

/** A feature's coverage: its measured files, the code files no summary covers, the total and the newest summary's date. */
export interface FeatureCoverage {
  files: { file: string; metrics: CoverageMetrics }[];
  unmeasured: string[];
  total: CoverageMetrics;
  producedAt: string | undefined;
}

/** The project directory a summary path names: everything before `/test-output/` or `/coverage/`. */
export function summaryProject(summary: string): string;
export const COVERAGE_KEYS: readonly (keyof CoverageMetrics)[];
export function sumCoverage(metrics: readonly CoverageMetrics[]): CoverageMetrics;
/** covered / total as a percentage; 100 for nothing to cover. */
export function percent(metric: CoverageMetric): number;
/** Whether coverage could measure a file: a script, not a declaration. */
export function isCode(file: string): boolean;
/** A feature's coverage over the files its sources match; undefined when no summary covers any of them. */
export function coverageOver(files: readonly string[], report: CoverageReport): FeatureCoverage | undefined;
/** Whether a visited path opens a route, a `:param` segment matching any segment. */
export function routeMatches(route: string, visited: string): boolean;
/** The routes some visited path opens, in `routes` order. */
export function routesVisited(routes: readonly string[], visits: readonly string[]): string[];

