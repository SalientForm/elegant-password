export interface MarkdownLink {
  /** 1-based line of the link. */
  line: number;
  href: string;
}

export interface BrokenLink extends MarkdownLink {
  /** Repository path the href resolves to, without fragment or query. */
  target: string;
}

/** Every relative link (inline `[text](href)` and reference `[id]: href`) outside code, with its 1-based line. */
export function relativeLinks(markdown: string): MarkdownLink[];

/** The repository path a relative href in `file` points at, without its fragment or query. */
export function linkTarget(file: string, href: string): string;

/**
 * The links in `file` whose target `exists(target)` denies. A link to the file itself by fragment (`#x`) or to an
 * external URL is never checked; a link resolving outside the repository is reported.
 */
export function brokenLinks(
  file: string,
  markdown: string,
  exists: (target: string) => boolean
): BrokenLink[];
