/**
 * The Audit implementation drift check (spec M12.8 §5.6): the roadmap, the TODO list and the architecture document's
 * Stack summary and Planned migrations, all named in settings.areas[slug] with the conventions they are parsed with.
 * Plain node; the kit's runner loads the settings, runs these rules and the spec ledger's (audit-ledger.mjs) over
 * the parsed data this returns.
 *
 * Each of the three files is optional (plan C): a rule that reads a file that is not configured is skipped, and the
 * summary names only what was checked.
 *
 * Fails when:
 *  - a configured file does not exist, does not parse, or breaks its structural rules (audit-markdown.mjs)
 *  - a phase Spec / Plan, a Completed ref, an Outside the roadmap Spec / Plan, a TODO path Source or a stack Ref path
 *    does not exist
 *  - a stack Ref or a Planned migrations bullet names an id that is not in the roadmap, or any roadmap id when no
 *    roadmap is configured, or a planned stack row names a phase that is not open
 *  - a file's "Reviewed:" line fails the date rule
 */
import { exists, modifiedDateRule, readRepo } from './index.mjs';
import { auditSettings } from './settings-defaults.mjs';
import {
  MILESTONE_ID,
  PHASE_ID,
  isTodoPath,
  parsePlannedMigrations,
  parseRoadmap,
  parseStackSummary,
  parseTodos,
} from './audit-markdown.mjs';

const PATH_KEYS = ['roadmap', 'todo', 'architecture'];

/**
 * Runs the implementation-page rules over `settings` (the workspace config's data half); `slug` is the area's key in
 * `settings.areas`. Returns { problems, paths, roadmap, todos, stack, plannedMigrations, summary }. `paths` holds only
 * the configured files; a file that is not configured, missing or does not parse is null, and the rules that need it
 * are skipped (a missing or malformed file's problem is already reported). Tell "not configured" from "did not parse"
 * by `paths`.
 */
export function checkAuditImplementation(settings, { slug = 'audit' } = {}) {
  const raw = settings.areas[slug];
  if (!raw) throw new Error(`wayfinder: settings.areas.${slug} is not configured`);
  const area = auditSettings(raw);
  for (const key of PATH_KEYS)
    if (area[key] !== undefined && (typeof area[key] !== 'string' || area[key] === ''))
      throw new Error(`wayfinder: settings.areas.${slug}.${key} is not a repository path`);
  for (const key of ['phaseKinds', 'todoAreas'])
    if (area[key] !== undefined && !Array.isArray(area[key])) throw new Error(`wayfinder: settings.areas.${slug} has no ${key} list`);
  const paths = Object.fromEntries(PATH_KEYS.filter((key) => area[key] !== undefined).map((key) => [key, area[key]]));
  const problems = [];

  /** Parse a configured file, or record why not and return null; null without a record when it is not configured. */
  const parsed = (file, parse) => {
    if (file === undefined) return null;
    if (!exists(file)) {
      problems.push(`missing: ${file} does not exist`);
      return null;
    }
    try {
      return parse(readRepo(file));
    } catch (e) {
      problems.push(`malformed: ${e.message}`);
      return null;
    }
  };
  const roadmap = parsed(paths.roadmap, (md) => parseRoadmap(md, { ...area, file: paths.roadmap }));
  const todos = parsed(paths.todo, (md) => parseTodos(md, { ...area, file: paths.todo }));
  const stack = parsed(paths.architecture, (md) => parseStackSummary(md, { file: paths.architecture }));
  const plannedMigrations = parsed(paths.architecture, (md) => parsePlannedMigrations(md, { file: paths.architecture }));

  const openPhases = roadmap ? roadmap.milestones.flatMap((m) => m.phases) : [];
  const roadmapIds = new Set(
    roadmap ? [...roadmap.milestones.map((m) => m.id), ...openPhases.map((p) => p.id), ...roadmap.completed.map((c) => c.id)] : []
  );
  const ROADMAP = paths.roadmap, TODO = paths.todo, ARCH = paths.architecture;

  for (const p of openPhases) {
    for (const [label, file] of [['Spec', p.spec], ...(p.plans ?? []).map((f) => ['Plan', f])]) {
      if (file && !exists(file)) problems.push(`missing: ${ROADMAP} ${p.id} ${label} ${file} does not exist`);
    }
  }
  for (const c of roadmap ? roadmap.completed : []) {
    if (c.ref && !exists(c.ref)) problems.push(`missing: ${ROADMAP} Completed ${c.id} ref ${c.ref} does not exist`);
  }
  for (const o of roadmap ? roadmap.outside : []) {
    for (const [label, file] of [['Spec', o.spec], ['Plan', o.plan]]) {
      if (file && !exists(file)) problems.push(`missing: ${ROADMAP} ${o.id} ${label} ${file} does not exist`);
    }
  }
  for (const t of todos ? todos.todos : []) {
    if (isTodoPath(t.source, area.todoSources) && !exists(t.source)) problems.push(`missing: ${TODO} #${t.id} Source ${t.source} does not exist`);
  }
  for (const item of stack ? stack.items : []) {
    if (!item.ref || item.ref.startsWith('§')) continue;
    if (PHASE_ID.test(item.ref) || MILESTONE_ID.test(item.ref)) {
      if (ROADMAP === undefined) {
        problems.push(`stale: ${ARCH} stack row "${item.item}" Ref ${item.ref} is a roadmap id, but settings.areas.${slug} has no roadmap`);
        continue;
      }
      if (!roadmap) continue;
      if (!roadmapIds.has(item.ref)) problems.push(`stale: ${ARCH} stack row "${item.item}" Ref ${item.ref} is not in ${ROADMAP}`);
      else if (item.planned && !openPhases.some((p) => p.id === item.ref || p.milestoneId === item.ref)) {
        problems.push(`stale: ${ARCH} stack row "${item.item}" is planned but ${item.ref} is not open — mark it current`);
      }
    } else if (!exists(item.ref)) problems.push(`missing: ${ARCH} stack row "${item.item}" Ref ${item.ref} does not exist`);
  }
  if (ROADMAP === undefined)
    for (const id of plannedMigrations ?? [])
      problems.push(`stale: ${ARCH} Planned migrations names ${id}, but settings.areas.${slug} has no roadmap`);
  for (const id of roadmap ? plannedMigrations ?? [] : []) {
    if (!openPhases.some((p) => p.id === id)) problems.push(`stale: ${ARCH} Planned migrations names ${id}, which is not an open phase in ${ROADMAP}`);
  }

  for (const file of [ROADMAP, TODO, ARCH]) {
    if (file === undefined || !exists(file)) continue;
    const m = /^Reviewed: (\d{4}-\d{2}-\d{2})$/m.exec(readRepo(file));
    if (!m) problems.push(`${file}: missing "Reviewed: YYYY-MM-DD" line`);
    else modifiedDateRule(problems, `${file}: Reviewed`, m[1]);
  }

  // Only what is configured is named: "14 open phases, 13 todos, 31 stack rows", or less, or nothing.
  const summary = [
    ...(ROADMAP === undefined ? [] : [`${openPhases.length} open phases`]),
    ...(TODO === undefined ? [] : [`${todos ? todos.todos.length : 0} todos`]),
    ...(ARCH === undefined ? [] : [`${stack ? stack.items.length : 0} stack rows`]),
  ].join(', ');
  return { problems, paths, roadmap, todos, stack, plannedMigrations, summary };
}
