/**
 * Coverage for the Features area (spec M13 §7, plan M13.3): line, statement, function and branch coverage summed over
 * the files a feature's `sources` match, and the routes its end-to-end tests visit. Dependency-free ESM, so the module
 * (through Vite) and node agree; the summaries are read by coverage-scan.mjs. Types: coverage.d.mts.
 */

export const COVERAGE_KEYS = ['lines', 'statements', 'functions', 'branches'];
/** Files coverage can measure: scripts, not declarations, styles or data. */
const CODE = /\.[cm]?[jt]sx?$/;
const DECLARATION = /\.d\.[cm]?ts$/;

const empty = () => Object.fromEntries(COVERAGE_KEYS.map((key) => [key, { total: 0, covered: 0 }]));

/** The metrics of several files added up. */
export function sumCoverage(metrics) {
  const total = empty();
  for (const m of metrics)
    for (const key of COVERAGE_KEYS) {
      total[key].total += m[key].total;
      total[key].covered += m[key].covered;
    }
  return total;
}

/** covered / total as a percentage; 100 for nothing to cover. */
export function percent(metric) {
  return metric.total === 0 ? 100 : (metric.covered / metric.total) * 100;
}

/** Whether coverage could measure `file`: a script, not a declaration. */
export const isCode = (file) => CODE.test(file) && !DECLARATION.test(file);

/** The project directory a summary path names: everything before `/test-output/` or `/coverage/`. */
export const summaryProject = (summary) => summary.replace(/\/(test-output|coverage)\/.*$/, '');

/**
 * A feature's coverage over `files` (the scanned files its sources match): the measured files with their metrics, the
 * code files no summary covers, the total, and when the newest summary of a project holding a measured file was
 * written. Undefined when no summary covers any of them: "Not measured", never 0%.
 */
export function coverageOver(files, report) {
  const measured = [];
  const unmeasured = [];
  for (const file of files) {
    const metrics = report.files[file];
    if (metrics) measured.push({ file, metrics });
    else if (isCode(file)) unmeasured.push(file);
  }
  if (measured.length === 0) return undefined;
  const producedAt = report.summaries
    .filter((s) => measured.some(({ file }) => file.startsWith(`${summaryProject(s.path)}/`)))
    .map((s) => s.producedAt)
    .sort()
    .at(-1);
  return { files: measured, unmeasured, total: sumCoverage(measured.map((m) => m.metrics)), producedAt };
}

/** Whether a visited path (`/orders/order/:param`) opens `route` (`/orders/order/:orderId`). */
export function routeMatches(route, visited) {
  const split = (p) => p.replace(/\/+$/, '').split('/');
  const r = split(route);
  const v = split(visited);
  return r.length === v.length && r.every((segment, i) => segment.startsWith(':') || segment === v[i]);
}

/** The routes some path in `visits` opens, in `routes` order. */
export function routesVisited(routes, visits) {
  return routes.filter((route) => visits.some((visited) => routeMatches(route, visited)));
}
