/**
 * The workspace's ports and its links to the repository's other apps (spec M12.11 §6.13), checked the same way by
 * `wayfinder()` (node, when Vite loads its config) and `createWorkspace` (the browser, at load). Dependency-free ESM.
 * Types: ports.d.mts.
 */

/** Ports a framework or tool picks by default: never the workspace's, which the repository assigns. */
export const FRAMEWORK_PORTS = [3000, 3001, 4173, 4200, 5000, 5173, 8000, 8080];

const isPort = (value) => Number.isInteger(value) && value >= 1024 && value <= 65535;

/** One port's problem, or undefined: an integer from 1024 to 65535 that is not a framework default. */
function portProblem(value, at) {
  if (!isPort(value)) return `${at} ${JSON.stringify(value)} is not an integer from 1024 to 65535`;
  if (FRAMEWORK_PORTS.includes(value)) return `${at} ${value} is a framework default (${FRAMEWORK_PORTS.join(', ')}): use the repository's own`;
  return undefined;
}

/**
 * The problems of a `{ dev, preview }` pair: each port an integer from 1024 to 65535 and not a framework default, the
 * two different. `at` names the setting in each problem ('settings.ports', or 'wayfinder({ ports })' for an override).
 */
export function portsProblems(ports, at = 'settings.ports') {
  if (typeof ports !== 'object' || ports === null || Array.isArray(ports))
    return [`${at} is missing: the workspace's { dev, preview } ports, assigned when the kit is set up`];
  const problems = [];
  for (const key of Object.keys(ports)) if (key !== 'dev' && key !== 'preview') problems.push(`${at} has an unknown field ${JSON.stringify(key)}`);
  for (const key of ['dev', 'preview']) {
    const problem = portProblem(ports[key], `${at}.${key}`);
    if (problem) problems.push(problem);
  }
  if (isPort(ports.dev) && ports.dev === ports.preview) problems.push(`${at}.dev and ${at}.preview are both ${ports.dev}`);
  return problems;
}

/**
 * The problems of `settings.links`: a list of `{ label, port, path }`, each with a label, a port from 1024 to 65535
 * other than the workspace's own, and an absolute path; labels unique.
 */
export function linksProblems(links, ports) {
  if (links === undefined) return [];
  if (!Array.isArray(links)) return ['settings.links is not a list'];
  const problems = [];
  const labels = new Set();
  const own = [ports?.dev, ports?.preview];
  links.forEach((link, i) => {
    const at = `settings.links[${i}]`;
    if (typeof link !== 'object' || link === null || Array.isArray(link)) {
      problems.push(`${at} is not an object`);
      return;
    }
    for (const key of Object.keys(link))
      if (!['label', 'port', 'path'].includes(key)) problems.push(`${at} has an unknown field ${JSON.stringify(key)}`);
    if (typeof link.label !== 'string' || link.label.trim() === '') problems.push(`${at} has no label`);
    else if (labels.has(link.label)) problems.push(`${at} label ${JSON.stringify(link.label)} repeats`);
    else labels.add(link.label);
    if (!isPort(link.port)) problems.push(`${at}.port ${JSON.stringify(link.port)} is not an integer from 1024 to 65535`);
    else if (own.includes(link.port)) problems.push(`${at}.port ${link.port} is the workspace's own`);
    if (typeof link.path !== 'string' || !link.path.startsWith('/')) problems.push(`${at}.path ${JSON.stringify(link.path)} does not start with '/'`);
  });
  return problems;
}

/**
 * Where a link points from a page of the workspace. On a dev server, or a build served at '/', the other app runs on
 * its own port: the page's host on `link.port`, so the link works on localhost and through a proxy that mirrors the
 * ports (Tailscale Serve). In a build served under a base other than '/', the apps share an origin: `link.path`.
 */
export function linkHref(link, { dev, base, location }) {
  return dev || base === '/' ? `${location.protocol}//${location.hostname}:${link.port}/` : link.path;
}
