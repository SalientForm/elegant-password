/** The runner a test file is written for: from its imports, or the area's `tests.playwright` globs. */
export type TestRunner = 'vitest' | 'playwright' | 'node';

/** One test, as its source declares it. */
export interface TestCase {
  /** The enclosing describe titles, outermost first. */
  path: string[];
  /** As written; a template or computed title is its source text. */
  title: string;
  /** 1-based line of the call. */
  line: number;
  /** Its own, or an enclosing describe's. */
  modifier?: 'skip' | 'only' | 'todo' | 'fixme';
  /** `.each` / `.for`, or declared inside a loop: the title is a template, not one test. */
  parameterised?: boolean;
  /** Playwright tags: `{ tag }` on the test or an enclosing describe, and `@tokens` in their titles. */
  tags: string[];
  /**
   * Playwright only, when any: the paths the test opens with `*.goto(…)`, from its body, the `beforeEach` hooks of its
   * file and describes, and the same-file functions they call; a template's `${…}` is a `:param` segment.
   */
  visits?: string[];
}

/** One test file. */
export interface TestFile {
  /** Repository-relative path. */
  file: string;
  runner: TestRunner;
  /** The nearest project.json's, else package.json's, `name`; '' for none. */
  project: string;
  tests: TestCase[];
}

/** Every test file the Features area's `tests.include` globs match, in path order. */
export interface TestInventory {
  files: TestFile[];
}

/**
 * `loaded`, what `require('typescript')` gave (undefined when it threw), when it has the compiler API the inventory
 * parses with; otherwise throws, saying what to install. `typescript` is an optional peer dependency (5.x), loaded on
 * the first parse.
 */
export function compilerFrom<T>(loaded: T | undefined): T;

/** One file's tests, parsed from its source; `playwright` forces the Playwright runner. */
export function parseTestFile(
  file: string,
  source: string,
  options?: { playwright?: boolean },
): Pick<TestFile, 'file' | 'runner' | 'tests'>;

/** The inventory under `repoRoot`; `parse` defaults to parseTestFile (the Vite plugin passes a cached one). */
export function scanTests(
  repoRoot: string,
  tests: { include: readonly string[]; playwright?: readonly string[] },
  parse?: typeof parseTestFile,
): TestInventory;
