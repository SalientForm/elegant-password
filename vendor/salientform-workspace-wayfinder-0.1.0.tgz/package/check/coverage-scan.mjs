/**
 * Reads v8 `json-summary` coverage files for the Features area (plan M13.3). Plain node; the Vite plugin and the check
 * share it. Types: coverage.d.mts.
 */
import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { COVERAGE_KEYS, summaryProject } from './coverage.mjs';
import { globBase, globMatcher } from './features.mjs';

const SKIP_DIRS = new Set(['node_modules', 'dist', 'out-tsc', '.nx', '.git']);

function walk(repoRoot, dir, out) {
  let entries;
  try {
    entries = readdirSync(path.join(repoRoot, dir), { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    if (SKIP_DIRS.has(entry.name)) continue;
    const rel = dir ? `${dir}/${entry.name}` : entry.name;
    if (entry.isDirectory()) walk(repoRoot, rel, out);
    else out.add(rel);
  }
}

/**
 * A summary key (an absolute path in the checkout that ran the tests) as a repository path. Under `repoRoot` it is made
 * relative; otherwise it is cut at `projectDir`, the directory the summary's own path names, so a summary from another
 * checkout still lands on this one's files. Undefined when neither applies.
 */
export function summaryKeyPath(key, repoRoot, projectDir) {
  const posix = key.split(path.sep).join('/');
  const root = repoRoot.split(path.sep).join('/').replace(/\/$/, '');
  if (posix.startsWith(`${root}/`)) return posix.slice(root.length + 1);
  const at = posix.lastIndexOf(`/${projectDir}/`);
  return at === -1 ? undefined : posix.slice(at + 1);
}

/**
 * Every summary `summaries` (globs) matches under `repoRoot`, merged: `{ summaries, files, problems }`. A file in two
 * summaries keeps the later one's metrics. A summary that does not parse is skipped and named in `problems`.
 */
export function readCoverage(repoRoot, summaries) {
  const matchers = summaries.map(globMatcher);
  const found = new Set();
  const bases = [...new Set(summaries.map(globBase))];
  for (const base of bases) walk(repoRoot, base, found);
  const paths = [...found].filter((file) => matchers.some((match) => match(file))).sort();
  const report = { summaries: [], files: {} };
  const problems = [];
  for (const summary of paths) {
    const full = path.join(repoRoot, summary);
    let json;
    try {
      json = JSON.parse(readFileSync(full, 'utf8'));
    } catch {
      problems.push(`${summary} is not JSON`);
      continue;
    }
    const projectDir = summaryProject(summary);
    let count = 0;
    for (const [key, metrics] of Object.entries(json)) {
      if (key === 'total' || typeof metrics !== 'object' || metrics === null) continue;
      const file = summaryKeyPath(key, repoRoot, projectDir);
      if (!file || !COVERAGE_KEYS.every((k) => typeof metrics[k]?.total === 'number')) continue;
      report.files[file] = Object.fromEntries(COVERAGE_KEYS.map((k) => [k, { total: metrics[k].total, covered: metrics[k].covered }]));
      count++;
    }
    report.summaries.push({ path: summary, producedAt: statSync(full).mtime.toISOString(), files: count });
  }
  return { ...report, problems };
}
