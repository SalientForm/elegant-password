/**
 * The API drift check (spec M12.6 §5.6): the OpenAPI document and the optional consumer registry the workspace config
 * names, built by the operation builder the module shares (api-operations.mjs), and the registry's reviewed date.
 * Plain node; the kit's runner (run.mjs) loads the settings and passes the request paths a rules file's `fetchSites`
 * returns.
 *
 * Fails when:
 *  - settings.areas[slug].document does not exist or is not JSON, or has no paths object
 *  - settings.areas[slug].registry is set and does not exist, is not JSON, or has a problem (a bad row or group)
 *  - an operation is in the document but not in the registry, a row not marked outsideDocument is not in the
 *    document, or a row marked outsideDocument is
 *  - a registry row's handler does not exist
 *  - settings.areas[slug].reviewedAt fails the date rule (required with a registry)
 *  - a `generated` file differs from the output of its command, or the command fails
 *  - with fetch sites (`fetched`, else the scan of `callers.roots`): a fetched path has no registry row, a fetched
 *    path's GET (else POST) row is not `used`, or a `used` GET under basePath is fetched nowhere
 */
import { execFileSync } from 'node:child_process';
import { readdirSync } from 'node:fs';
import path from 'node:path';
import { exists, modifiedDateRule, readRepo, repoRoot } from './index.mjs';
import { apiOperations, documentOperations } from './api-operations.mjs';

/** A repository JSON file, or a problem naming it. */
function readJson(file, setting, problems) {
  if (!exists(file)) {
    problems.push(`fatal: ${file} (${setting}) does not exist`);
    return undefined;
  }
  try {
    return JSON.parse(readRepo(file));
  } catch (error) {
    problems.push(`fatal: ${file} (${setting}) is not JSON: ${error.message}`);
    return undefined;
  }
}

const SKIP_DIRS = new Set(['node_modules', 'dist', 'out-tsc', 'build', 'coverage']);
const SOURCE_FILE = /\.[cm]?[jt]sx?$/;
const TEST_FILE = /\.(test|spec)\.[cm]?[jt]sx?$/;

/** Every non-test source file under `dir` (repository-relative), skipping build output and dependencies. */
function sourceFiles(dir, acc = []) {
  if (!exists(dir)) return acc;
  for (const entry of readdirSync(path.join(repoRoot, dir), { withFileTypes: true })) {
    const p = path.posix.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (!SKIP_DIRS.has(entry.name)) sourceFiles(p, acc);
    } else if (SOURCE_FILE.test(entry.name) && !TEST_FILE.test(entry.name)) acc.push(p);
  }
  return acc;
}

/**
 * The request paths under `basePath` the files under `roots` call: the first argument of `fetch('…')` and of an
 * openapi-fetch style `<client>.GET|POST|PUT|PATCH|DELETE('…')`, a string or template literal, up to any query.
 */
export function scanFetchSites(roots, basePath = '/') {
  const base = basePath.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const call = new RegExp(`(?:\\.(?:GET|POST|PUT|PATCH|DELETE)|\\bfetch)\\(\\s*[\`'"](${base}[^\`'"?]*)`, 'g');
  return roots.flatMap((root) => sourceFiles(root)).flatMap((file) => [...readRepo(file).matchAll(call)].map((m) => m[1]));
}

/** The `generated` rule: each file equals the stdout of its command, run at the repository root. */
function generatedRule(generated, at, problems) {
  for (const [i, { path: file, command, fix }] of generated.entries()) {
    if (typeof file !== 'string' || !Array.isArray(command) || command.length === 0) {
      problems.push(`fatal: ${at}.generated[${i}] needs a path and a command (an argv array)`);
      continue;
    }
    let fresh;
    try {
      fresh = execFileSync(command[0], command.slice(1), { cwd: repoRoot, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (error) {
      const stderr = error.stderr?.toString().trim().split('\n')[0] || error.message;
      problems.push(`fatal: ${file} could not be regenerated (\`${command.join(' ')}\`): ${stderr}`);
      continue;
    }
    if (!exists(file) || fresh !== readRepo(file))
      problems.push(`fatal: ${file} is stale: it differs from a fresh \`${command.join(' ')}\`${fix ? ` — run: ${fix}` : ''}`);
  }
}

/**
 * Runs the API rules over `settings` (the workspace config's data half); `slug` is the area's key in
 * `settings.areas`. `fetched` are the request paths the product's code calls (a rules file's `fetchSites`); omitted,
 * they are scanned from `callers.roots`, and without those the consumer rules are skipped. Returns
 * { problems, summary }.
 */
export function checkApi(settings, { slug = 'api', fetched } = {}) {
  const area = settings.areas[slug];
  if (typeof area?.document !== 'string') throw new Error(`wayfinder: settings.areas.${slug} has no document`);
  const at = `settings.areas.${slug}`;
  const problems = [];

  const document = readJson(area.document, `${at}.document`, problems);
  const hasRegistry = area.registry !== undefined;
  const registry = hasRegistry ? readJson(area.registry, `${at}.registry`, problems) : undefined;
  const operations = document === undefined ? [] : documentOperations(document);

  let rows = [];
  if (document !== undefined && (!hasRegistry || registry !== undefined)) {
    const built = apiOperations(document, registry, { document: area.document, registry: area.registry });
    for (const problem of [...built.problems, ...built.drift]) problems.push(`fatal: ${problem}`);
    rows = built.operations.filter((op) => op.endpoint);
  }

  for (const { key, endpoint } of rows)
    if (endpoint.handler && !exists(endpoint.handler))
      problems.push(`fatal: ${area.registry}: ${key} handler ${endpoint.handler} does not exist`);

  if (hasRegistry || area.reviewedAt !== undefined) modifiedDateRule(problems, `${at}.reviewedAt`, area.reviewedAt);

  generatedRule(area.generated ?? [], at, problems);

  if (fetched === undefined && area.callers?.roots) fetched = scanFetchSites(area.callers.roots, area.basePath ?? '/');

  if (fetched !== undefined && hasRegistry) {
    const basePath = area.basePath ?? '/';
    const status = new Map(rows.map(({ key, endpoint }) => [key, endpoint.status]));
    const paths = new Set(fetched);
    for (const path of paths) {
      const found = status.get(`GET ${path}`) ?? status.get(`POST ${path}`);
      if (found !== undefined && found !== 'used')
        problems.push(`fatal: ${path} is fetched, but ${area.registry} marks it '${found}'`);
      if (found === undefined && !rows.some((op) => op.path === path))
        problems.push(`fatal: ${path} is fetched, but ${area.registry} has no row for it`);
    }
    for (const { key, method, path, endpoint } of rows)
      if (endpoint.status === 'used' && method === 'GET' && path.startsWith(basePath) && !paths.has(path))
        problems.push(`fatal: ${key} is marked used in ${area.registry}, but nothing fetches it`);
  }

  const parts = [`${operations.length} operations in ${area.document}`];
  if (hasRegistry) parts.push(`${rows.length} registry rows`);
  if (fetched !== undefined) parts.push(`${new Set(fetched).size} fetched paths`);
  return { problems, summary: `${settings.product}: ${parts.join(', ')}` };
}
