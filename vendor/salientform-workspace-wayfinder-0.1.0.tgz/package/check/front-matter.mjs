/**
 * Front matter for markdown files: a leading `---` block parsed as YAML (the `yaml` package, its core schema: a date
 * stays a string), so a list over several lines or a folded value reads as it does in any other YAML tool (spec M12.11
 * §6.15). Shared by the workspace (through Vite) and the check scripts (through plain node). Types: front-matter.d.mts.
 */
import { parse } from 'yaml';

const BLOCK = /^---[ \t]*\r?\n(?:([\s\S]*?)\r?\n)?---[ \t]*(?:\r?\n|$)/;

const isMapping = (value) => typeof value === 'object' && value !== null && !Array.isArray(value);

/**
 * `{ data, body }` of `markdown`: the block's mapping and what follows it. No block: `data` is empty and `body` the
 * whole input. A block that is not valid YAML, or not a mapping, throws; `file`, when given, names it in the message.
 */
export function parseFrontMatter(markdown, file) {
  const match = BLOCK.exec(markdown);
  if (!match) return { data: {}, body: markdown };
  const at = (line, problem) => new Error(`${file ? `${file}:${line}` : `line ${line}`}: front matter ${problem}`);
  let data;
  try {
    data = parse(match[1] ?? '') ?? {};
  } catch (error) {
    throw at((error.linePos?.[0]?.line ?? 0) + 1, `is not valid YAML: ${error.message.split('\n')[0]}`);
  }
  if (!isMapping(data)) throw at(2, 'is not a mapping of keys to values');
  return { data, body: markdown.slice(match[0].length) };
}

/**
 * The body of `markdown` for rendering: without its front matter when the block parses, as written when it does not,
 * so a document's own leading `---` (a rule) or a broken block never stops a page rendering.
 */
export function stripFrontMatter(markdown) {
  try {
    return parseFrontMatter(markdown).body;
  } catch {
    return markdown;
  }
}
