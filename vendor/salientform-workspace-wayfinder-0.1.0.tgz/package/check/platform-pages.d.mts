/** One Platform Docs page, built from a front-matter markdown file. */
export interface PlatformPage {
  /** URL segment: the file name without its numeric prefix and `.md`. */
  slug: string;
  title: string;
  order: number;
  summary: string;
  /** Repository path. */
  path: string;
  /** Markdown after the front matter. */
  body: string;
}

/** `docs/platform/10-getting-started.md` (or `10-getting-started.md`) → `getting-started`: the page's URL segment. */
export function platformSlug(path: string): string;

/**
 * Pages built from their files, sorted by `order` then path, and every problem with them: a page with no `title`,
 * numeric `order` or `summary`, or two pages with one slug. A page with a problem is still built.
 */
export function platformPages(files: readonly { path: string; markdown: string }[]): {
  pages: PlatformPage[];
  problems: string[];
};
