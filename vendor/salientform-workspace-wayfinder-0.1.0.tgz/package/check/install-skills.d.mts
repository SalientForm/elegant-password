/** The kit's skills directory (`skills/` beside `check/`). */
export const KIT_SKILLS: string;
/** A file beside an installed skill the installer never touches. */
export const REPOSITORY_FILE: string;

/** One change installing the kit's skills would make, by repository path. */
export interface SkillChange {
  path: string;
  /**
   * In the skills directory: 'add', 'update', 'remove'. In an agent directory: 'link', 'relink', 'unlink', 'move' (a
   * real directory of a kit skill, moved to `to`) and 'conflict' (in the way of a link to `to`; nothing is written).
   * In either, 'drop': a file or link of a kit skill whose area is not configured.
   */
  change: 'add' | 'update' | 'remove' | 'link' | 'relink' | 'unlink' | 'move' | 'conflict' | 'drop';
  /** A 'move''s destination; a 'conflict''s other path. */
  to?: string;
}

interface InstallOptions {
  /** The repository root. Default the cwd's git top level. */
  root?: string;
  /** The kit's skills directory. Default KIT_SKILLS. */
  kitDir?: string;
  /** The agent directories that get a link per kit skill (the settings' `skillLinks`). Default none. */
  skillLinks?: readonly string[];
  /** The kit skills to install (`skillsFor`, or `['wayfinder-onboard']` for `wayfinder init`). Default every kit skill. */
  skills?: readonly string[];
  /** With `skills`: drop every other kit skill installed (its kit files and links). Default false. */
  prune?: boolean;
}

/** Why the installer will not write on `platform` (default process.platform), or undefined on Linux and macOS. */
export function platformProblem(platform?: string): string | undefined;
/** The names of the skills the kit ships. */
export function kitSkillNames(kitDir?: string): string[];
/** The kit skills every repository installs: `assess-workspace` and `wayfinder-onboard`. */
export const ALWAYS_SKILLS: readonly string[];
/** The kit skills the configured areas of `settings` use, sorted. */
export function skillsFor(settings: { areas?: Record<string, unknown> } | undefined): string[];
/** The target the link `<dir>/<name>` holds: the relative path from `dir` to `<skillsDir>/<name>`. */
export function linkTarget(dir: string, skillsDir: string, name: string): string;
/** What installing would change (repository-relative); `installedOnly` skips kit skills not installed, moves and unlinks. */
export function skillChanges(skillsDir: string, options?: InstallOptions & { installedOnly?: boolean }): SkillChange[];
/**
 * Installs the kit's skills into `skillsDir` and links them (unless `dryRun`) and returns the changes. Throws before
 * writing on a platform other than Linux or macOS (`platform`, default process.platform), on a link path git ignores, and on a 'conflict'.
 */
export function installSkills(skillsDir: string, options?: InstallOptions & { dryRun?: boolean; platform?: string }): SkillChange[];
/** One change as the script prints it (`would …` in a dry run). */
export function describeChange(change: SkillChange, dryRun?: boolean): string;

/** Each kit skill's link path in `skillLinks` that git ignores at `root` (none outside a git repository). */
export function ignoredLinks(skillLinks: readonly string[], options?: { root?: string; kitDir?: string; skills?: readonly string[] }): string[];

/** Why ignored link paths stop the install and the check, or undefined when there are none. */
export function ignoredLinksProblem(ignored: string[]): string | undefined;
