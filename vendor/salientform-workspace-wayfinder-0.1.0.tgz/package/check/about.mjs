/**
 * The About drift check (spec M12.3 §5.9): the prose files and the product's About manifest against the areas
 * the workspace config lists. Plain node; the product's check-about.mjs is a wrapper that loads the settings.
 *
 * Fails when:
 *  - an area configured in the workspace config (other than About) has no <prose>/<slug>.md and no kit default
 *  - a <prose>/*.md file is neither an area nor overview, shell or skills
 *  - overview, shell or skills has neither a <prose> file nor a kit default
 *  - a <prose>/*.md file has no front-matter `title:` or `summary:`
 *  - a script in the root package.json check script (`checkScript`, default workspace:check) belongs to a skill that
 *    is not in ABOUT_SKILLS
 *  - an ABOUT_SKILLS skill has no <skillsDir>/<name>/SKILL.md (the skills directory, default .agents/skills), or one
 *    of its scripts does not exist
 *  - the check script runs a kit skill's script through an agent directory (`skillLinks`, or the pre-§6.14 default
 *    .claude/skills) rather than from the skills directory
 *  - a `file:` the manifest names does not exist
 *  - an installed kit skill (a kit skill's directory under <skillsDir>) differs from the kit's: a file missing,
 *    changed or no longer shipped (REPOSITORY.md aside); install-skills.mjs installs them
 *  - a kit skill whose area is not configured (install-skills.mjs's skillsFor, plan C) has a kit file in <skillsDir>
 *    or a link in an agent directory; install-skills.mjs drops them
 *  - an installed kit skill has, in an agent directory of `skillLinks`, no symlink resolving to <skillsDir>/<name>
 *    (missing, a copy, or a link elsewhere); install-skills.mjs makes them (spec M12.11 §6.14)
 *  - git ignores a kit skill's link path in an agent directory of `skillLinks`: the links are committed
 *  - ABOUT_REVIEWED_AT fails the date rule
 */
import { readdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { dateRule, exists, readRepo, repoRoot } from './index.mjs';
import { parseFrontMatter } from './front-matter.mjs';
import { ABOUT_DEFAULTS, aboutSettings } from './settings-defaults.mjs';
import { ignoredLinks, ignoredLinksProblem, kitSkillNames, skillChanges, skillsFor } from './install-skills.mjs';

const INSTALL = 'node node_modules/@salientform/workspace-wayfinder/check/install-skills.mjs';

const FIXED_PROSE = ['overview', 'shell', 'skills'];

/** The names of the kit's default prose files (`prose/*.md` beside `check/`, spec M12.11 §6.5). */
export const KIT_PROSE = readdirSync(fileURLToPath(new URL('../prose/', import.meta.url)))
  .filter((f) => f.endsWith('.md'))
  .map((f) => f.replace(/\.md$/, ''));

const escapeRegExp = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/**
 * Runs the About rules over `settings` (the workspace config's data half); `slug` is About's key in
 * `settings.areas`, whose `manifest` and `prose` paths, `skillsDir` and `checkScript` the rules read. Returns the
 * problems and an OK summary.
 */
export function checkAbout(settings, slug = 'about') {
  const about = settings.areas[slug];
  if (typeof about?.manifest !== 'string' || typeof about?.prose !== 'string')
    throw new Error(
      `wayfinder: settings.areas.${slug} has no manifest and prose`
    );
  const { manifest: MANIFEST, prose: PROSE_DIR, skillsDir: SKILLS, skillLinks: LINKS, checkScript: CHECK } = aboutSettings(about);
  const slugs = Object.keys(settings.areas);
  const problems = [];

  // 1. Areas: every configured area other than About has a prose file, its own or the kit's.
  for (const s of slugs) {
    if (s !== slug && !exists(`${PROSE_DIR}/${s}.md`) && !KIT_PROSE.includes(s))
      problems.push(`fatal: area ${s} has no ${PROSE_DIR}/${s}.md, and the kit has no default for it`);
  }

  // 2–3. Prose files: known names, title and summary.
  const allowed = new Set([...FIXED_PROSE, ...slugs.filter((s) => s !== slug)]);
  const prose = exists(PROSE_DIR)
    ? readdirSync(path.join(repoRoot, PROSE_DIR))
        .filter((f) => f.endsWith('.md'))
        .sort()
    : [];
  for (const name of FIXED_PROSE)
    if (!prose.includes(`${name}.md`) && !KIT_PROSE.includes(name))
      problems.push(`fatal: ${PROSE_DIR}/${name}.md is missing, and the kit has no default for it`);
  for (const file of prose) {
    const name = file.replace(/\.md$/, '');
    if (!allowed.has(name))
      problems.push(
        `fatal: ${PROSE_DIR}/${file} is neither an area nor overview, shell or skills`
      );
    let data = {};
    try {
      ({ data } = parseFrontMatter(readRepo(`${PROSE_DIR}/${file}`), `${PROSE_DIR}/${file}`));
    } catch (error) {
      problems.push(`fatal: ${error.message}`);
      continue;
    }
    for (const key of ['title', 'summary'])
      if (!data[key])
        problems.push(
          `fatal: ${PROSE_DIR}/${file} has no front-matter ${key}:`
        );
  }

  // 4–6. Manifest: skills, scripts and files.
  const manifestSrc = readRepo(MANIFEST);
  const skillsStart = manifestSrc.indexOf('export const ABOUT_SKILLS');
  const skillsBlock =
    skillsStart === -1
      ? ''
      : manifestSrc.slice(
          skillsStart,
          skillsStart + manifestSrc.slice(skillsStart).search(/\n\];/)
        );
  if (skillsStart === -1)
    problems.push(`fatal: ${MANIFEST} has no ABOUT_SKILLS`);
  const skills = [
    ...skillsBlock.matchAll(/name:\s*'([^']+)'\s*,\s*scripts:\s*\[([^\]]*)\]/g),
  ].map((m) => ({
    name: m[1],
    scripts: [...m[2].matchAll(/'([^']+)'/g)].map((s) => s[1]),
  }));
  for (const skill of skills) {
    if (!exists(`${SKILLS}/${skill.name}/SKILL.md`))
      problems.push(
        `fatal: ABOUT_SKILLS ${skill.name} has no ${SKILLS}/${skill.name}/SKILL.md`
      );
    for (const script of skill.scripts)
      if (!exists(script))
        problems.push(
          `fatal: ABOUT_SKILLS ${skill.name} script ${script} does not exist`
        );
  }
  const checkCommand = exists('package.json')
    ? JSON.parse(readRepo('package.json')).scripts?.[CHECK] ?? ''
    : '';
  const skillScript = new RegExp(`${escapeRegExp(SKILLS)}/([^/\\s]+)/scripts/\\S+`, 'g');
  for (const m of checkCommand.matchAll(skillScript)) {
    if (!skills.some((s) => s.name === m[1]))
      problems.push(
        `fatal: ${CHECK} runs ${m[0]} but ${m[1]} is not in ABOUT_SKILLS`
      );
  }
  // Kit skills run from the skills directory: never through an agent directory's link, nor from the old default.
  const kitNames = kitSkillNames();
  for (const dir of new Set([...LINKS, ...ABOUT_DEFAULTS.skillLinks])) {
    if (dir === SKILLS) continue;
    for (const m of checkCommand.matchAll(new RegExp(`(?<![\\w./-])${escapeRegExp(dir)}/([^/\\s]+)/(\\S+)`, 'g')))
      if (kitNames.includes(m[1]))
        problems.push(
          `fatal: ${CHECK} runs ${m[0]}: kit skills run from the skills directory, ${SKILLS}/${m[1]}/${m[2]} — fix ${CHECK}, then run: ${INSTALL}`
        );
  }
  for (const m of manifestSrc.matchAll(/file:\s*'([^']+)'/g)) {
    if (!exists(m[1]))
      problems.push(`fatal: ${MANIFEST} names ${m[1]}, which does not exist`);
  }

  // 7. Installed kit skills are the kit's, only those of the configured areas, and each agent directory links to them.
  const WHAT = {
    add: 'is missing',
    update: "differs from the kit's",
    remove: 'is no longer shipped by the kit',
    drop: 'is a kit skill whose area is not configured',
  };
  const wanted = skillsFor(settings);
  for (const { path: at, change } of skillChanges(SKILLS, { installedOnly: true, skillLinks: LINKS, skills: wanted }))
    problems.push(
      change in WHAT
        ? `fatal: ${at} ${WHAT[change]} — run: ${INSTALL}`
        : `fatal: ${at}: not a link to ${SKILLS}/${path.posix.basename(at)} — run: ${INSTALL}`
    );

  // Git must not ignore a link: they are committed, so a clone has them.
  const ignored = ignoredLinksProblem(ignoredLinks(LINKS, { skills: wanted }));
  if (ignored) problems.push(`fatal: ${ignored.replace(/^wayfinder: /, '')}`);

  // 8. Date rule.
  dateRule(problems, MANIFEST, 'ABOUT_REVIEWED_AT');

  return {
    problems,
    summary: `${slugs.length} areas, ${skills.length} skills, ${prose.length} prose files of the repository's own`,
  };
}
