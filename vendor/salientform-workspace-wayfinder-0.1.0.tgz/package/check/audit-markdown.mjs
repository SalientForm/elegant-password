/**
 * Parsers for a roadmap (ROADMAP.md), a TODO list (TODO.md) and the Stack summary / Planned migrations sections of an
 * architecture document (ARCHITECTURE.md). Dependency-free ESM so the kit's Audit module (through Vite) and the check
 * scripts (through plain Node) read the same rules. Types: audit-markdown.d.mts.
 * Format: the kit's docs/formats.md. The house conventions, the phase kinds and the
 * TODO areas, are arguments: a repository's workspace config holds them (settings.areas.audit, spec M12.8 §5.3).
 */

export const PHASE_STATUSES = ['not started', 'specified', 'planned', 'in progress'];
export const PHASE_ID = /^M\d+\.\d+$/;
export const MILESTONE_ID = /^M\d+$/;
export const X_ID = /^X\d+$/;

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const FIELD = /^- \*\*([^:*]+):\*\* ?(.*)$/;
const EMPTY = new Set(['', '—', '-']);

function fail(file, line, message) {
  throw new Error(`${file}:${line}: ${message}`);
}

/** The convention list `name` of `options`, or a throw naming the parser: a missing list is never "anything goes". */
function conventionList(options, name, parser) {
  const list = options?.[name];
  if (!Array.isArray(list) || list.length === 0 || !list.every((v) => typeof v === 'string' && v.trim() !== ''))
    throw new TypeError(`${parser}: ${name} must be a non-empty list of strings`);
  return list;
}

/**
 * Whether a TODO `Source:` names a repository path. `todoSources` are the values that do not: an exact value, or a
 * prefix ending in ':' (`feature-audit:` covers `feature-audit:<slug>`). Default ['idea'].
 */
export function isTodoPath(source, todoSources = ['idea']) {
  return !todoSources.some((tag) => (tag.endsWith(':') ? source.startsWith(tag) : source === tag));
}

/** Lines with a 1-based number and whether they sit inside a fenced code block. */
function scan(markdown) {
  let inFence = false;
  return markdown.split('\n').map((text, i) => {
    const fence = text.trimStart().startsWith('```');
    const fenced = inFence || fence;
    if (fence) inFence = !inFence;
    return { text, n: i + 1, fenced };
  });
}

function headerDate(lines, file) {
  for (const l of lines) {
    if (l.text.startsWith('## ')) break;
    const m = /^Reviewed: (.+)$/.exec(l.text);
    if (m) {
      if (!ISO_DATE.test(m[1])) fail(file, l.n, `Reviewed date "${m[1]}" is not YYYY-MM-DD`);
      return m[1];
    }
  }
  return fail(file, 1, 'missing "Reviewed: YYYY-MM-DD" line before the first section');
}

function value(raw) {
  const v = raw.trim();
  return EMPTY.has(v) ? undefined : v;
}

/** Cells of a markdown table row, or null when the line is not a row or is the --- separator. */
function tableCells(text) {
  const t = text.trim();
  if (!t.startsWith('|') || !t.endsWith('|')) return null;
  const cells = t
    .slice(1, -1)
    .split(/(?<!\\)\|/)
    .map((c) => c.trim().replace(/\\\|/g, '|'));
  if (cells.every((c) => /^:?-{3,}:?$/.test(c))) return null;
  return cells;
}

function trimBlank(lines) {
  const out = [...lines];
  while (out.length && out[0].trim() === '') out.shift();
  while (out.length && out[out.length - 1].trim() === '') out.pop();
  return out.join('\n');
}

// ───────────────────────── ROADMAP.md ─────────────────────────

const UI_FIELDS = new Set(['Status', 'Kind', 'Depends on', 'Spec', 'Plan']);

export function parseRoadmap(markdown, conventions) {
  const phaseKinds = conventionList(conventions, 'phaseKinds', 'parseRoadmap');
  const ROADMAP_FILE = conventions.file ?? 'ROADMAP.md';
  const lines = scan(markdown);
  const roadmap = { reviewedAt: headerDate(lines, ROADMAP_FILE), sequence: [], milestones: [], completed: [], nextX: NaN, outside: [] };
  let section = null; // 'sequence' | 'completed' | 'outside' | 'milestone'
  let milestone = null;
  let phase = null;
  let summary = [];
  let body = [];
  let sawCompletedHeader = false;
  let sawOutsideHeader = false;
  let sawOutside = false;

  const closePhase = () => {
    if (!phase) return;
    phase.body = trimBlank(body);
    body = [];
    phase = null;
  };
  const closeMilestone = () => {
    closePhase();
    if (milestone) milestone.summary = trimBlank(summary);
    summary = [];
    milestone = null;
  };

  for (const l of lines) {
    const h2 = !l.fenced && /^## (.+?)\s*$/.exec(l.text);
    const h3 = !l.fenced && /^### (.+?)\s*$/.exec(l.text);
    if (h2) {
      closeMilestone();
      const m = /^(M\d+)\. (.+)$/.exec(h2[1]);
      if (h2[1] === 'Sequence') section = 'sequence';
      else if (h2[1] === 'Completed') section = 'completed';
      else if (h2[1] === 'Outside the roadmap') { section = 'outside'; sawOutside = true; }
      else if (m) {
        section = 'milestone';
        milestone = { id: m[1], title: m[2], summary: '', phases: [] };
        roadmap.milestones.push(milestone);
      } else fail(ROADMAP_FILE, l.n, `unexpected section "${h2[1]}" — expected Sequence, Completed, Outside the roadmap or "M<n>. Title"`);
      continue;
    }
    if (h3) {
      closePhase();
      const m = /^(M\d+\.\d+) (.+)$/.exec(h3[1]);
      if (section !== 'milestone' || !m) fail(ROADMAP_FILE, l.n, `unexpected heading "${h3[1]}" — expected "M<n>.<k> Title" inside a milestone`);
      phase = { id: m[1], milestoneId: milestone.id, title: m[2], dependsOn: [], body: '', line: l.n };
      milestone.phases.push(phase);
      continue;
    }
    if (section === 'sequence') {
      if (l.text.trim() === '') continue;
      const m = /^\d+\. (\S+)$/.exec(l.text.trim());
      if (!m) fail(ROADMAP_FILE, l.n, 'Sequence lines must be "<n>. M<n>.<k>"');
      roadmap.sequence.push(m[1]);
    } else if (section === 'completed') {
      const cells = tableCells(l.text);
      if (!cells) continue;
      if (!sawCompletedHeader) { sawCompletedHeader = true; continue; }
      if (cells.length !== 4) fail(ROADMAP_FILE, l.n, 'Completed rows need 4 cells: ID, Title, Shipped, Spec / plan');
      if (!ISO_DATE.test(cells[2])) fail(ROADMAP_FILE, l.n, `Shipped date "${cells[2]}" is not YYYY-MM-DD`);
      const row = { id: cells[0], title: cells[1], shipped: cells[2] };
      if (value(cells[3])) row.ref = value(cells[3]);
      roadmap.completed.push(row);
    } else if (section === 'outside') {
      const next = /^Next X: (\d+)$/.exec(l.text.trim());
      if (next) { roadmap.nextX = Number(next[1]); continue; }
      const cells = tableCells(l.text);
      if (!cells) continue;
      if (!sawOutsideHeader) { sawOutsideHeader = true; continue; }
      if (cells.length !== 4) fail(ROADMAP_FILE, l.n, 'Outside the roadmap rows need 4 cells: ID, Title, Spec, Plan');
      const row = { id: cells[0], title: cells[1] };
      if (value(cells[2])) row.spec = value(cells[2]);
      if (value(cells[3])) row.plan = value(cells[3]);
      roadmap.outside.push(row);
    } else if (phase) {
      const f = !l.fenced && FIELD.exec(l.text);
      if (f) applyPhaseField(phase, f[1], f[2], l.n, phaseKinds, ROADMAP_FILE);
      if (!f || !UI_FIELDS.has(f[1])) body.push(l.text);
    } else if (milestone) {
      summary.push(l.text);
    }
  }
  closeMilestone();

  if (sawOutside && !Number.isInteger(roadmap.nextX)) fail(ROADMAP_FILE, 1, 'Outside the roadmap is missing its "Next X: <n>" line');
  const problems = validateRoadmap(roadmap);
  if (problems.length) throw new Error(`${ROADMAP_FILE}: ${problems.join('; ')}`);
  for (const m of roadmap.milestones) for (const p of m.phases) delete p.line;
  return roadmap;
}

function applyPhaseField(phase, label, raw, n, phaseKinds, file) {
  const v = value(raw);
  if (label === 'Status') {
    if (!PHASE_STATUSES.includes(v)) fail(file, n, `${phase.id} status "${raw.trim()}" is not one of ${PHASE_STATUSES.join(' | ')}`);
    phase.status = v;
  } else if (label === 'Kind') {
    if (!phaseKinds.includes(v)) fail(file, n, `${phase.id} kind "${raw.trim()}" is not one of ${phaseKinds.join(' | ')}`);
    phase.kind = v;
  } else if (label === 'Goal') phase.goal = v;
  else if (label === 'Not in scope') { if (v) phase.notInScope = v; }
  else if (label === 'Depends on') phase.dependsOn = v ? v.split(',').map((s) => s.trim()).filter(Boolean) : [];
  else if (label === 'Spec') { if (v) phase.spec = v; }
  else if (label === 'Plan') {
    // Several plans, comma-separated, in the order they run: the first is the current one.
    if (v) [phase.plan] = phase.plans = v.split(',').map((s) => s.trim()).filter(Boolean);
  }
}

export function validateRoadmap(roadmap) {
  const problems = [];
  const open = roadmap.milestones.flatMap((m) => m.phases);
  const outside = roadmap.outside ?? [];
  const seen = new Set();
  for (const id of [...roadmap.milestones.map((m) => m.id), ...open.map((p) => p.id), ...roadmap.completed.map((c) => c.id), ...outside.map((o) => o.id)]) {
    if (seen.has(id)) problems.push(`duplicate id ${id}`);
    seen.add(id);
  }
  for (const c of roadmap.completed) if (!PHASE_ID.test(c.id)) problems.push(`Completed id "${c.id}" is not M<n>.<k>`);
  for (const o of outside) {
    if (!X_ID.test(o.id)) problems.push(`Outside the roadmap id "${o.id}" is not X<n>`);
    if (!o.title) problems.push(`${o.id} has no title`);
    if (!o.spec && !o.plan) problems.push(`${o.id} names neither a spec or plan`);
    if (Number.isInteger(roadmap.nextX) && X_ID.test(o.id) && Number(o.id.slice(1)) >= roadmap.nextX) problems.push(`Next X ${roadmap.nextX} must be greater than ${o.id}`);
  }
  for (const m of roadmap.milestones) {
    if (m.phases.length === 0) problems.push(`${m.id} has no open phase — add one or delete the milestone`);
    if (!m.summary) problems.push(`${m.id} has no summary paragraph`);
    for (const p of m.phases) {
      if (!p.id.startsWith(`${m.id}.`)) problems.push(`${p.id} sits under ${m.id} but its id does not start with ${m.id}.`);
      if (!p.status) problems.push(`${p.id} is missing Status`);
      if (!p.kind) problems.push(`${p.id} is missing Kind`);
      if (!p.goal) problems.push(`${p.id} is missing Goal`);
      if (p.plans && new Set(p.plans).size !== p.plans.length) problems.push(`${p.id} names a plan twice`);
      if (p.status === 'not started' && (p.spec || p.plan)) problems.push(`${p.id} is not started but names a spec or plan`);
      if (p.status === 'specified' && (!p.spec || p.plan)) problems.push(`${p.id} is specified: needs a Spec and no Plan`);
      if ((p.status === 'planned' || p.status === 'in progress') && (!p.spec || !p.plan)) problems.push(`${p.id} is ${p.status}: needs both Spec and Plan`);
      for (const dep of p.dependsOn) if (PHASE_ID.test(dep) && !seen.has(dep)) problems.push(`${p.id} depends on unknown phase ${dep}`);
    }
  }
  const openIds = new Set(open.map((p) => p.id));
  const inSequence = new Set();
  for (const id of roadmap.sequence) {
    if (!openIds.has(id)) problems.push(`${id} is in Sequence but is not an open phase`);
    if (inSequence.has(id)) problems.push(`${id} appears twice in Sequence`);
    inSequence.add(id);
  }
  for (const id of openIds) if (!inSequence.has(id)) problems.push(`${id} is open but missing from Sequence`);
  return problems;
}

// ───────────────────────── TODO.md ─────────────────────────

export function parseTodos(markdown, conventions) {
  const todoAreas = conventionList(conventions, 'todoAreas', 'parseTodos');
  const TODO_FILE = conventions.file ?? 'TODO.md';
  const lines = scan(markdown);
  const list = { reviewedAt: headerDate(lines, TODO_FILE), nextId: NaN, todos: [] };
  let todo = null;
  let body = [];
  const close = () => {
    if (!todo) return;
    todo.body = trimBlank(body);
    body = [];
    todo = null;
  };
  for (const l of lines) {
    const h2 = !l.fenced && /^## (.+?)\s*$/.exec(l.text);
    if (h2) {
      close();
      const m = /^#(\d+) (.+)$/.exec(h2[1]);
      if (!m) fail(TODO_FILE, l.n, `heading "${h2[1]}" is not "#<id> Title"`);
      todo = { id: Number(m[1]), title: m[2], body: '' };
      list.todos.push(todo);
      continue;
    }
    if (!todo) {
      const next = /^Next ID: (\d+)$/.exec(l.text);
      if (next) list.nextId = Number(next[1]);
      continue;
    }
    const f = !l.fenced && FIELD.exec(l.text);
    if (f && f[1] === 'Area') {
      if (!todoAreas.includes(f[2].trim())) fail(TODO_FILE, l.n, `#${todo.id} area "${f[2].trim()}" is not one of ${todoAreas.join(' | ')}`);
      todo.area = f[2].trim();
    } else if (f && f[1] === 'Source') todo.source = f[2].trim();
    else if (f && f[1] === 'Added') {
      if (!ISO_DATE.test(f[2].trim())) fail(TODO_FILE, l.n, `#${todo.id} Added "${f[2].trim()}" is not YYYY-MM-DD`);
      todo.added = f[2].trim();
    } else body.push(l.text);
  }
  close();
  const problems = validateTodos(list);
  if (problems.length) throw new Error(`${TODO_FILE}: ${problems.join('; ')}`);
  return list;
}

export function validateTodos(list) {
  const problems = [];
  if (!Number.isInteger(list.nextId)) problems.push('missing "Next ID: <n>" line');
  const seen = new Set();
  for (const t of list.todos) {
    if (seen.has(t.id)) problems.push(`duplicate id #${t.id}`);
    seen.add(t.id);
    for (const field of ['area', 'source', 'added']) {
      if (!t[field]) problems.push(`#${t.id} is missing ${field[0].toUpperCase()}${field.slice(1)}`);
    }
    if (Number.isInteger(list.nextId) && t.id >= list.nextId) problems.push(`Next ID ${list.nextId} must be greater than #${t.id}`);
  }
  return problems;
}

// ───────────────────────── ARCHITECTURE.md ─────────────────────────

/** Lines of the `## <title>` section (heading excluded), or null. A leading "<n>. " on the heading is allowed. */
function sectionLines(lines, title) {
  const start = lines.findIndex((l) => !l.fenced && new RegExp(`^## (?:\\d+\\. )?${title}\\s*$`).test(l.text));
  if (start === -1) return null;
  const rest = lines.slice(start + 1);
  const end = rest.findIndex((l) => !l.fenced && l.text.startsWith('## '));
  return end === -1 ? rest : rest.slice(0, end);
}

export function parseStackSummary(markdown, { file: ARCH_FILE = 'ARCHITECTURE.md' } = {}) {
  const lines = scan(markdown);
  const summary = { reviewedAt: headerDate(lines, ARCH_FILE), areas: [], items: [] };
  const section = sectionLines(lines, 'Stack summary');
  if (!section) fail(ARCH_FILE, 1, 'missing "## Stack summary" section');
  let area = null;
  let sawHeader = false;
  for (const l of section) {
    const h3 = !l.fenced && /^### (.+?)\s*$/.exec(l.text);
    if (h3) {
      area = h3[1];
      sawHeader = false;
      summary.areas.push(area);
      continue;
    }
    const cells = tableCells(l.text);
    if (!cells) continue;
    if (!area) fail(ARCH_FILE, l.n, 'table row before the first "### <Area>" heading');
    if (!sawHeader) { sawHeader = true; continue; }
    if (cells.length !== 4) fail(ARCH_FILE, l.n, 'Stack summary rows need 4 cells: Item, Status, Note, Ref');
    const [item, status, note, ref] = cells;
    if (status !== 'current' && status !== 'planned') fail(ARCH_FILE, l.n, `status "${status}" is not current | planned`);
    if (!item) fail(ARCH_FILE, l.n, 'empty Item cell');
    const row = { area, item, planned: status === 'planned' };
    if (value(note)) row.note = value(note);
    if (value(ref)) row.ref = value(ref);
    summary.items.push(row);
  }
  if (summary.items.length === 0) fail(ARCH_FILE, 1, 'Stack summary has no rows');
  return summary;
}

export function parsePlannedMigrations(markdown, { file: ARCH_FILE = 'ARCHITECTURE.md' } = {}) {
  const section = sectionLines(scan(markdown), 'Planned migrations');
  if (!section) fail(ARCH_FILE, 1, 'missing "## Planned migrations" section');
  const ids = [];
  for (const l of section) {
    if (!l.text.startsWith('- ')) continue;
    const m = /^- \*\*(M\d+\.\d+) /.exec(l.text);
    if (!m) fail(ARCH_FILE, l.n, 'Planned migrations bullets must start "- **M<n>.<k> Title**"');
    ids.push(m[1]);
  }
  return ids;
}
