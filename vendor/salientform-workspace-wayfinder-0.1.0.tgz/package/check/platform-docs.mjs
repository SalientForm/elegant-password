/**
 * The Platform Docs drift check (spec M12.5 §5.5): the pages in the area's directory, built by the page builder the
 * module shares (platform-pages.mjs), and the area's reviewed date, all from the workspace config. Plain node; the
 * product's check-platform-docs.mjs is a wrapper that loads the settings and supplies the terms to look for.
 *
 * Fails when:
 *  - settings.areas[slug].directory does not exist or holds no *.md file
 *  - a page has no front-matter `title:`, numeric `order:` or `summary:`
 *  - two pages resolve to the same slug (numeric prefix and .md stripped)
 *  - settings.areas[slug].reviewedAt fails the date rule
 *
 * Reports (does not fail) each of `mentions` that no page body mentions, case-insensitively.
 */
import { readdirSync } from 'node:fs';
import path from 'node:path';
import { exists, modifiedDateRule, readRepo, repoRoot } from './index.mjs';
import { platformPages } from './platform-pages.mjs';

/**
 * Runs the Platform Docs rules over `settings` (the workspace config's data half); `slug` is the area's key in
 * `settings.areas`. `mentions` are terms the product expects some page to mention (a rules file's navLabels: the navigation's labels);
 * the ones no page mentions are returned as `unmentioned`, not failed. Returns { problems, unmentioned, summary }.
 */
export function checkPlatformDocs(settings, { slug = 'platform-docs', mentions = [] } = {}) {
  const area = settings.areas[slug];
  if (typeof area?.directory !== 'string')
    throw new Error(`wayfinder: settings.areas.${slug} has no directory`);
  const DIR = area.directory;
  const problems = [];

  const files = exists(DIR)
    ? readdirSync(path.join(repoRoot, DIR))
        .filter((f) => f.endsWith('.md'))
        .sort()
    : [];
  if (!exists(DIR)) problems.push(`fatal: ${DIR} (settings.areas.${slug}.directory) does not exist`);
  else if (files.length === 0) problems.push(`fatal: ${DIR} (settings.areas.${slug}.directory) holds no *.md page`);

  const { pages, problems: pageProblems } = platformPages(
    files.map((f) => ({ path: `${DIR}/${f}`, markdown: readRepo(`${DIR}/${f}`) }))
  );
  for (const problem of pageProblems) problems.push(`fatal: ${problem}`);

  modifiedDateRule(problems, `settings.areas.${slug}.reviewedAt`, area.reviewedAt);

  const bodies = pages.map((p) => p.body.toLowerCase()).join('\n');
  const unmentioned = mentions.filter((term) => !bodies.includes(term.toLowerCase()));

  return { problems, unmentioned, summary: `${settings.product}: ${pages.length} pages` };
}
