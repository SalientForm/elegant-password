import type { RuleContext, WorkspaceRules } from './index.mjs';

/** What one check returns to the runner. */
export interface CheckOutcome {
  problems: string[];
  /** Printed when there is no problem. */
  ok: string;
  /** Printed first, never failing (unmentioned labels). */
  notes?: string[];
}

/** The checks `runCheck` runs, by name. */
export const CHECKS: Record<
  'about' | 'audit' | 'feature-audit' | 'features' | 'api' | 'platform-docs',
  (settings: import('../src/settings').WorkspaceSettings, rules: WorkspaceRules, ctx: RuleContext) => CheckOutcome
>;

/** Runs a check in the repository the process runs in, prints its outcome and exits 1 on a problem. */
export function runCheck(name: keyof typeof CHECKS): Promise<void>;
