export interface FrontMatter {
  /** The block's top-level keys; each caller narrows the values it reads (YAML: strings, numbers, lists, mappings). */
  data: Record<string, unknown>;
  body: string;
}

/**
 * `{ data, body }` of `markdown`: a leading `---` block parsed as YAML (core schema, so a date stays a string) and
 * what follows it. No block: `data` is empty and `body` the whole input. A block that is not valid YAML or not a
 * mapping throws; `file`, when given, names it in the message.
 */
export function parseFrontMatter(markdown: string, file?: string): FrontMatter;

/**
 * The body of `markdown` for rendering: without its front matter when the block parses, as written when it does not.
 */
export function stripFrontMatter(markdown: string): string;
