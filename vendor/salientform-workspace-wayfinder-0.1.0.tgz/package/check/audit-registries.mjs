/**
 * The Audit area's registries (spec M12.9 §5.3, spec M12.11 §6.15): the feature audit and the product route mirror read
 * from JSON, and the spec ledger and the documents built from markdown (each spec's and plan's front matter, one review
 * file per reviewed document, and the reviews folder's index), each validated row by row. Plain ESM (the `yaml` package
 * is the only dependency, through the front-matter parser) so the Audit module (through Vite) and its checks (through
 * plain node) judge a registry the same way. Rules that need the file system or another registry belong to the checks
 * (audit-ledger.mjs, feature-audit.mjs). Types: audit-registries.d.mts.
 */
import { parseFrontMatter } from './front-matter.mjs';


export const DOC_VERDICTS = ['current', 'partially-stale', 'stale', 'superseded', 'done', 'conflicting', 'wrong'];
export const SPEC_STATES = ['draft', 'under-review', 'blocked', 'conflicting', 'implemented', 'superseded'];
export const CLOSED_SPEC_STATES = ['implemented', 'superseded'];
export const ACTIVE_SPEC_STATES = ['draft', 'under-review', 'blocked'];
export const FINDING_KINDS = ['dead-code', 'unreachable', 'todo', 'recommendation'];
export const FINDING_STATUSES = ['open', 'known', 'planned'];
export const FEATURE_AUDIT_SOURCE = 'feature-audit:';

const SPEC_KINDS = ['spec', 'plan'];
const KEBAB = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

const isObject = (value) => typeof value === 'object' && value !== null && !Array.isArray(value);
const quote = (value) => JSON.stringify(value);

/**
 * Field rules, by key: `string` (non-empty), `text` (any string), `strings` (a list of non-empty strings), or a list
 * of allowed values. A key ending in '?' is optional.
 */
const DOC_KIND = { id: 'string', label: 'string' };
const REVIEW_ROW = {
  path: 'string',
  kind: 'string',
  lastModified: 'string',
  verdict: DOC_VERDICTS,
  'staleContent?': 'text',
  'futureContent?': 'text',
  'tracked?': 'strings',
  recommendation: 'string',
  'ref?': 'text',
};
const SPEC_ROW = {
  path: 'string',
  title: 'string',
  kind: SPEC_KINDS,
  'milestone?': 'string',
  state: SPEC_STATES,
  summary: 'text',
  'blockedOn?': 'text',
  'followUps?': 'strings',
  'evidence?': 'text',
  'specPath?': 'string',
};
const DOCUMENT = { id: 'string', title: 'string', path: 'string', description: 'text', 'anchor?': 'string' };
const GROUP = { id: 'string', title: 'string', blurb: 'text' };
const FINDING = {
  slug: 'string',
  title: 'string',
  kind: FINDING_KINDS,
  group: 'string',
  status: FINDING_STATUSES,
  summary: 'text',
  files: 'strings',
  action: 'string',
  'size?': 'text',
  'ref?': 'text',
  'page?': 'string',
};

/** A reader's problem list, each problem prefixed with the file (when there is one). */
function problemList(file) {
  const problems = [];
  return { problems, add: (problem) => problems.push(file ? `${file}: ${problem}` : problem) };
}

/** One field against its rule; returns whether it passed. */
function fieldProblem(row, key, rule, at, add) {
  const value = row[key];
  if (Array.isArray(rule)) {
    if (!rule.includes(value)) add(`${at} ${key} ${quote(value)} is not one of ${rule.join(', ')}`);
    else return true;
  } else if (rule === 'strings') {
    if (!Array.isArray(value) || !value.every((v) => typeof v === 'string' && v !== '')) add(`${at} ${key} is not a list of non-empty strings`);
    else return true;
  } else if (typeof value !== 'string') add(`${at} ${key} is not a string`);
  else if (rule === 'string' && value === '') add(`${at} ${key} is empty`);
  else return true;
  return false;
}

/**
 * The rows of `name`: each an object whose fields follow `fields`. Returns the rows without a problem. `rowAt` names a
 * row in a problem (default `name[i]`); a reader over files passes each row's own file.
 */
function rows(json, name, fields, add, rowAt = (row, i) => `${name}[${i}]`) {
  const list = json[name];
  if (!Array.isArray(list)) {
    add(`${name} is not a list`);
    return [];
  }
  const keys = Object.keys(fields).map((k) => k.replace(/\?$/, ''));
  return list.filter((row, i) => {
    const at = rowAt(row, i);
    if (!isObject(row)) {
      add(`${at} is not an object`);
      return false;
    }
    let ok = true;
    for (const [field, rule] of Object.entries(fields)) {
      const key = field.replace(/\?$/, '');
      if (field.endsWith('?') && row[key] === undefined) continue;
      if (!field.endsWith('?') && row[key] === undefined) {
        add(`${at} has no ${key}`);
        ok = false;
      } else if (!fieldProblem(row, key, rule, at, add)) ok = false;
    }
    for (const key of Object.keys(row))
      if (!keys.includes(key)) {
        add(`${at} has an unknown key ${quote(key)}`);
        ok = false;
      }
    return ok;
  });
}

/** The rows of `list` whose `key` repeats an earlier row's; reports each repeat. */
function unique(list, name, key, add) {
  const seen = new Set();
  return list.filter((row) => {
    if (seen.has(row[key])) {
      add(`${name} ${key} ${quote(row[key])} is listed twice`);
      return false;
    }
    seen.add(row[key]);
    return true;
  });
}

function reviewedAt(json, add) {
  const value = json.reviewedAt;
  if (typeof value !== 'string' || !ISO_DATE.test(value) || Number.isNaN(Date.parse(value)))
    add(`reviewedAt ${quote(value)} is not an ISO date (YYYY-MM-DD)`);
  return typeof value === 'string' ? value : '';
}

/** The top level: an object, or a problem and an empty object. */
function topLevel(json, what, add) {
  if (isObject(json)) return json;
  add(`is not a JSON object with ${what}`);
  return {};
}

/** The reviews and spec rows of a ledger: each row valid, each review's kind one of `kinds`, none repeated. */
function ledgerRows(top, kinds, add, rowAt) {
  const kindIds = new Set(kinds.map((k) => k.id));
  const docReviews = unique(
    rows(top, 'docReviews', REVIEW_ROW, add, rowAt).filter((r) => {
      if (kindIds.has(r.kind)) return true;
      // A review file names itself (rowAt); a JSON row, by its registry key.
      const at = rowAt ? `${rowAt(r)}:` : `docReviews ${r.path}`;
      add(`${at} kind ${quote(r.kind)} is not one of the${rowAt ? " index's" : ''} kinds (${[...kindIds].join(', ')})`);
      return false;
    }),
    'docReviews',
    'path',
    add,
  );
  const specStatus = unique(rows(top, 'specStatus', SPEC_ROW, add, rowAt), 'specStatus', 'path', add);
  return { docReviews, specStatus };
}

/** The spec ledger: reviewedAt, kinds, docReviews and specStatus. */
export function readLedger(json, file) {
  const { problems, add } = problemList(file);
  const top = topLevel(json, 'reviewedAt, kinds, docReviews and specStatus', add);
  const date = reviewedAt(top, add);
  const kinds = unique(rows(top, 'kinds', DOC_KIND, add), 'kinds', 'id', add);
  const { docReviews, specStatus } = ledgerRows(top, kinds, add);
  for (const key of Object.keys(top))
    if (!['reviewedAt', 'kinds', 'docReviews', 'specStatus'].includes(key)) add(`unknown key ${quote(key)}`);
  return { value: { reviewedAt: date, kinds, docReviews, specStatus }, problems };
}

/** The documents registry: reviewedAt and documents. */
export function readDocuments(json, file) {
  const { problems, add } = problemList(file);
  const top = topLevel(json, 'reviewedAt and documents', add);
  const date = reviewedAt(top, add);
  const documents = unique(
    rows(top, 'documents', DOCUMENT, add).filter((d) => {
      if (KEBAB.test(d.id)) return true;
      add(`documents id ${quote(d.id)} is not lowercase kebab`);
      return false;
    }),
    'documents',
    'id',
    add,
  );
  for (const key of Object.keys(top)) if (!['reviewedAt', 'documents'].includes(key)) add(`unknown key ${quote(key)}`);
  return { value: { reviewedAt: date, documents }, problems };
}

/** The feature audit: reviewedAt, groups and findings (the inventory beside them moved to the feature catalogue, M13.1). */
export function readFeatureAudit(json, file) {
  const { problems, add } = problemList(file);
  const top = topLevel(json, 'reviewedAt, groups and findings', add);
  const date = reviewedAt(top, add);
  const groups = unique(rows(top, 'groups', GROUP, add), 'groups', 'id', add);
  const groupIds = new Set(groups.map((g) => g.id));
  const findings = unique(
    rows(top, 'findings', FINDING, add).filter((f) => {
      if (groupIds.has(f.group)) return true;
      add(`findings ${f.slug} group ${quote(f.group)} is not one of the groups (${[...groupIds].join(', ')})`);
      return false;
    }),
    'findings',
    'slug',
    add,
  );
  for (const key of Object.keys(top)) if (!['reviewedAt', 'groups', 'findings'].includes(key)) add(`unknown key ${quote(key)}`);
  return { value: { reviewedAt: date, groups, findings }, problems };
}

/** The product route mirror: routes and the optional sidebar, each a list of paths starting with '/'. */
export function readProductRoutes(json, file) {
  const { problems, add } = problemList(file);
  const top = topLevel(json, 'routes', add);
  const paths = (key, optional) => {
    const list = top[key];
    if (list === undefined && optional) return undefined;
    if (!Array.isArray(list)) {
      add(`${key} is not a list`);
      return [];
    }
    return list.filter((p, i) => {
      if (typeof p === 'string' && p.startsWith('/')) return true;
      add(`${key}[${i}] ${quote(p)} is not a path starting with /`);
      return false;
    });
  };
  const routes = paths('routes', false);
  const sidebar = paths('sidebar', true);
  for (const key of Object.keys(top)) if (!['routes', 'sidebar'].includes(key)) add(`unknown key ${quote(key)}`);
  return { value: { routes, ...(sidebar === undefined ? {} : { sidebar }) }, problems };
}

// ── The ledger from markdown (spec M12.11 §6.15) ──────────────────────────────────────────────────────────────────

/** The folder's index: its date, the All markdowns sections, the Documentation list. */
export const REVIEWS_INDEX = 'index.md';
/** A directory review's file name: `<reviews>/<dir>/_directory.review.md` for the reviewed `<dir>/`. */
export const DIRECTORY_REVIEW = '_directory.review.md';

/** The review file of a reviewed `path`: `docs/x.md` → `<reviews>/docs/x.review.md`; `docs/x/` → `<reviews>/docs/x/_directory.review.md`. */
export function reviewFilePath(reviews, path) {
  if (path.endsWith('/')) return `${reviews}/${path}${DIRECTORY_REVIEW}`;
  return `${reviews}/${path.replace(/\.md$/, '')}.review.md`;
}

/** The text of `markdown`'s first `# ` heading outside fenced code, or undefined. */
export function firstHeading(markdown) {
  let fence = null;
  for (const line of markdown.split(/\r?\n/)) {
    const opener = /^\s*(`{3,}|~{3,})/.exec(line);
    if (fence) {
      if (opener && opener[1][0] === fence[0] && opener[1].length >= fence.length) fence = null;
      continue;
    }
    if (opener) {
      fence = opener[1];
      continue;
    }
    const heading = /^#[ \t]+(.+?)[ \t]*#*[ \t]*$/.exec(line);
    if (heading) return heading[1].trim();
  }
  return undefined;
}

const MILESTONE_LINE = /^\*\*Milestone:\*\* (.+)$/gm;

/** Each `**Milestone:**` id before `body`'s first `## ` heading (the rule that there is exactly one is the check's). */
export function milestoneIds(body) {
  return [...body.split(/^## /m)[0].matchAll(MILESTONE_LINE)].map((m) => m[1].trim());
}

const SPEC_FRONT_KEYS = ['state', 'summary', 'followUps', 'evidence', 'spec', 'blockedOn'];
const REVIEW_FRONT_KEYS = ['path', 'kind', 'lastModified', 'verdict', 'tracked', 'ref'];
const INDEX_KEYS = ['reviewedAt', 'kinds', 'documents'];
const REVIEW_SECTIONS = { 'Stale content': 'staleContent', 'Future content': 'futureContent', Recommendation: 'recommendation' };

/**
 * The order the ledger's rows are read in: by file name (a date prefix keeps a spec beside its plan, in date order),
 * then by path. The order has no field of its own: a document is its own row, and the folder carries no order.
 */
const compareRows = (a, b) => {
  const nameA = a.slice(a.lastIndexOf('/') + 1);
  const nameB = b.slice(b.lastIndexOf('/') + 1);
  return nameA < nameB ? -1 : nameA > nameB ? 1 : a < b ? -1 : 1;
};

/** A prose value as it reads on a page: a folded scalar's trailing newline dropped. */
const prose = (value) => (typeof value === 'string' ? value.trim() : value);

/** `data` with only the keys that are set: an optional field stays absent rather than undefined. */
const defined = (data) => Object.fromEntries(Object.entries(data).filter(([, value]) => value !== undefined));

/** `markdown`'s front matter and body, or a problem and null. */
function frontMatterOf(markdown, file, addProblem) {
  try {
    return parseFrontMatter(markdown, file);
  } catch (error) {
    addProblem(error.message);
    return null;
  }
}

/** A problem for each key of `data` that is not in `allowed`, naming `file`. */
function unknownKeys(data, allowed, file, addProblem) {
  for (const key of Object.keys(data)) if (!allowed.includes(key)) addProblem(`${file}: unknown front-matter key ${quote(key)}`);
}

/** The `## Stale content`, `## Future content` and `## Recommendation` sections of a review's body. */
function reviewSections(body, file, addProblem) {
  const sections = {};
  let key = null;
  let lines = [];
  const flush = () => {
    if (key === null) return;
    const text = lines.join('\n').replace(/\s*\n\s*/g, ' ').trim();
    if (text === '') addProblem(`${file}: section ${key} is empty`);
    else sections[key] = text;
  };
  for (const line of body.split(/\r?\n/)) {
    const heading = /^## (.+?)\s*$/.exec(line);
    if (heading) {
      flush();
      key = REVIEW_SECTIONS[heading[1]] ?? null;
      if (key === null) addProblem(`${file}: unknown section "## ${heading[1]}"`);
      else if (sections[key] !== undefined) addProblem(`${file}: section "## ${heading[1]}" is repeated`);
      lines = [];
    } else if (key === null && line.trim() !== '') addProblem(`${file}: text before the first section`);
    else lines.push(line);
  }
  flush();
  return sections;
}

/**
 * The spec ledger and the documents, built from markdown: `specDocs` ({ path, markdown }: every markdown file under
 * `specDirs`, archived ones among them), `reviewDocs` (the review files under `reviews`, without the index) and
 * `indexMarkdown` (`<reviews>/index.md`). A document directly in a spec directory with no `state` is left to the check
 * (`state` is required there; the document simply has no row here); one in a subdirectory without front matter is not
 * a row at all. Returns { ledger, documents, problems }; `documents` is undefined when the index has none.
 */
export function readAuditMarkdown({ specDirs, reviews, specDocs, reviewDocs, indexMarkdown }) {
  const problems = [];
  const addProblem = (problem) => problems.push(problem);
  const indexFile = `${reviews}/${REVIEWS_INDEX}`;

  const specStatus = [];
  for (const { path: docPath, markdown } of [...specDocs].sort((a, b) => compareRows(a.path, b.path))) {
    const front = frontMatterOf(markdown, docPath, addProblem);
    if (!front || front.data.state === undefined) continue;
    unknownKeys(front.data, SPEC_FRONT_KEYS, docPath, addProblem);
    const directory = specDirs.find((dir) => docPath === dir || docPath.startsWith(`${dir}/`));
    const title = firstHeading(front.body);
    if (title === undefined) addProblem(`${docPath}: no "# " heading to title it`);
    const [milestone] = milestoneIds(front.body);
    specStatus.push(
      defined({
        path: docPath,
        title: title ?? docPath,
        kind: specDirs.indexOf(directory) === 0 ? 'spec' : 'plan',
        milestone,
        state: front.data.state,
        summary: prose(front.data.summary),
        blockedOn: prose(front.data.blockedOn),
        followUps: front.data.followUps,
        evidence: prose(front.data.evidence),
        specPath: front.data.spec,
      }),
    );
  }

  const docReviews = [];
  for (const { path: file, markdown } of reviewDocs) {
    const front = frontMatterOf(markdown, file, addProblem);
    if (!front) continue;
    const { path: reviewed } = front.data;
    if (typeof reviewed !== 'string' || reviewed === '') {
      addProblem(`${file}: no front-matter path`);
      continue;
    }
    const expected = reviewFilePath(reviews, reviewed);
    if (expected !== file) addProblem(`${file}: path ${quote(reviewed)} does not match its file name (expected ${expected})`);
    unknownKeys(front.data, REVIEW_FRONT_KEYS, file, addProblem);
    docReviews.push(
      defined({
        path: reviewed,
        kind: front.data.kind,
        lastModified: front.data.lastModified,
        verdict: front.data.verdict,
        tracked: front.data.tracked,
        ref: prose(front.data.ref),
        ...reviewSections(front.body, file, addProblem),
      }),
    );
  }
  docReviews.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));

  const index = frontMatterOf(indexMarkdown, indexFile, addProblem) ?? { data: {}, body: '' };
  unknownKeys(index.data, INDEX_KEYS, indexFile, addProblem);
  const addIndex = (problem) => addProblem(`${indexFile}: ${problem}`);
  const date = reviewedAt(index.data, addIndex);
  const kinds = unique(rows(index.data, 'kinds', DOC_KIND, addIndex), 'kinds', 'id', addIndex);
  const fileOf = (row) => (row.title === undefined ? reviewFilePath(reviews, row.path) : row.path);
  const built = ledgerRows({ docReviews, specStatus }, kinds, addProblem, fileOf);
  const hasDocuments = index.data.documents !== undefined;
  const documents = hasDocuments ? readDocumentsList(index.data.documents, date, addIndex) : undefined;
  return { ledger: { reviewedAt: date, kinds, ...built }, documents, problems };
}

/** The index's documents, validated as readDocuments validates them. */
function readDocumentsList(list, date, addProblem) {
  const documents = unique(
    rows({ documents: list }, 'documents', DOCUMENT, addProblem).filter((d) => {
      if (KEBAB.test(d.id)) return true;
      addProblem(`documents id ${quote(d.id)} is not lowercase kebab`);
      return false;
    }),
    'documents',
    'id',
    addProblem,
  );
  return { reviewedAt: date, documents };
}
