/** The workspace's ports and its links to the repository's other apps. */

import type { WorkspaceLink, WorkspacePorts } from '../src/settings';

export type { WorkspaceLink, WorkspacePorts };

/** Ports a framework or tool picks by default. */
export const FRAMEWORK_PORTS: readonly number[];
/** The problems of a `{ dev, preview }` pair; `at` names the setting. */
export function portsProblems(ports: unknown, at?: string): string[];
/** The problems of `settings.links`, given the workspace's own ports. */
export function linksProblems(links: unknown, ports: unknown): string[];
/** Where a link points: the page's host on its port in dev or at base '/', else its path. */
export function linkHref(
  link: Pick<WorkspaceLink, 'port' | 'path'>,
  context: { dev: boolean; base: string; location: Pick<Location, 'protocol' | 'hostname'> }
): string;
