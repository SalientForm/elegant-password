/**
 * Platform Docs pages from their files (spec M12.5 §5.2): dependency-free ESM so the Platform Docs module (through
 * Vite) and its check (through plain node) build and validate pages the same way. Types: platform-pages.d.mts.
 */
import { parseFrontMatter } from './front-matter.mjs';

/** `docs/platform/10-getting-started.md` (or `10-getting-started.md`) → `getting-started`: the page's URL segment. */
export function platformSlug(path) {
  return path
    .replace(/^.*\//, '')
    .replace(/^\d+-/, '')
    .replace(/\.md$/, '');
}

/**
 * Pages built from `files` ({ path, markdown }), sorted by `order` then path, and every problem with them: a page
 * with no `title`, numeric `order` or `summary`, or two pages with one slug. A page with a problem is still built,
 * titled by its slug and ordered last, so a caller can report every problem at once.
 */
export function platformPages(files) {
  const problems = [];
  const bySlug = new Map();
  const pages = files.map(({ path, markdown }) => {
    let parsed;
    try {
      parsed = parseFrontMatter(markdown, path);
    } catch (error) {
      problems.push(error.message);
      parsed = { data: {}, body: markdown };
    }
    const { data, body } = parsed;
    const slug = platformSlug(path);
    for (const key of Object.keys(data))
      if (typeof data[key] === 'object' && data[key] !== null)
        problems.push(`${path} front-matter ${key}: parsed to a mapping or list: quote it: '{…}'`);
    if (typeof data.title !== 'string' || !data.title) problems.push(`${path} has no front-matter title:`);
    if (typeof data.order !== 'number') problems.push(`${path} has no numeric front-matter order:`);
    if (typeof data.summary !== 'string' || !data.summary) problems.push(`${path} has no front-matter summary:`);
    if (bySlug.has(slug)) problems.push(`${path} and ${bySlug.get(slug)} both resolve to slug "${slug}"`);
    else bySlug.set(slug, path);
    return {
      slug,
      title: typeof data.title === 'string' && data.title ? data.title : slug,
      order: typeof data.order === 'number' ? data.order : Number.MAX_SAFE_INTEGER,
      summary: typeof data.summary === 'string' ? data.summary : '',
      path,
      body,
    };
  });
  pages.sort((a, b) => a.order - b.order || (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  return { pages, problems };
}
