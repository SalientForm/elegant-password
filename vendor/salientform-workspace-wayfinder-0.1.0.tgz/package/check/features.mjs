/**
 * The feature catalogue from its files (spec M13 §5.1, plan M13.1 § The feature file): dependency-free ESM so the
 * Features module (through Vite) and its check (through plain node) build features, match globs and find gaps the
 * same way. Types: features.d.mts.
 */
import { parseFrontMatter } from './front-matter.mjs';

/** A feature's status: the first three are the retired inventory's; `planned` is roadmap work with no route yet. */
export const FEATURE_STATUSES = ['live', 'partial', 'parked', 'planned'];
/** Ids the Features area's static routes take (`/<slug>/gaps`, M13.2's `/<slug>/tests`). */
export const RESERVED_FEATURE_IDS = ['gaps', 'tests'];
/** Every front-matter key a feature file may carry. */
export const FEATURE_KEYS = ['title', 'status', 'summary', 'routes', 'sources', 'tests', 'platformDoc', 'specs', 'roadmap'];
const LIST_KEYS = ['routes', 'sources', 'tests', 'specs', 'roadmap'];
const KEBAB = /^[a-z0-9]+(-[a-z0-9]+)*$/;

/** A file's front matter; a block that does not parse is `problems`' line and the file reads as having none. */
function readFrontMatter(markdown, path, problems) {
  try {
    return parseFrontMatter(markdown, path);
  } catch (error) {
    problems.push(error.message);
    return { data: {}, body: markdown };
  }
}

/** `docs/features/sign-in.md` → `sign-in`: the feature's id and URL segment. */
export function featureId(path) {
  return path.replace(/^.*\//, '').replace(/\.md$/, '');
}

/**
 * Features built from `files` ({ path, markdown }), sorted by title, and every problem a file alone shows: a missing
 * `title`, `status` or `summary`, no `sources` unless `planned`, an unknown status or key, a list key not written
 * `[…]`, a list item that is not a string (quote a `{…}` glob), an id that is not lowercase kebab or is reserved, and
 * two features owning one route. A feature with a problem is still built, so a caller can report every problem at once.
 */
export function featureRecords(files) {
  // A list item YAML read as a mapping (an unquoted `{a,b}` glob) is reported by `list`, below.
  const problems = [];
  const routeOwner = new Map();
  const features = files.map(({ path, markdown }) => {
    const { data, body } = readFrontMatter(markdown, path, problems);
    const id = featureId(path);
    const fail = (problem) => problems.push(`${path}: ${problem}`);
    if (!KEBAB.test(id)) fail(`id "${id}" is not lowercase kebab-case`);
    else if (RESERVED_FEATURE_IDS.includes(id)) fail(`id "${id}" is reserved for the area's own page`);
    for (const key of Object.keys(data)) if (!FEATURE_KEYS.includes(key)) fail(`unknown front-matter key ${key}:`);
    const text = (key) => (typeof data[key] === 'string' && data[key] ? data[key] : undefined);
    for (const key of ['title', 'summary']) if (!text(key)) fail(`no front-matter ${key}:`);
    const status = FEATURE_STATUSES.includes(data.status) ? data.status : undefined;
    if (data.status === undefined) fail('no front-matter status:');
    else if (!status) fail(`status "${data.status}" is not one of ${FEATURE_STATUSES.join(', ')}`);
    const list = (key) => {
      const value = data[key];
      if (value === undefined) return [];
      if (!Array.isArray(value)) {
        fail(`${key}: must be a list, written [a, b]`);
        return [];
      }
      return value.filter((item) => {
        if (typeof item === 'string') return true;
        fail(`${key}: an item is not a string (${JSON.stringify(item)}): quote it: '{…}'`);
        return false;
      });
    };
    const [routes, sources, tests, specs, roadmap] = LIST_KEYS.map(list);
    // A scalar `sources:` was reported by list() already.
    if (sources.length === 0 && status !== 'planned' && (data.sources === undefined || Array.isArray(data.sources)))
      fail('no front-matter sources: (only a planned feature may have none)');
    if (data.platformDoc !== undefined && !text('platformDoc')) fail('platformDoc: must be a path');
    for (const route of routes) {
      const owner = routeOwner.get(route);
      if (owner && owner !== id) fail(`route ${route} is also owned by ${owner}`);
      else routeOwner.set(route, id);
    }
    return {
      id,
      path,
      title: text('title') ?? id,
      status: status ?? 'planned',
      summary: text('summary') ?? '',
      routes,
      sources,
      tests,
      ...(text('platformDoc') ? { platformDoc: text('platformDoc') } : {}),
      specs,
      roadmap,
      body,
    };
  });
  features.sort((a, b) => a.title.localeCompare(b.title, 'en') || (a.path < b.path ? -1 : 1));
  return { features, problems };
}

const escape = (char) => char.replace(/[.+^$()|[\]\\{}]/g, '\\$&');

/**
 * A matcher for a repository-relative glob: `**` (any number of directories), `*` and `?` (within a segment) and
 * `{a,b}`; no negation and no character classes. Unlike minimatch, a wildcard also matches a dot file.
 */
export function globMatcher(glob) {
  // An unbalanced brace is matched literally.
  const opens = [...glob].filter((c) => c === '{').length;
  const literalBraces = opens !== [...glob].filter((c) => c === '}').length;
  let source = '';
  let braces = 0;
  for (let i = 0; i < glob.length; i++) {
    const char = glob[i];
    if (char === '*' && glob[i + 1] === '*') {
      const atStart = i === 0 || glob[i - 1] === '/';
      i++;
      while (glob[i + 1] === '*') i++;
      if (atStart && glob[i + 1] === '/') {
        source += '(?:[^/]*/)*';
        i++;
      } else if (atStart && i === glob.length - 1) source += '.*';
      else source += '[^/]*';
    } else if (char === '*') source += '[^/]*';
    else if (char === '?') source += '[^/]';
    else if (char === '{' && !literalBraces) {
      braces++;
      source += '(?:';
    } else if (char === '}' && braces > 0) {
      braces--;
      source += ')';
    } else if (char === ',' && braces > 0) source += '|';
    else source += escape(char);
  }
  const pattern = new RegExp(`^${source}$`);
  return (path) => pattern.test(path);
}

/** The directory a glob's matches sit under: its segments before the first wildcard (a plain path's directory). */
export function globBase(glob) {
  const segments = glob.split('/');
  const wild = segments.findIndex((segment) => /[*?{]/.test(segment));
  return (wild === -1 ? segments.slice(0, -1) : segments.slice(0, wild)).join('/');
}

/** For each of a feature's `sources` globs, the files in `files` it matches, in `files` order. */
export function sourcesOf(feature, files) {
  return feature.sources.map((glob) => {
    const match = globMatcher(glob);
    return { glob, files: files.filter(match) };
  });
}

/** A matcher for the files under a source root: a directory, or a glob of directories such as `libs/features/{a,b}/src`. */
export function underRoot(root) {
  return globMatcher(`${root}/**`);
}

/**
 * What the catalogue leaves out (plan M13.1 § The module): mirror routes no feature owns, `sources` globs matching
 * none of `files`, and the files under each of `roots` (`underRoot`) that no feature's `sources` matches.
 */
export function catalogueGaps(features, { routes, files, roots }) {
  const owned = new Set(features.flatMap((f) => f.routes));
  const matchers = features.flatMap((f) => f.sources.map((glob) => ({ feature: f.id, glob, match: globMatcher(glob) })));
  return {
    unownedRoutes: routes.filter((route) => !owned.has(route)),
    emptyGlobs: matchers.filter(({ match }) => !files.some(match)).map(({ feature, glob }) => ({ feature, glob })),
    unclaimed: roots.map((root) => {
      const under = underRoot(root);
      return { root, files: files.filter((file) => under(file) && !matchers.some(({ match }) => match(file))) };
    }),
  };
}

/**
 * The fragments a link to a `##` or `###` heading of `markdown` may use: the workspace's id (`slugify`) and GitHub's
 * slug, as the renderer's `headingAnchor` accepts. Fenced code is skipped.
 */
export function headingSlugs(markdown) {
  const slugs = new Set();
  let fence = null;
  for (const line of markdown.split(/\r?\n/)) {
    const opener = /^\s*(`{3,}|~{3,})/.exec(line);
    if (fence) {
      if (opener && opener[1][0] === fence[0] && opener[1].length >= fence.length) fence = null;
      continue;
    }
    if (opener) {
      fence = opener[1];
      continue;
    }
    const heading = /^#{2,3}\s+(.+?)\s*#*\s*$/.exec(line);
    if (!heading) continue;
    // The text the renderer gives the heading (search-headings.ts plainText).
    const title = heading[1].replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').replace(/[`*~]/g, '').trim();
    slugs.add(title.toLowerCase().replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '-'));
    slugs.add(title.toLowerCase().replace(/[^\p{L}\p{M}\p{N}\p{Pc}\s-]/gu, '').replace(/ /g, '-'));
  }
  return slugs;
}

/** The tag prefix that names a feature on a Playwright test or describe: `{ tag: '@feature:sign-in' }`. */
export const FEATURE_TAG = '@feature:';

/** The file a test file tests: its path without the `.test` or `.spec` segment (`routes/cases.test.ts` → `routes/cases.ts`). */
export function testSubject(file) {
  return file.replace(/\.(test|spec)(\.[cm]?[jt]sx?)$/, '$2');
}

/**
 * Which features own which tests (spec M13 §6.2, plan M13.2 § Mapping). A file's path owners are the features whose
 * `sources` or `tests` globs match it or the file it tests (`testSubject`). A Playwright test belongs to the features
 * its `@feature:<id>` tags name, or to its file's path owners when it has no such tag; any other test to its file's
 * path owners. A test no feature owns is unassigned, or infrastructure when its file matches an `infrastructure` glob.
 */
export function testOwnership(features, inventory, { infrastructure }) {
  const ids = new Set(features.map((f) => f.id));
  const matchers = features.map((f) => ({ id: f.id, globs: [...f.sources, ...f.tests].map(globMatcher) }));
  const infra = infrastructure.map(globMatcher);
  const result = {
    features: Object.fromEntries(features.map((f) => [f.id, { unit: [], e2e: [] }])),
    files: [],
    unassigned: [],
    infrastructure: [],
    unknownTags: [],
  };
  for (const file of inventory.files) {
    const subject = testSubject(file.file);
    const pathOwners = matchers.filter(({ globs }) => globs.some((match) => match(file.file) || match(subject))).map(({ id }) => id);
    const tests = file.tests.map((test) => {
      if (file.runner !== 'playwright') return { ...test, owners: pathOwners };
      const tagged = [...new Set(test.tags.filter((tag) => tag.startsWith(FEATURE_TAG)).map((tag) => tag.slice(FEATURE_TAG.length)))];
      for (const id of tagged) if (!ids.has(id)) result.unknownTags.push({ file: file.file, line: test.line, tag: `${FEATURE_TAG}${id}` });
      return { ...test, owners: tagged.length > 0 ? tagged.filter((id) => ids.has(id)) : pathOwners };
    });
    const owned = { ...file, tests };
    result.files.push(owned);
    const kind = file.runner === 'playwright' ? 'e2e' : 'unit';
    for (const { id } of matchers) {
      const mine = tests.filter((test) => test.owners.includes(id));
      if (mine.length > 0) result.features[id][kind].push({ ...file, tests: mine });
    }
    const orphans = tests.filter((test) => test.owners.length === 0);
    // An infrastructure file lists the tests no feature owns (all of them, usually); any other file's are unassigned.
    if (infra.some((match) => match(file.file))) {
      if (orphans.length > 0 || tests.length === 0) result.infrastructure.push({ ...file, tests: orphans });
    } else if (orphans.length > 0) result.unassigned.push({ ...file, tests: orphans });
  }
  return result;
}
