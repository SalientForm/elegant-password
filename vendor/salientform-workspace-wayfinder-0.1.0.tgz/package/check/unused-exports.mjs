/**
 * Unused exports and orphan files (the feature audit's dead-code sweep, spec M12.11 §6.3), over the source files under
 * settings.areas[slug].unusedExports.roots. Heuristic and regex-based: confirm each hit before acting on it.
 *
 * Lists (a) exported names with no reference outside tests and barrels in any other file, and (b) files nothing
 * imports by relative path. Entry files (`entries`, globs), tests and barrels are never orphans; files under `ignore`
 * (a public API reached through its barrel, say) are not reported, but still count as users.
 */
import { readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { globMatcher } from './features.mjs';
import { repoRoot } from './index.mjs';

/** Entry files when the settings name none: app entries and tool configs nothing imports. */
export const DEFAULT_ENTRIES = [
  '**/main.{ts,tsx,js,jsx}',
  '**/index.html',
  '**/vite.config.{ts,mts,js,mjs}',
  '**/vitest.setup.ts',
  '**/test-setup.ts',
  '**/playwright.config.ts',
  '**/eslint.config.{js,mjs}',
];

const SKIP_DIRS = new Set(['node_modules', 'dist', 'out-tsc', 'test-output', '.nx', 'build', 'coverage']);
const WALKED = /\.([cm]?[jt]sx?|css)$/;
const DECLARATION = /\.d\.[cm]?ts$/;
const TARGET = /\.(tsx?|jsx?|mts)$/;
const isTest = (f) => /\.(test|spec)\.[cm]?[jt]sx?$/.test(f);
const isBarrel = (f) => /(^|\/)index\.[cm]?[jt]sx?$/.test(f);

function walk(dir, acc = []) {
  let entries;
  try {
    entries = readdirSync(path.join(repoRoot, dir), { withFileTypes: true });
  } catch {
    return acc;
  }
  for (const entry of entries) {
    const p = path.posix.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (!SKIP_DIRS.has(entry.name)) walk(p, acc);
    } else if (WALKED.test(entry.name) && !DECLARATION.test(entry.name)) acc.push(p);
  }
  return acc;
}

/** The area's `unusedExports` with its defaults: roots `['src']`, the default entries, nothing ignored. */
export function unusedExportsSettings(settings, slug = 'audit') {
  const given = settings.areas[slug]?.unusedExports ?? {};
  return { roots: given.roots ?? ['src'], entries: given.entries ?? DEFAULT_ENTRIES, ignore: given.ignore ?? [] };
}

/**
 * The unused exports and orphan files under the area's roots. `prefix` reports only paths starting with it; `exclude`
 * lists roots treated as already dead: their files use nothing (transitive death) and are not reported.
 * Returns { exports: { file, name }[], orphans: string[] }.
 */
export function findUnusedExports(settings, { slug = 'audit', prefix = '', exclude = [] } = {}) {
  const { roots, entries, ignore } = unusedExportsSettings(settings, slug);
  const dead = exclude.map((d) => (d.endsWith('/') ? d : `${d}/`));
  const ignored = ignore.map((d) => (d.endsWith('/') ? d : `${d}/`));
  const isEntry = (f) => entries.some((glob) => globMatcher(glob)(f));
  const all = roots.flatMap((root) => walk(root));
  const src = Object.fromEntries(all.map((f) => [f, readFileSync(path.join(repoRoot, f), 'utf8')]));
  const users = all.filter((f) => !dead.some((d) => f.startsWith(d)));
  const reported = (f) => f.startsWith(prefix) && !ignored.some((d) => f.startsWith(d)) && !dead.some((d) => f.startsWith(d));

  // (a) Exported names no other file outside tests and barrels mentions.
  const exportRe =
    /^export\s+(?:declare\s+)?(?:async\s+)?(?:const|let|var|function\*?|class|type|interface|enum)\s+([A-Za-z_$][\w$]*)/gm;
  const unused = [];
  for (const f of all.filter((f) => TARGET.test(f) && reported(f) && !isTest(f) && !isBarrel(f))) {
    for (const [, name] of src[f].matchAll(exportRe)) {
      const re = new RegExp(`\\b${name.replace(/\$/g, '\\$')}\\b`);
      if (!users.some((g) => g !== f && !isBarrel(g) && !isTest(g) && re.test(src[g]))) unused.push({ file: f, name });
    }
  }

  // (b) Files nothing imports by relative path.
  const importRe = /(?:from|import|require\(|import\()\s*['"]([^'"]+)['"]/g;
  const imported = new Set();
  for (const f of users)
    for (const [, spec] of src[f].matchAll(importRe)) {
      if (!spec.startsWith('.')) continue;
      const base = path.posix.normalize(path.posix.join(path.posix.dirname(f), spec)).replace(/\.js$/, '');
      for (const ext of ['', '.ts', '.tsx', '.js', '.jsx', '/index.ts', '/index.tsx', '/index.js', '.css'])
        if (src[base + ext] !== undefined) {
          imported.add(base + ext);
          break;
        }
    }
  const orphans = all.filter((f) => reported(f) && !imported.has(f) && !isEntry(f) && !isTest(f) && !isBarrel(f));
  return { exports: unused, orphans };
}

/** Prints the report for `argv` (`[pathPrefix] [--exclude=dir,dir]`), as the feature audit skill's script does. */
export function printUnusedExports(settings, argv) {
  const prefix = argv.find((a) => !a.startsWith('--')) ?? '';
  const exclude = (argv.find((a) => a.startsWith('--exclude=')) ?? '--exclude=').slice('--exclude='.length).split(',').filter(Boolean);
  const { exports, orphans } = findUnusedExports(settings, { prefix, exclude });
  console.log('== Exports with no non-test, non-barrel reference ==');
  for (const { file, name } of exports) console.log(`${file}  ${name}`);
  if (exports.length === 0) console.log('(none)');
  console.log('\n== Orphan files (nothing imports them by relative path) ==');
  for (const file of orphans) console.log(`ORPHAN ${file}`);
  if (orphans.length === 0) console.log('(none)');
}
