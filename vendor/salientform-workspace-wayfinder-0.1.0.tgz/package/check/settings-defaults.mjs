/**
 * The defaults of the optional settings that both the node checks and the browser modules read (spec M12.11 §6.1),
 * in one place so the two never disagree. Plain values; `settings.ts` documents each field.
 */

/**
 * `settings.areas.<about>`: where the skills live (the agent-neutral `.agents/skills`, spec M12.11 §6.14), the agent
 * directories that hold a link per kit skill (`.claude/skills`, for Claude Code), and which root package.json script
 * runs the checks.
 */
export const ABOUT_DEFAULTS = { skillsDir: '.agents/skills', skillLinks: ['.claude/skills'], checkScript: 'workspace:check' };

/**
 * `settings.areas.<audit>`: the directories of specs and plans (the first holds specs, the others plans; a document
 * directly in one carries a Milestone line), the folder of the review files, tracked paths left out of the markdown set,
 * and paths whose links are not checked.
 */
export const AUDIT_DEFAULTS = { specDirs: ['docs/specs', 'docs/plans'], reviews: 'docs/reviews', ignore: [], linkExempt: [] };

/** A repository-relative directory: not absolute, no empty, '.' or '..' segment, no trailing slash. */
const isRepoDir = (dir) =>
  typeof dir === 'string' && dir !== '' && !dir.startsWith('/') && dir.split('/').every((s) => s !== '' && s !== '.' && s !== '..');

/**
 * The problems of `skillLinks` beside `skillsDir`: a list of repository-relative directories, none equal to
 * `skillsDir` or inside it, none repeated (`[]`: no links). `at` names the about settings in each problem.
 */
export function skillLinksProblems(skillsDir, skillLinks, at = 'settings.areas.about') {
  if (!isRepoDir(skillsDir)) return [`${at}.skillsDir ${JSON.stringify(skillsDir)} is not a repository-relative directory`];
  if (!Array.isArray(skillLinks)) return [`${at}.skillLinks is not a list of directories`];
  const problems = [];
  const seen = new Set();
  skillLinks.forEach((dir, i) => {
    const where = `${at}.skillLinks[${i}] ${JSON.stringify(dir)}`;
    if (!isRepoDir(dir)) problems.push(`${where} is not a repository-relative directory`);
    else if (dir === skillsDir) problems.push(`${where} is the skills directory itself`);
    else if (dir.startsWith(`${skillsDir}/`)) problems.push(`${where} is inside the skills directory ${skillsDir}`);
    else if (seen.has(dir)) problems.push(`${where} repeats`);
    seen.add(dir);
  });
  return problems;
}

/** `about` with its defaults applied; throws on a `skillsDir` or `skillLinks` that breaks `skillLinksProblems`. */
export function aboutSettings(about) {
  const settings = { ...ABOUT_DEFAULTS, ...about };
  const problems = skillLinksProblems(settings.skillsDir, settings.skillLinks);
  if (problems.length > 0) throw new Error(`wayfinder: ${problems.join('; ')}`);
  return settings;
}

/**
 * The Audit area's optional implementation files (plan C): each of `roadmap`, `todo` and `architecture` is configured
 * on its own, and the vocabularies that read a file come with it. `[setting, file, what]`: the setting needs the file,
 * and a file with a required setting needs it.
 */
export const AUDIT_FILE_SETTINGS = [
  ['phaseKinds', 'roadmap', true],
  ['todoAreas', 'todo', true],
  ['todoSources', 'todo', false],
];

/**
 * `audit` with its defaults applied; throws on `ledger` or `documents`, which are markdown now (spec M12.11 §6.15), on
 * `phaseKinds` without `roadmap` or `todoAreas` or `todoSources` without `todo`, and on `roadmap` without `phaseKinds`
 * or `todo` without `todoAreas`.
 */
export function auditSettings(audit) {
  for (const key of ['ledger', 'documents'])
    if (audit[key] !== undefined) throw new Error(`wayfinder: areas.audit.${key} is gone: the ledger is markdown since §6.15 (reviews)`);
  for (const [key, file, required] of AUDIT_FILE_SETTINGS) {
    if (audit[key] !== undefined && audit[file] === undefined)
      throw new Error(`wayfinder: areas.audit.${key} is set but areas.audit.${file} is not: it describes that file, so set both or neither`);
    if (required && audit[file] !== undefined && audit[key] === undefined)
      throw new Error(`wayfinder: areas.audit.${file} needs areas.audit.${key}, the values its entries may take`);
  }
  return { ...AUDIT_DEFAULTS, ...audit };
}

/**
 * The command that runs a root package.json script, from its `packageManager` field: `pnpm <script>`, `yarn <script>`,
 * `bun run <script>`, otherwise `npm run <script>`.
 */
export function scriptCommand(packageJson, script) {
  const manager = String(packageJson?.packageManager ?? '').split('@')[0];
  if (manager === 'pnpm' || manager === 'yarn') return `${manager} ${script}`;
  if (manager === 'bun') return `bun run ${script}`;
  return `npm run ${script}`;
}
