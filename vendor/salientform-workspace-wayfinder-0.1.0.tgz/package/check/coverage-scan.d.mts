import type { CoverageReport } from './coverage.mjs';

/** Every summary the globs match under `repoRoot`, merged, and the ones that did not parse. */
export function readCoverage(repoRoot: string, summaries: readonly string[]): CoverageReport & { problems: string[] };

/** A summary key (an absolute path) as a repository path: relative under `repoRoot`, else cut at `projectDir`. */
export function summaryKeyPath(key: string, repoRoot: string, projectDir: string): string | undefined;
