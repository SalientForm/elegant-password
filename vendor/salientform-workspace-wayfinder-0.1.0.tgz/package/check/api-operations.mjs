/**
 * API operations from an OpenAPI document and an optional consumer registry (spec M12.6 §5.3): dependency-free ESM so
 * the API module (through Vite) and its check (through plain node) read both, and judge their agreement, the same way.
 * Types: api-operations.d.mts.
 */

/** The HTTP methods an OpenAPI path item can hold; its other keys (`parameters`, `summary`, …) are not operations. */
export const HTTP_METHODS = ['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS', 'HEAD', 'PATCH', 'TRACE'];
export const ENDPOINT_STATUSES = ['used', 'unused', 'stub'];
/** The group a registry-backed page puts document operations the registry does not list in. */
export const UNLISTED_GROUP = { id: 'unlisted', label: 'Not in the registry' };

const isObject = (value) => typeof value === 'object' && value !== null && !Array.isArray(value);
const KEBAB = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

/** A tag's group id: lowercase, words joined by '-'. */
const groupId = (label) =>
  label
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'group';

/** Every operation the document describes, in document order: one per HTTP method of each path item. */
export function documentOperations(document) {
  const paths = isObject(document) && isObject(document.paths) ? document.paths : {};
  const operations = [];
  for (const [path, item] of Object.entries(paths)) {
    if (!isObject(item)) continue;
    for (const [name, operation] of Object.entries(item)) {
      const method = name.toUpperCase();
      if (!HTTP_METHODS.includes(method) || name !== name.toLowerCase() || !isObject(operation)) continue;
      const tags = Array.isArray(operation.tags) ? operation.tags.filter((t) => typeof t === 'string') : [];
      const summary = typeof operation.summary === 'string' ? operation.summary : undefined;
      operations.push({ method, path, key: `${method} ${path}`, summary, tags });
    }
  }
  return operations;
}

/**
 * A handler's label: its path relative to the nearest of `root` and root's ancestors that contains it
 * (`apps/api/src/routes/cases.ts` → `cases.ts`, `apps/api/src/app.ts` → `app.ts`), else its whole path; without a
 * root, its file name.
 */
export function handlerLabel(handler, root) {
  if (!root) return handler.slice(handler.lastIndexOf('/') + 1);
  for (let dir = root.replace(/\/$/, ''); dir; dir = dir.includes('/') ? dir.slice(0, dir.lastIndexOf('/')) : '')
    if (handler.startsWith(`${dir}/`)) return handler.slice(dir.length + 1);
  return handler;
}

/** The document's tag groups (spec M12.6 §5.3): declared tags in order, then the others by first use, then untagged. */
function tagGroups(document, operations) {
  const labels = [];
  const add = (label) => {
    if (!labels.includes(label)) labels.push(label);
  };
  for (const tag of Array.isArray(document?.tags) ? document.tags : []) if (typeof tag?.name === 'string') add(tag.name);
  for (const op of operations) for (const tag of op.tags) add(tag);
  const used = labels.filter((label) => operations.some((op) => op.tags[0] === label));
  const groups = used.map((label) => ({ id: groupId(label), label }));
  const untagged = operations.some((op) => op.tags.length === 0);
  const fallback = groups.length === 0 ? { id: 'operations', label: 'Operations' } : { id: 'other', label: 'Other' };
  // Two labels that slugify alike, or a tag that slugifies to the fallback's id, get a numbered id.
  const seen = new Set();
  for (const group of untagged ? [...groups, fallback] : groups) {
    let id = group.id;
    for (let n = 2; seen.has(id); n++) id = `${group.id}-${n}`;
    group.id = id;
    seen.add(id);
  }
  return {
    groups: untagged ? [...groups, fallback] : groups,
    groupOf: (op) => (op.tags[0] ? groups[used.indexOf(op.tags[0])].id : fallback.id),
  };
}

/** The registry's own problems, each naming the registry; returns the rows worth building from. */
function registryProblems(registry, name, problems) {
  if (!isObject(registry)) {
    problems.push(`${name} is not a JSON object with groups and endpoints`);
    return { groups: [], endpoints: [] };
  }
  if (registry.handlerRoot !== undefined && typeof registry.handlerRoot !== 'string')
    problems.push(`${name}: handlerRoot is not a string`);
  const groups = Array.isArray(registry.groups) ? registry.groups : [];
  if (!Array.isArray(registry.groups)) problems.push(`${name}: groups is not an array`);
  const groupIds = new Set();
  groups.forEach((group, i) => {
    if (!isObject(group) || typeof group.id !== 'string' || !KEBAB.test(group.id))
      problems.push(`${name}: group ${i} has no lowercase-kebab id`);
    else if (group.id === UNLISTED_GROUP.id) problems.push(`${name}: group id '${group.id}' is reserved`);
    else if (groupIds.has(group.id)) problems.push(`${name}: two groups have the id '${group.id}'`);
    else groupIds.add(group.id);
    if (!isObject(group) || typeof group.label !== 'string' || !group.label)
      problems.push(`${name}: group ${i} has no label`);
  });
  const endpoints = Array.isArray(registry.endpoints) ? registry.endpoints : [];
  if (!Array.isArray(registry.endpoints)) problems.push(`${name}: endpoints is not an array`);
  const keys = new Set();
  const valid = [];
  endpoints.forEach((endpoint, i) => {
    if (!isObject(endpoint)) {
      problems.push(`${name}: endpoint ${i} is not an object`);
      return;
    }
    const key = `${endpoint.method} ${endpoint.path}`;
    const at = `${name}: ${typeof endpoint.method === 'string' && typeof endpoint.path === 'string' ? key : `endpoint ${i}`}`;
    const before = problems.length;
    if (!HTTP_METHODS.includes(endpoint.method)) problems.push(`${at} has no upper-case HTTP method`);
    if (typeof endpoint.path !== 'string' || !endpoint.path.startsWith('/')) problems.push(`${at} has no path starting with /`);
    if (!groupIds.has(endpoint.group)) problems.push(`${at} names no declared group (${JSON.stringify(endpoint.group)})`);
    if (!ENDPOINT_STATUSES.includes(endpoint.status))
      problems.push(`${at} has status ${JSON.stringify(endpoint.status)}, not ${ENDPOINT_STATUSES.join(', ')}`);
    if (typeof endpoint.description !== 'string' || !endpoint.description) problems.push(`${at} has no description`);
    for (const field of ['handler', 'consumer', 'note'])
      if (endpoint[field] !== undefined && typeof endpoint[field] !== 'string') problems.push(`${at}: ${field} is not a string`);
    if (endpoint.example !== undefined && (typeof endpoint.example !== 'string' || !endpoint.example.startsWith('/')))
      problems.push(`${at}: example does not start with /`);
    if (
      endpoint.pages !== undefined &&
      !(Array.isArray(endpoint.pages) && endpoint.pages.every((p) => typeof p === 'string' && p.startsWith('/')))
    )
      problems.push(`${at}: pages is not a list of routes starting with /`);
    if (endpoint.outsideDocument !== undefined && endpoint.outsideDocument !== true)
      problems.push(`${at}: outsideDocument is not true`);
    if (keys.has(key)) problems.push(`${at} is listed twice`);
    keys.add(key);
    if (problems.length === before) valid.push(endpoint);
  });
  return { groups: groups.filter((g) => isObject(g) && groupIds.has(g.id)), endpoints: valid };
}

/**
 * The page's groups and rows, every problem (the registry's own faults, or a document with no `paths`) and the drift
 * (where the registry and the document disagree). `names` label the two files in the messages.
 */
export function apiOperations(document, registry, names = {}) {
  const documentName = names.document ?? 'the document';
  const registryName = names.registry ?? 'the registry';
  const problems = [];
  const drift = [];
  if (!isObject(document) || !isObject(document.paths)) problems.push(`${documentName} has no paths object`);
  const fromDocument = documentOperations(document);

  if (registry === undefined) {
    const { groups, groupOf } = tagGroups(document, fromDocument);
    const operations = fromDocument.map((op) => ({
      method: op.method,
      path: op.path,
      key: op.key,
      group: groupOf(op),
      inDocument: true,
      description: op.summary ?? '',
    }));
    return { groups, operations, problems, drift };
  }

  const { groups, endpoints } = registryProblems(registry, registryName, problems);
  const root = isObject(registry) && typeof registry.handlerRoot === 'string' ? registry.handlerRoot : undefined;
  const described = new Map(fromDocument.map((op) => [op.key, op]));
  const operations = endpoints.map((endpoint) => {
    const key = `${endpoint.method} ${endpoint.path}`;
    const inDocument = described.has(key);
    if (endpoint.outsideDocument && inDocument)
      drift.push(`${key} is marked outsideDocument in ${registryName}, but ${documentName} describes it`);
    if (!endpoint.outsideDocument && !inDocument)
      drift.push(`${key} is in ${registryName} but not in ${documentName} (mark it outsideDocument if the API serves it anyway)`);
    const operation = { method: endpoint.method, path: endpoint.path, key, group: endpoint.group, inDocument, description: endpoint.description, endpoint };
    if (endpoint.handler) operation.handlerLabel = handlerLabel(endpoint.handler, root);
    return operation;
  });
  const listed = new Set(operations.map((op) => op.key));
  const unlisted = fromDocument.filter((op) => !listed.has(op.key));
  for (const op of unlisted) drift.push(`${op.key} is in ${documentName} but not in ${registryName}`);
  for (const op of unlisted)
    operations.push({ method: op.method, path: op.path, key: op.key, group: UNLISTED_GROUP.id, inDocument: true, description: op.summary ?? '' });
  return { groups: unlisted.length ? [...groups, { ...UNLISTED_GROUP }] : groups, operations, problems, drift };
}
