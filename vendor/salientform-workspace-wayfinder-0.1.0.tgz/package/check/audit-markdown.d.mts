export type PhaseStatus = 'not started' | 'specified' | 'planned' | 'in progress';

export interface Phase {
  /** 'M2.4' */
  id: string;
  /** 'M2' */
  milestoneId: string;
  title: string;
  status: PhaseStatus;
  /** One of the configured phase kinds (`settings.areas.audit.phaseKinds`). */
  kind: string;
  goal: string;
  notInScope?: string;
  /** Phase IDs and free-text external conditions, as written. */
  dependsOn: string[];
  spec?: string;
  /** The current plan: the first of `plans`. */
  plan?: string;
  /** Every plan the phase names, in the order they run (a phase may need several, one after another). */
  plans?: string[];
  /** The section's markdown minus the Status / Kind / Depends on / Spec / Plan bullets. */
  body: string;
}
export interface Milestone { id: string; title: string; summary: string; phases: Phase[] }
export interface CompletedPhase { id: string; title: string; shipped: string; ref?: string }
/** A row under "Outside the roadmap": work that aligns with no milestone. */
export interface OutsideRow { id: string; title: string; spec?: string; plan?: string }
export interface Roadmap {
  reviewedAt: string;
  sequence: string[];
  milestones: Milestone[];
  completed: CompletedPhase[];
  /** NaN when the "Outside the roadmap" section is absent. */
  nextX: number;
  outside: OutsideRow[];
}

export interface Todo {
  id: number;
  title: string;
  /** One of the configured TODO areas (`settings.areas.audit.todoAreas`). */
  area: string;
  /** A repository path, or a value `isTodoPath` rejects (`idea`, a configured prefix such as `feature-audit:<slug>`). */
  source: string;
  added: string;
  body: string;
}
export interface TodoList { reviewedAt: string; nextId: number; todos: Todo[] }

export interface StackItem { area: string; item: string; planned: boolean; note?: string; ref?: string }
export interface StackSummary { reviewedAt: string; areas: string[]; items: StackItem[] }

/** A roadmap's house convention: the values a phase's `Kind:` may take. `settings.areas.audit` satisfies it. */
export interface RoadmapConventions {
  phaseKinds: readonly string[];
  /** The file's name in error messages. Default 'ROADMAP.md'. */
  file?: string;
}
/** A TODO list's house convention: the values an entry's `Area:` may take. `settings.areas.audit` satisfies it. */
export interface TodoConventions {
  todoAreas: readonly string[];
  /** The file's name in error messages. Default 'TODO.md'. */
  file?: string;
}

export const PHASE_STATUSES: readonly PhaseStatus[];
export const PHASE_ID: RegExp;
export const MILESTONE_ID: RegExp;
export const X_ID: RegExp;

/**
 * Throws `Error('<file>:<line>: …')` on malformed input or when validateRoadmap reports problems, and a TypeError
 * when `phaseKinds` is missing or empty.
 */
export function parseRoadmap(markdown: string, conventions: RoadmapConventions): Roadmap;
/** Throws like parseRoadmap; a TypeError when `todoAreas` is missing or empty. */
export function parseTodos(markdown: string, conventions: TodoConventions): TodoList;
export function parseStackSummary(markdown: string, options?: { file?: string }): StackSummary;
/** Phase IDs named by the bullets under "## Planned migrations" in the architecture document. */
export function parsePlannedMigrations(markdown: string, options?: { file?: string }): string[];
/**
 * Whether a TODO `Source:` names a repository path. `todoSources` are the values that do not: an exact value, or a
 * prefix ending in ':'. Default ['idea'].
 */
export function isTodoPath(source: string, todoSources?: readonly string[]): boolean;
export function validateRoadmap(roadmap: Roadmap): string[];
export function validateTodos(list: TodoList): string[];
