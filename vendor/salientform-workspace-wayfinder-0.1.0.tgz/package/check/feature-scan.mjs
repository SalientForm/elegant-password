/**
 * The source scan (plan M13.1 § The source scan): the files a feature's globs can match, walked from disk. Plain node
 * (`node:fs` only), so the Features area's Vite plugin and the catalogue check list the same files. Types:
 * feature-scan.d.mts.
 */
import { readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { globBase } from './features.mjs';

const SKIP_DIRS = new Set(['node_modules', 'dist', 'out-tsc', '.nx', '.git', 'coverage', 'test-output']);
const TEST_FILE = /\.(test|spec)\.[cm]?[jt]sx?$/;

const isDirectory = (dir) => {
  try {
    return statSync(dir).isDirectory();
  } catch {
    return false;
  }
};

function walk(repoRoot, dir, includeTests, out) {
  for (const entry of readdirSync(path.join(repoRoot, dir))) {
    if (SKIP_DIRS.has(entry)) continue;
    const rel = dir ? `${dir}/${entry}` : entry;
    if (isDirectory(path.join(repoRoot, rel))) walk(repoRoot, rel, includeTests, out);
    else if (includeTests || !TEST_FILE.test(entry)) out.add(rel);
  }
}

/**
 * Every file under `roots` (directories, or globs of directories) and under each of `globs`' bases (`globBase`),
 * repository-relative and sorted. A base that
 * is not a directory is skipped, so its glob matches nothing. Tests (`*.test.*`, `*.spec.*`) are left out unless
 * `includeTests`; `node_modules`, `dist`, `out-tsc`, `.nx`, `.git`, `coverage` and `test-output` always are.
 */
export function scanFeatureSources(repoRoot, { roots = [], globs = [], includeTests = false } = {}) {
  const bases = [...new Set([...roots.map((root) => globBase(`${root}/**`)), ...globs.map(globBase)])].sort();
  // A base inside another is walked with it.
  const walked = bases.filter((base, i) => !bases.slice(0, i).some((outer) => outer === '' || base.startsWith(`${outer}/`)));
  const files = new Set();
  for (const base of walked) if (isDirectory(path.join(repoRoot, base))) walk(repoRoot, base, includeTests, files);
  return { roots: [...roots], files: [...files].sort() };
}
