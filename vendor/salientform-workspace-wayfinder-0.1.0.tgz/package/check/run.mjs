/**
 * The check runner (spec M12.11 §6.3): every skill's check script is `await runCheck('<name>')`. It loads the workspace
 * config and the repository's rules file (package.json `wayfinder.config` and `wayfinder.rules`), runs the named check
 * with what the rules hooks return, appends the problems `extraChecks` returns under that name, prints the notes, and
 * exits 1 on any problem or prints the OK line.
 *
 * Checks: about, audit, feature-audit, features, api, platform-docs. Each check's own header lists what
 * fails it.
 */
import { checkAbout } from './about.mjs';
import { checkApi } from './api.mjs';
import { checkAuditImplementation } from './audit-implementation.mjs';
import { checkAuditLedger } from './audit-ledger.mjs';
import { checkFeatureAudit } from './feature-audit.mjs';
import { checkFeatureCatalogue } from './feature-catalogue.mjs';
import { exists, finish, loadWorkspaceRules, loadWorkspaceSettings, readRepo, repoRoot } from './index.mjs';
import { checkPlatformDocs } from './platform-docs.mjs';

/** Each check: (settings, rules, ctx) → { problems, ok, notes? }. */
export const CHECKS = {
  about: (settings) => {
    const r = checkAbout(settings);
    return { problems: r.problems, ok: `about OK — ${r.summary}` };
  },
  audit: (settings) => {
    const implementation = checkAuditImplementation(settings);
    const ledger = checkAuditLedger(settings, { implementation });
    return {
      problems: [...implementation.problems, ...ledger.problems],
      // The implementation summary names only the configured files, and is empty without any.
      ok: `audit registries OK — ${[ledger.summary, implementation.summary].filter(Boolean).join('; ')}`,
    };
  },
  'feature-audit': (settings) => {
    const r = checkFeatureAudit(settings);
    return { problems: r.problems, ok: `feature-audit registry OK — ${r.summary}` };
  },
  features: (settings, rules, ctx) => {
    const r = checkFeatureCatalogue(settings, { router: rules.productRoutes?.(ctx) });
    return { problems: r.problems, ok: `feature catalogue OK — ${r.summary}` };
  },
  api: (settings, rules, ctx) => {
    const r = checkApi(settings, { fetched: rules.fetchSites?.(ctx) });
    return { problems: r.problems, ok: `API registry OK — ${r.summary}` };
  },
  'platform-docs': (settings, rules, ctx) => {
    const labels = rules.navLabels?.(ctx);
    const r = checkPlatformDocs(settings, { mentions: labels ?? [] });
    return {
      problems: r.problems,
      notes: r.unmentioned.map((label) => `unmentioned: ${label}`),
      ok: `platform docs OK — ${r.summary}${labels ? `, ${labels.length} navigation labels checked` : ''}`,
    };
  },
};

/** Runs check `name` in the repository the process runs in, then exits (see the header). */
export async function runCheck(name) {
  const check = CHECKS[name];
  if (!check) throw new Error(`wayfinder: no check ${name} (${Object.keys(CHECKS).join(', ')})`);
  const settings = await loadWorkspaceSettings();
  const rules = await loadWorkspaceRules();
  const ctx = { settings, repoRoot, readRepo, exists };
  const { problems, ok, notes = [] } = check(settings, rules, ctx);
  const extra = rules.extraChecks?.(ctx)?.[name] ?? [];
  for (const note of notes) console.log(note);
  finish([...problems, ...extra], ok);
}
