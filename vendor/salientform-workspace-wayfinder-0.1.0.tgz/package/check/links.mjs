/**
 * Relative links in markdown whose target does not exist: dependency-free ESM for the check scripts. A rendered
 * document never ships a broken link; the check fails until the path is fixed or the link removed. Types: links.d.mts.
 */
import path from 'node:path';

const LIST_ITEM = /^\s*([-*+]|\d+[.)])\s/;

/** Markdown with code (fenced, indented and inline) blanked out, line numbers kept. */
function withoutCode(markdown) {
  const lines = markdown.split(/\r?\n/);
  let fence = null;
  let previous = '';
  let blankBefore = true;
  let inIndentedCode = false;
  return lines.map((line) => {
    const opener = /^\s*(`{3,}|~{3,})/.exec(line); // list items indent their fences
    if (fence) {
      if (
        opener &&
        opener[1][0] === fence[0] &&
        opener[1].length >= fence.length
      )
        fence = null;
      return '';
    }
    if (opener) {
      fence = opener[1];
      return '';
    }
    const blank = line.trim() === '';
    // An indented block starts after a blank line that does not continue a list item; it runs until a line is not indented.
    const indented = /^( {4}|\t)/.test(line);
    if (!indented && !blank) inIndentedCode = false;
    else if (
      indented &&
      blankBefore &&
      !LIST_ITEM.test(previous) &&
      !/^\s/.test(previous)
    )
      inIndentedCode = true;
    if (!blank) previous = line;
    blankBefore = blank;
    if (inIndentedCode) return '';
    return line.replace(/(`+)[^`]*?\1/g, '');
  });
}

/** Every relative link (inline `[text](href)` and reference `[id]: href`) with its 1-based line. */
export function relativeLinks(markdown) {
  const links = [];
  withoutCode(markdown).forEach((line, index) => {
    const hrefs = [
      ...[...line.matchAll(/\]\(\s*(<[^>]*>|[^)\s]+)/g)].map((m) => m[1]),
      ...[...line.matchAll(/^\s{0,3}\[[^\]]+\]:\s*(<[^>]*>|\S+)/g)].map(
        (m) => m[1]
      ),
    ];
    for (const raw of hrefs) {
      const href = raw.replace(/^<|>$/g, '');
      if (
        !href ||
        href.startsWith('#') ||
        href.startsWith('/') ||
        /^[a-z][a-z0-9+.-]*:/i.test(href)
      )
        continue;
      links.push({ line: index + 1, href });
    }
  });
  return links;
}

/** The repository path a relative href in `file` points at, without its fragment or query. */
export function linkTarget(file, href) {
  const bare = href.split('#')[0].split('?')[0];
  let decoded = bare;
  try {
    decoded = decodeURI(bare);
  } catch {
    // keep the raw path: a malformed escape is reported as missing
  }
  return path.posix
    .normalize(path.posix.join(path.posix.dirname(file), decoded))
    .replace(/\/$/, '');
}

/**
 * The links in `file` whose target `exists(target)` denies. A link to the file itself by fragment (`#x`) or to an
 * external URL is never checked; a link resolving outside the repository is reported.
 */
export function brokenLinks(file, markdown, exists) {
  return relativeLinks(markdown).flatMap(({ line, href }) => {
    const target = linkTarget(file, href);
    if (target === '.' || target === '') return [];
    if (!target.startsWith('../') && exists(target)) return [];
    return [{ line, href, target }];
  });
}
