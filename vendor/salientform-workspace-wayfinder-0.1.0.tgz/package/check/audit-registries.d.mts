/**
 * The Audit area's registries as data: the spec ledger, the documents readable in full, the feature
 * audit and the product's route mirror. Each is a JSON file at a path the workspace config names; the readers in
 * audit-registries.mjs validate them in both runtimes.
 */

/**
 * The spec ledger (`settings.areas.audit.reviews`): one review per markdown file or directory, one row per spec and plan.
 * Built from markdown by `readAuditMarkdown` (`docs/formats.md`, "The spec ledger and reviews"); the fields are the
 * same whether a row came from a review file or a document's front matter. Owner: assess-audit.
 */
export interface AuditLedger {
  /** ISO date the ledger was last modified; the date rule (check/index.mjs). */
  reviewedAt: string;
  /** The All markdowns page's sections, in page order: ids are DocReview kinds. Was DocKind and KIND_LABEL. */
  kinds: DocKind[];
  /** One review per tracked markdown file, or per directory with a trailing '/'. */
  docReviews: DocReview[];
  /** One row per spec and plan. */
  specStatus: SpecStatus[];
}

/** A section of the All markdowns page; the repository's own heading, which the ledger rules put no meaning on. */
export interface DocKind {
  /** The value a DocReview's `kind` names. */
  id: string;
  /** The section heading, e.g. 'Specs'. */
  label: string;
}

/**
 * current          — accurate as of the review date
 * partially-stale  — mostly right, with named sections that no longer match
 * stale            — describes a repo state that no longer exists
 * superseded       — replaced by a newer document (named in `ref`)
 * done             — a spec/plan whose work has shipped
 * conflicting      — contradicts a later decision (named in `ref`)
 * wrong            — factually incorrect content
 */
export type DocVerdict = 'current' | 'partially-stale' | 'stale' | 'superseded' | 'done' | 'conflicting' | 'wrong';

export interface DocReview {
  /** Repo-relative path; a trailing `/` covers every markdown file in that tree. */
  path: string;
  /** One of the ledger's `kinds` ids. */
  kind: string;
  /** ISO date the file was last modified, as recorded by whoever edited it: a valid date, not after today. Not derived from git. */
  lastModified: string;
  verdict: DocVerdict;
  /** What is out of date and how that was verified. Omit when nothing is stale. */
  staleContent?: string;
  /** Future work, TODOs, roadmap items, or open follow-ups the document carries. */
  futureContent?: string;
  /** Where `futureContent` is tracked: '#<id>' (the TODO list), a phase, milestone or X id (the roadmap), or a specStatus path. Required, non-empty, whenever futureContent is set. */
  tracked?: string[];
  /** One imperative sentence. */
  recommendation: string;
  /** Superseding/conflicting document or decision. */
  ref?: string;
}

/**
 * draft         — written, not yet reviewed
 * under-review  — awaiting a decision
 * blocked       — cannot start until `blockedOn` lands
 * conflicting   — contradicts a later decision; needs a rewrite or retirement
 * implemented   — shipped
 * superseded    — replaced by another document
 */
export type SpecState = 'draft' | 'under-review' | 'blocked' | 'conflicting' | 'implemented' | 'superseded';

export interface SpecStatus {
  path: string;
  title: string;
  kind: 'spec' | 'plan';
  /**
   * The document's `**Milestone:**` line, read from its body: a phase (`M3.1`), a milestone (`M10`, historical rows
   * only) or an X id (`X4`, a row under "Outside the roadmap" in the roadmap). Required on every document directly in a
   * `specDirs` directory; the Milestone check enforces it.
   */
  milestone?: string;
  state: SpecState;
  /** Short description of what the document delivers. */
  summary: string;
  /** What must land first (for `blocked`). */
  blockedOn?: string;
  /** Open follow-ups the document itself lists. */
  followUps?: string[];
  /** Evidence for the state: commit, PR, or decision. */
  evidence?: string;
  /** For `kind: 'plan'`: repo path of the spec this plan implements, when that spec is in the ledger (front matter `spec`). */
  specPath?: string;
}

/** The documents readable in full under Documentation: the reviews index's `documents`. Owner: assess-audit. */
export interface AuditDocuments {
  /** ISO date the list was last modified. */
  reviewedAt: string;
  /** In nav order. */
  documents: AuditDocument[];
}

/** One document under Documentation. Was DocEntry. */
export interface AuditDocument {
  /** Lowercase kebab, unique: the URL segment in `/<slug>/documentation/<id>`. */
  id: string;
  title: string;
  /** Repo-relative path (for the GitHub link and the review cross-reference). A content collection must cover it. */
  path: string;
  description: string;
  /** Heading slug to scroll to when the document opens. */
  anchor?: string;
}

/**
 * The feature audit (`settings.areas.audit.featureAudit`): dead code, unreachable features, known TODOs and
 * recommendations across the codebase, each with the files involved and one concrete action. Owner:
 * assess-feature-audit.
 */
export interface FeatureAudit {
  /** ISO date the audit was last modified. */
  reviewedAt: string;
  /** The Features page's sections, in page order. Were AuditGroup and the page's GROUPS. */
  groups: FindingGroup[];
  /** The feature audit's findings; the feature inventory is the Features area's catalogue. */
  findings: AuditFinding[];
}

/** A section of the Features page; the repository's own heading. */
export interface FindingGroup {
  /** The value an AuditFinding's `group` names. */
  id: string;
  title: string;
  /** One sentence under the title. */
  blurb: string;
}

export type FindingKind = 'dead-code' | 'unreachable' | 'todo' | 'recommendation';

/**
 * open    — not documented anywhere else
 * known   — already recorded in docs (the architecture document, a repository audit); cite in `ref`
 * planned — a fix is queued
 */
export type FindingStatus = 'open' | 'known' | 'planned';

export interface AuditFinding {
  /** URL-safe id (anchor); a `kind: 'todo'` finding pairs with the TODO whose Source is `feature-audit:<slug>`. */
  slug: string;
  title: string;
  kind: FindingKind;
  /** One of the audit's `groups` ids. */
  group: string;
  status: FindingStatus;
  /** One or two sentences: what is dead/unreachable and how that was established. */
  summary: string;
  /** Repo-relative paths (a directory means the whole tree). */
  files: string[];
  /** One concrete, imperative action. */
  action: string;
  /** Optional size hint, e.g. "1502 lines / 7 files". */
  size?: string;
  /** Where this is already documented, when status is `known`/`planned`. */
  ref?: string;
  /** Product route where the finding is visible, if any. */
  page?: string;
}

/**
 * The product's route mirror (`settings.productRoutes`): what the product the workspace documents registers, which the
 * product's own check keeps equal to its router. Owner: assess-features; the Features area checks every route has one
 * feature.
 */
export interface ProductRoutes {
  /** Every page route the product registers, `:param` for a path parameter. */
  routes: string[];
  /** The paths the product's main navigation links. */
  sidebar?: string[];
}

/** What a reader returns: the value with its malformed rows dropped, and every problem, each naming the file and row. */
export interface ReadResult<T> {
  value: T;
  problems: string[];
}

export const DOC_VERDICTS: readonly DocVerdict[];
export const SPEC_STATES: readonly SpecState[];
/** `implemented`, `superseded`: rows that no longer describe unbuilt work. */
export const CLOSED_SPEC_STATES: readonly SpecState[];
/** `draft`, `under-review`, `blocked`: the states a roadmap phase's Spec or Plan must be in. */
export const ACTIVE_SPEC_STATES: readonly SpecState[];
export const FINDING_KINDS: readonly FindingKind[];
export const FINDING_STATUSES: readonly FindingStatus[];
/** The TODO `Source:` prefix that names a feature-audit finding: `feature-audit:<slug>`. */
export const FEATURE_AUDIT_SOURCE: 'feature-audit:';

/** The spec ledger; `file` names it in the problems. */
export function readLedger(json: unknown, file: string): ReadResult<AuditLedger>;
/** `index.md`: the reviews folder's index, a file in `AuditSettings.reviews`. */
export const REVIEWS_INDEX: 'index.md';
/** The file name of a review of a directory, `<reviews>/<dir>/_directory.review.md`. */
export const DIRECTORY_REVIEW: '_directory.review.md';
/** The review file of a reviewed path: `docs/x.md` → `<reviews>/docs/x.review.md`; a directory → its `_directory.review.md`. */
export function reviewFilePath(reviews: string, path: string): string;
/** The text of a markdown document's first `# ` heading outside fenced code, or undefined. */
export function firstHeading(markdown: string): string | undefined;
/** Each `**Milestone:**` id before a document's first `## ` heading. */
export function milestoneIds(body: string): string[];
/**
 * The spec ledger and the documents built from their markdown: every markdown file under `specDirs`, the review files
 * under `reviews` (without the index) and the index's text. `documents` is undefined when the index has none.
 */
export function readAuditMarkdown(input: {
  specDirs: readonly string[];
  reviews: string;
  specDocs: readonly { path: string; markdown: string }[];
  reviewDocs: readonly { path: string; markdown: string }[];
  indexMarkdown: string;
}): { ledger: AuditLedger; documents: AuditDocuments | undefined; problems: string[] };
/** The documents registry. */
export function readDocuments(json: unknown, file: string): ReadResult<AuditDocuments>;
/** The feature audit. */
export function readFeatureAudit(json: unknown, file: string): ReadResult<FeatureAudit>;
/** The product route mirror. */
export function readProductRoutes(json: unknown, file: string): ReadResult<ProductRoutes>;
