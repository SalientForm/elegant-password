import type { TestCase, TestFile, TestInventory } from './test-inventory.mjs';

/** A feature's status: `live`, `partial` and `parked` are the retired inventory's; `planned` has no route yet. */
export type FeatureStatus = 'live' | 'partial' | 'parked' | 'planned';

/** One feature: a `docs/features/<id>.md` file's front matter and body. */
export interface Feature {
  /** The file name without `.md`: lowercase kebab, permanent, the feature page's URL segment. */
  id: string;
  /** Repository path of the file. */
  path: string;
  title: string;
  status: FeatureStatus;
  /** One sentence, shown on the index. */
  summary: string;
  /** Product routes the feature owns, as the route mirror writes them (`settings.productRoutes`). */
  routes: string[];
  /** Repository-relative globs of the feature's source files, API handlers included. A file may sit in several features. */
  sources: string[];
  /** Extra test globs, for tests outside `sources`. */
  tests: string[];
  /** A Platform Docs path, optionally with `#anchor`. */
  platformDoc?: string;
  /** Spec paths. */
  specs: string[];
  /** Roadmap ids (`M10.1`, `X3`). */
  roadmap: string[];
  /** The markdown after the front matter. */
  body: string;
}

/** The files a build could match feature globs against. */
export interface FeatureSourceScan {
  /** `settings.areas.features.sourceRoots`, as configured: directories, or globs of directories. */
  roots: string[];
  /** Every file under the roots and under each `sources` glob's base, repository-relative and sorted; tests left out. */
  files: string[];
}

/** What the catalogue leaves out. */
export interface CatalogueGaps {
  /** Mirror routes no feature owns. */
  unownedRoutes: string[];
  /** `sources` globs that match no scanned file. */
  emptyGlobs: { feature: string; glob: string }[];
  /** Per source root, the files under it no feature's `sources` matches. */
  unclaimed: { root: string; files: string[] }[];
}

export const FEATURE_STATUSES: readonly FeatureStatus[];
export const RESERVED_FEATURE_IDS: readonly string[];
export const FEATURE_KEYS: readonly string[];

/** `docs/features/sign-in.md` → `sign-in`. */
export function featureId(path: string): string;

/** Features built from their files, sorted by title, and every problem a file alone shows. A feature with a problem is still built. */
export function featureRecords(files: readonly { path: string; markdown: string }[]): {
  features: Feature[];
  problems: string[];
};

/** `**`, `*`, `?` and `{a,b}` over repository-relative paths; no negation, no character classes. */
export function globMatcher(glob: string): (path: string) => boolean;

/** The directory a glob's matches sit under: its segments before the first wildcard. */
export function globBase(glob: string): string;

/** For each of a feature's `sources` globs, the files it matches. */
export function sourcesOf(feature: Feature, files: readonly string[]): { glob: string; files: string[] }[];

/** A matcher for the files under a source root: a directory, or a glob of directories (`libs/features/{a,b}/src`). */
export function underRoot(root: string): (path: string) => boolean;

export function catalogueGaps(
  features: readonly Feature[],
  options: { routes: readonly string[]; files: readonly string[]; roots: readonly string[] },
): CatalogueGaps;

/** The fragments a link to a `##` or `###` heading may use: the workspace's id and GitHub's slug. */
export function headingSlugs(markdown: string): Set<string>;

/** The tag prefix that names a feature on a Playwright test or describe: `{ tag: '@feature:sign-in' }`. */
export const FEATURE_TAG: '@feature:';

/** The file a test file tests: its path without the `.test` or `.spec` segment. */
export function testSubject(file: string): string;

/** A test with the ids of the features that own it (none when unassigned or infrastructure). */
export interface OwnedTestCase extends TestCase {
  owners: string[];
}

/** A test file whose tests carry their owners; in a feature's lists, only that feature's tests. */
export interface OwnedTestFile extends Omit<TestFile, 'tests'> {
  tests: OwnedTestCase[];
}

/** Which features own which tests. */
export interface TestOwnership {
  /** Per feature id, its unit (Vitest and node) and end-to-end (Playwright) files, each holding that feature's tests only. */
  features: Record<string, { unit: OwnedTestFile[]; e2e: OwnedTestFile[] }>;
  /** Every inventoried file, each test with its owners. */
  files: OwnedTestFile[];
  /** Files outside the infrastructure globs with a test no feature owns: those tests only. */
  unassigned: OwnedTestFile[];
  /** Files matching an infrastructure glob, with the tests no feature owns (a file with no test is listed too). */
  infrastructure: OwnedTestFile[];
  /** `@feature:` tags that name no feature. */
  unknownTags: { file: string; line: number; tag: string }[];
}

/**
 * Tests mapped to features: by `@feature:<id>` tag for a Playwright test that has one, else by the path of the file or
 * the file it tests against each feature's `sources` and `tests` globs.
 */
export function testOwnership(
  features: readonly Feature[],
  inventory: TestInventory,
  options: { infrastructure: readonly string[] },
): TestOwnership;
