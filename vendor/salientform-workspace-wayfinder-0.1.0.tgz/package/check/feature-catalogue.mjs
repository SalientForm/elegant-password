/**
 * The feature-catalogue drift check (spec M13 §5.4, plan M13.1 § The check): the feature files in
 * settings.areas[slug].directory, built by the builder the Features module shares (features.mjs), against the route
 * mirror (settings.productRoutes) and the repository. Plain node; the kit's runner (run.mjs) loads the settings and
 * passes what a rules file's `productRoutes` reads from the product's router.
 *
 * Fails when:
 *  - settings.areas[slug].directory does not exist or holds no *.md file, or a sourceRoots entry holds no file
 *  - a feature file has a problem featureRecords reports (a missing field, an unknown status or key, a list not
 *    written [a, b], a bad or reserved id, a route two features own)
 *  - settings.productRoutes is unset or does not read
 *  - a mirror route belongs to no feature, or a feature's route is not in the mirror
 *  - with the product's routes (`router`): a route or navigation path differs between the product and the mirror
 *  - a `sources` or `tests` glob matches no file (tests included in the walk)
 *  - a `platformDoc` path does not exist, or its #anchor is not one of its ## or ### headings
 *  - a `specs` path does not exist, or a `roadmap` id is not one of `roadmapIds` (by default the milestones, phases,
 *    Completed and Outside the roadmap rows of the Audit area's roadmap; skipped without one), or that roadmap does
 *    not parse
 *  - with an API registry (settings.areas[apiSlug].registry): a row lists a page whose feature's `sources` do not
 *    claim the row's handler
 *  - settings.areas[slug].reviewedAt fails the date rule
 *  - (M13.2) a tests.include glob matches no test file, or a tests.infrastructure glob no inventoried one
 *  - a test belongs to no feature and its file matches no tests.infrastructure glob
 *  - a Playwright `@feature:<id>` tag names no feature
 *
 * Reports (does not fail) the files under sourceRoots no feature's `sources` claims and the features with no tests,
 * which the Gaps page lists, and (M13.3) how many coverage summaries settings.areas[slug].coverage finds: a missing,
 * stale or unreadable summary is never a failure (spec M13 §11 D6).
 */
import { readdirSync } from 'node:fs';
import path from 'node:path';
import { readRegistry } from './audit-ledger.mjs';
import { checkAuditImplementation } from './audit-implementation.mjs';
import { readProductRoutes } from './audit-registries.mjs';
import { scanFeatureSources } from './feature-scan.mjs';
import { readCoverage } from './coverage-scan.mjs';
import { catalogueGaps, featureRecords, FEATURE_TAG, globMatcher, headingSlugs, testOwnership, underRoot } from './features.mjs';
import { exists, modifiedDateRule, readRepo, repoRoot } from './index.mjs';
import { scanTests } from './test-inventory.mjs';

const TEST_FILE = /\.(test|spec)\.[cm]?[jt]sx?$/;

/** "3 coverage summaries", or "no coverage summary (run the tests with coverage)", and any that did not parse. */
function coverageNote({ summaries, problems }) {
  const found = summaries.length === 0 ? 'no coverage summary (run the tests with coverage)' : `${summaries.length} coverage summaries`;
  return problems.length === 0 ? found : `${found}, ${problems.length} unreadable (${problems.join('; ')})`;
}

/** The ids a feature's `roadmap` may name: the milestones, their open phases, Completed rows and Outside the roadmap rows. */
function roadmapIdsOf(roadmap) {
  return [
    ...roadmap.milestones.flatMap((m) => [m.id, ...m.phases.map((p) => p.id)]),
    ...roadmap.completed.map((c) => c.id),
    ...roadmap.outside.map((o) => o.id),
  ];
}

/**
 * Runs the feature-catalogue rules over `settings` (the workspace config's data half); `slug` is the Features area's
 * key in `settings.areas`. `roadmapIds` are the ids a feature's `roadmap` may name (default: read from the Audit
 * area `auditSlug`'s roadmap; none when it has no roadmap). `router` is the product's routes and navigation (a rules file's `productRoutes`),
 * which the mirror must equal; omitted, the mirror is trusted. `apiSlug` names the API area whose registry's handlers
 * follow their pages. Returns { problems, features, productRoutes, gaps, inventory, ownership, summary };
 * `gaps.untested` lists the ids of the features, planned ones aside, that own no test.
 */
export function checkFeatureCatalogue(
  settings,
  { slug = 'features', roadmapIds, router, auditSlug = 'audit', apiSlug = 'api' } = {},
) {
  const area = settings.areas[slug];
  const at = `settings.areas.${slug}`;
  if (typeof area?.directory !== 'string') throw new Error(`wayfinder: ${at} has no directory`);
  if (!Array.isArray(area.sourceRoots)) throw new Error(`wayfinder: ${at} has no sourceRoots list`);
  if (!Array.isArray(area.tests?.include) || !Array.isArray(area.tests?.infrastructure))
    throw new Error(`wayfinder: ${at} has no tests.include and tests.infrastructure lists`);
  if (area.coverage !== undefined && !Array.isArray(area.coverage?.summaries))
    throw new Error(`wayfinder: ${at}.coverage has no summaries list`);
  const DIR = area.directory;
  const problems = [];

  const names = exists(DIR)
    ? readdirSync(path.join(repoRoot, DIR))
        .filter((f) => f.endsWith('.md'))
        .sort()
    : [];
  if (!exists(DIR)) problems.push(`fatal: ${DIR} (${at}.directory) does not exist`);
  else if (names.length === 0) problems.push(`fatal: ${DIR} (${at}.directory) holds no *.md feature`);

  const { features, problems: fileProblems } = featureRecords(
    names.map((f) => ({ path: `${DIR}/${f}`, markdown: readRepo(`${DIR}/${f}`) })),
  );
  for (const problem of fileProblems) problems.push(`malformed: ${problem}`);

  // The mirror: every route belongs to one feature (two owners are featureRecords' problem), and no feature names a
  // route the product does not register.
  const MIRROR = settings.productRoutes;
  let productRoutes = null;
  if (MIRROR === undefined) problems.push(`missing: settings.productRoutes names no route mirror, which every feature route is checked against`);
  else productRoutes = readRegistry(MIRROR, 'settings.productRoutes', readProductRoutes, problems);
  const mirrored = new Set(productRoutes?.routes ?? []);
  if (productRoutes) {
    for (const f of features)
      for (const route of f.routes)
        if (!mirrored.has(route)) problems.push(`missing: ${f.path}: route ${route} is not in the routes of ${MIRROR}`);
  }

  // The mirror equals the product's router and navigation.
  if (productRoutes && router) {
    const appRoutes = new Set(router.routes);
    for (const r of appRoutes) if (!mirrored.has(r)) problems.push(`missing: ${router.source} route ${r} not in the routes of ${MIRROR}`);
    for (const r of mirrored) if (!appRoutes.has(r)) problems.push(`stale: ${MIRROR} route ${r} not registered in ${router.source}`);
    if (router.sidebar) {
      const nav = router.sidebarSource ?? router.source;
      const navPaths = new Set(router.sidebar);
      const mirrorSidebar = new Set(productRoutes.sidebar ?? []);
      for (const p of navPaths) if (!mirrorSidebar.has(p)) problems.push(`missing: ${nav} path ${p} not in the sidebar of ${MIRROR}`);
      for (const p of mirrorSidebar) if (!navPaths.has(p)) problems.push(`stale: ${MIRROR} sidebar entry ${p} not in ${nav}`);
    }
  }

  // Globs, over every file under their bases and the roots, tests included (a `tests` glob names tests).
  const globs = features.flatMap((f) => [...f.sources, ...f.tests]);
  const { files } = scanFeatureSources(repoRoot, { roots: area.sourceRoots, globs, includeTests: true });
  for (const root of area.sourceRoots)
    if (!files.some(underRoot(root))) problems.push(`missing: ${root} (${at}.sourceRoots) holds no file`);
  for (const f of features)
    for (const [key, list] of [['sources', f.sources], ['tests', f.tests]])
      for (const glob of list) {
        const match = globMatcher(glob);
        if (!files.some(match)) problems.push(`missing: ${f.path}: ${key} glob ${glob} matches no file`);
      }

  // Links.
  let noRoadmap = false;
  if (roadmapIds === undefined && settings.areas[auditSlug]) {
    const { roadmap: parsed, paths } = checkAuditImplementation(settings, { slug: auditSlug });
    if (parsed) roadmapIds = roadmapIdsOf(parsed);
    else if (paths.roadmap === undefined) {
      noRoadmap = true;
      roadmapIds = [];
    } else problems.push(`malformed: ${paths.roadmap} did not parse, so no roadmap id was checked`);
  }
  const roadmap = roadmapIds ? new Set(roadmapIds) : null;
  for (const f of features) {
    if (f.platformDoc) {
      const [doc, anchor] = f.platformDoc.split('#');
      if (!exists(doc)) problems.push(`missing: ${f.path}: platformDoc ${doc} does not exist`);
      else if (anchor && !headingSlugs(readRepo(doc)).has(anchor))
        problems.push(`missing: ${f.path}: platformDoc anchor #${anchor} is not a ## or ### heading of ${doc}`);
    }
    for (const spec of f.specs) if (!exists(spec)) problems.push(`missing: ${f.path}: spec ${spec} does not exist`);
    if (roadmap)
      for (const id of f.roadmap)
        if (!roadmap.has(id))
          problems.push(
            noRoadmap
              ? `missing: ${f.path}: roadmap id ${id}, but settings.areas.${auditSlug} has no roadmap`
              : `missing: ${f.path}: roadmap id ${id} is not in the roadmap`,
          );
  }

  modifiedDateRule(problems, `${at}.reviewedAt`, area.reviewedAt);

  const gaps = catalogueGaps(features, {
    routes: productRoutes?.routes ?? [],
    files: files.filter((file) => !TEST_FILE.test(file)),
    roots: area.sourceRoots,
  });
  for (const route of gaps.unownedRoutes) problems.push(`unowned: route ${route} (${MIRROR}) belongs to no feature in ${DIR}`);

  // Tests (spec M13 §6): every test belongs to a feature or sits in an infrastructure file; every tag names a feature.
  const inventory = scanTests(repoRoot, area.tests);
  const ownership = testOwnership(features, inventory, { infrastructure: area.tests.infrastructure });
  for (const [key, list] of [['include', area.tests.include], ['infrastructure', area.tests.infrastructure]])
    for (const glob of list) {
      const match = globMatcher(glob);
      if (!inventory.files.some((f) => match(f.file))) problems.push(`missing: ${at}.tests.${key} glob ${glob} matches no test file`);
    }
  for (const file of ownership.unassigned) {
    const first = file.tests[0];
    const more = file.tests.length > 1 ? ` and ${file.tests.length - 1} more` : '';
    problems.push(
      `unassigned: ${file.file}: "${[...first.path, first.title].join(' › ')}"${more} belong to no feature — claim the file it tests in a feature's sources, add a tests glob, tag it ${FEATURE_TAG}<id>, or match it with ${at}.tests.infrastructure`,
    );
  }
  for (const { file, line, tag } of ownership.unknownTags) problems.push(`missing: ${file}:${line}: tag ${tag} names no feature in ${DIR}`);
  const untested = features
    .filter((f) => f.status !== 'planned')
    .filter((f) => ownership.features[f.id].unit.length + ownership.features[f.id].e2e.length === 0)
    .map((f) => f.id);

  const count = (files) => files.reduce((n, f) => n + f.tests.length, 0);
  // Tests a feature owns, end-to-end (Playwright) or unit (Vitest and node); a test two features own counts once.
  const owned = (e2e) =>
    ownership.files
      .filter((f) => (f.runner === 'playwright') === e2e)
      .reduce((n, f) => n + f.tests.filter((t) => t.owners.length > 0).length, 0);
  // API handlers follow their pages: the feature owning a page a registry row lists claims the row's handler.
  const API_REGISTRY = settings.areas[apiSlug]?.registry;
  let handlerPairs;
  if (typeof API_REGISTRY === 'string' && exists(API_REGISTRY)) {
    let endpoints = [];
    try {
      endpoints = JSON.parse(readRepo(API_REGISTRY)).endpoints ?? [];
    } catch {
      // An unreadable registry is the API check's problem.
    }
    const ownerOf = new Map(features.flatMap((f) => f.routes.map((route) => [route, f])));
    handlerPairs = 0;
    for (const endpoint of endpoints) {
      if (!endpoint.handler) continue;
      for (const page of endpoint.pages ?? []) {
        const feature = ownerOf.get(page);
        if (!feature) continue; // an unowned route is reported above
        handlerPairs++;
        if (!feature.sources.some((glob) => globMatcher(glob)(endpoint.handler)))
          problems.push(
            `missing: ${feature.path}: sources claim no ${endpoint.handler}, the handler of ${endpoint.method} ${endpoint.path}, which ${API_REGISTRY} lists for ${page}`,
          );
      }
    }
  }

  const unclaimed = gaps.unclaimed.reduce((n, root) => n + root.files.length, 0);
  const summary =
    `${settings.product}: ${features.length} features own ${mirrored.size} routes with ${globs.length} globs; ${unclaimed} unclaimed source files; ` +
    `${inventory.files.length} test files with ${count(inventory.files)} tests: ${owned(false)} unit, ${owned(true)} E2E, ` +
    `${count(ownership.infrastructure)} infrastructure; ${untested.length} features with no tests` +
    (area.coverage ? `; ${coverageNote(readCoverage(repoRoot, area.coverage.summaries))}` : '') +
    (router
      ? `; ${new Set(router.routes).size} app routes${router.sidebar ? `, ${new Set(router.sidebar).size} sidebar items` : ''}`
      : productRoutes
        ? '; the route mirror is not checked against the router (no productRoutes rule)'
        : '') +
    (handlerPairs === undefined ? '' : `${router ? ',' : ';'} ${handlerPairs} page handlers claimed`);
  return { problems, features, productRoutes, gaps: { ...gaps, untested }, inventory, ownership, summary };
}
