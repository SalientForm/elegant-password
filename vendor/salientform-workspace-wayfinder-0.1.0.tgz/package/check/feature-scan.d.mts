import type { FeatureSourceScan } from './features.mjs';

/**
 * Every file under `roots` and under each of `globs`' bases, repository-relative and sorted; tests left out unless
 * `includeTests`, and node_modules, dist, out-tsc, .nx, .git, coverage and test-output always.
 */
export function scanFeatureSources(
  repoRoot: string,
  options?: { roots?: readonly string[]; globs?: readonly string[]; includeTests?: boolean },
): FeatureSourceScan;
