export const ABOUT_DEFAULTS: { readonly skillsDir: string; readonly skillLinks: readonly string[]; readonly checkScript: string };
export const AUDIT_DEFAULTS: {
  readonly specDirs: readonly string[];
  readonly reviews: string;
  readonly ignore: readonly string[];
  readonly linkExempt: readonly string[];
};
/** The problems of `skillLinks` beside `skillsDir`: repository-relative, not `skillsDir` or inside it, no repeats. */
export function skillLinksProblems(skillsDir: unknown, skillLinks: unknown, at?: string): string[];
/** `about` with its defaults applied; throws on a `skillsDir` or `skillLinks` that breaks `skillLinksProblems`. */
export function aboutSettings<T extends object>(
  about: T
): T & { skillsDir: string; skillLinks: readonly string[]; checkScript: string };
/** Each implementation-file setting, the file it describes, and whether that file requires it. */
export const AUDIT_FILE_SETTINGS: readonly (readonly [setting: string, file: 'roadmap' | 'todo', required: boolean])[];
/**
 * `audit` with its defaults applied; throws on `ledger` or `documents`, and on a vocabulary without
 * its file or a roadmap or TODO list without its vocabulary.
 */
export function auditSettings<T extends object>(
  audit: T
): T & { specDirs: readonly string[]; reviews: string; ignore: readonly string[]; linkExempt: readonly string[] };
/** The command that runs a root package.json script, from its `packageManager` field. */
export function scriptCommand(packageJson: { packageManager?: string } | undefined, script: string): string;
