/**
 * The feature-audit drift check (spec M12.9 §5.8): the JSON registry settings.areas[slug].featureAudit, read by the
 * reader the Audit module shares (audit-registries.mjs), against the repository and the TODO list. Plain node. The
 * feature inventory and its rule against the route mirror moved to the feature catalogue's check in M13.1
 * (feature-catalogue.mjs).
 *
 * Fails when:
 *  - the feature audit is missing, is not JSON, or has a problem its reader reports
 *  - settings.areas[slug] has no TODO list (`todo`), or its todoSources does not list 'feature-audit:'
 *  - a finding's `files` path (a directory when it ends in '/') does not exist
 *  - a `kind: 'todo'` finding has no TODO whose Source is feature-audit:<slug>, or such a TODO has no todo finding
 *  - without `todos`: the TODO list is missing or malformed (the pairing rule is then skipped)
 *  - the feature audit's reviewedAt fails the date rule
 */
import { exists } from './index.mjs';
import { checkAuditImplementation } from './audit-implementation.mjs';
import { readRegistry, reviewedAtRule } from './audit-ledger.mjs';
import { FEATURE_AUDIT_SOURCE, readFeatureAudit } from './audit-registries.mjs';

/**
 * Runs the feature-audit rules over `settings` (the workspace config's data half); `slug` is the Audit area's key in
 * `settings.areas`. `todos` is the TODO list the implementation check parsed (parsed here when omitted; null when it
 * did not parse, which skips the pairing rule). Returns { problems, featureAudit, summary }; a registry that cannot be
 * read is null.
 */
export function checkFeatureAudit(settings, { slug = 'audit', todos } = {}) {
  const area = settings.areas[slug];
  if (typeof area?.featureAudit !== 'string') throw new Error(`wayfinder: settings.areas.${slug} has no featureAudit path`);
  const at = `settings.areas.${slug}`;
  const AUDIT = area.featureAudit;
  const TODO = area.todo;
  const problems = [];

  const featureAudit = readRegistry(AUDIT, `${at}.featureAudit`, readFeatureAudit, problems);
  if (TODO === undefined)
    problems.push(`malformed: ${at}.featureAudit needs ${at}.todo: a feature audit's todo findings pair with TODO entries`);
  else if (!(area.todoSources ?? []).includes(FEATURE_AUDIT_SOURCE))
    problems.push(`malformed: ${at}.todoSources does not list '${FEATURE_AUDIT_SOURCE}', which a feature audit's TODOs use as their Source`);

  const findings = featureAudit?.findings ?? [];

  // 1. Every finding's files exist.
  for (const f of findings)
    for (const p of f.files) if (!exists(p)) problems.push(`missing: findings ${f.slug} files entry ${p} does not exist (${AUDIT})`);

  // 2. Every todo finding has a TODO whose Source is feature-audit:<slug>, and the reverse.
  let list = todos;
  if (todos === undefined) {
    // Parsed here: when the TODO list does not parse, the pairing rule is skipped, so say why.
    const implementation = checkAuditImplementation(settings, { slug });
    list = implementation.todos;
    if (!list)
      problems.push(
        ...implementation.problems.filter((p) => p.startsWith(`malformed: ${TODO}:`) || p === `missing: ${TODO} does not exist`),
      );
  }
  const todoFindings = findings.filter((f) => f.kind === 'todo');
  if (list && featureAudit) {
    const sources = list.todos
      .filter((t) => t.source.startsWith(FEATURE_AUDIT_SOURCE))
      .map((t) => ({ id: t.id, slug: t.source.slice(FEATURE_AUDIT_SOURCE.length) }));
    for (const f of todoFindings)
      if (!sources.some((t) => t.slug === f.slug))
        problems.push(`missing: findings todo "${f.title}" has no ${TODO} entry with Source ${FEATURE_AUDIT_SOURCE}${f.slug}`);
    const slugs = new Set(todoFindings.map((f) => f.slug));
    for (const t of sources)
      if (!slugs.has(t.slug))
        problems.push(`stale: ${TODO} #${t.id} Source ${FEATURE_AUDIT_SOURCE}${t.slug} has no finding with kind 'todo' and that slug (${AUDIT})`);
  }

  // 3. Date rule.
  if (featureAudit) reviewedAtRule(problems, AUDIT, featureAudit.reviewedAt);

  const summary = `${findings.length} findings, ${todoFindings.length} todo findings`;
  return { problems, featureAudit, summary };
}
