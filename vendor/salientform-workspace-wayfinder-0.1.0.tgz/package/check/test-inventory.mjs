/**
 * The test inventory (spec M13 §6.1, plan M13.2 § The inventory): every test file the Features area's
 * `tests.include` globs match, parsed statically with the TypeScript compiler API (the optional peer `typescript`)
 * into describe paths, titles, lines, modifiers and Playwright tags. Plain node, so the area's Vite plugin and the
 * catalogue check build the same inventory; the browser never loads this file. Types: test-inventory.d.mts.
 */
import { existsSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { scanFeatureSources } from './feature-scan.mjs';
import { globMatcher } from './features.mjs';

/** The identifiers a test or describe call starts from. */
const ROOTS = new Set(['describe', 'suite', 'it', 'test']);
const DESCRIBES = new Set(['describe', 'suite']);
const MODIFIERS = new Set(['skip', 'only', 'todo', 'fixme']);
/** Members that make a call something other than a test or describe: hooks, fixtures, steps and annotations. */
const NOT_TESTS = new Set([
  'step',
  'use',
  'extend',
  'configure',
  'info',
  'slow',
  'setTimeout',
  'beforeEach',
  'afterEach',
  'beforeAll',
  'afterAll',
  'expect',
]);
/** Array methods whose callback runs once per element: a test declared inside one is parameterised. */
const ITERATORS = new Set(['forEach', 'map', 'flatMap']);
const TITLE_TAG = /(?:^|\s)(@[\w:.-]+)/g;

/**
 * The TypeScript compiler, loaded on the first parse: `typescript` is an optional peer dependency, needed only by a
 * repository whose Features area lists its tests, so loading the kit's Vite plugins or checks never requires it.
 */
let ts;

/**
 * `loaded` (what `require('typescript')` gave, or undefined when it threw) if it has the compiler API the inventory
 * parses with; otherwise an error saying what to install. TypeScript 7's package has no such API.
 */
export function compilerFrom(loaded) {
  if (typeof loaded?.createSourceFile === 'function' && loaded.ScriptKind) return loaded;
  const found = loaded ? `typescript ${loaded.version ?? '(unknown version)'}, which has no compiler API` : 'no typescript';
  throw new Error(
    `wayfinder: the Features area's test inventory parses test files with the TypeScript compiler API, from the kit's optional peer dependency typescript (5.9 or later 5.x); found ${found}. Install it beside the kit, or leave areas.features.tests out.`
  );
}

function compiler() {
  if (ts) return ts;
  let loaded;
  try {
    loaded = createRequire(import.meta.url)('typescript');
  } catch {
    loaded = undefined;
  }
  ts = compilerFrom(loaded);
  return ts;
}

const scriptKind = (file) =>
  file.endsWith('.tsx') ? ts.ScriptKind.TSX : file.endsWith('.jsx') ? ts.ScriptKind.JSX : /\.[cm]?js$/.test(file) ? ts.ScriptKind.JS : ts.ScriptKind.TS;

/**
 * The member chain of a call's callee, root first (`test.describe.serial` → ['test', 'describe', 'serial']), and
 * whether it is curried (`test.each(table)(…)`, `it.skipIf(c)(…)`, `` it.each`…`(…) ``); null when it does not start
 * at an identifier.
 */
function chainOf(callee) {
  const names = [];
  let curried = false;
  let node = callee;
  for (;;) {
    if (ts.isPropertyAccessExpression(node)) {
      names.unshift(node.name.text);
      node = node.expression;
    } else if (ts.isCallExpression(node)) {
      curried = true;
      node = node.expression;
    } else if (ts.isTaggedTemplateExpression(node)) {
      curried = true;
      node = node.tag;
    } else if (ts.isIdentifier(node)) {
      names.unshift(node.text);
      return { names, curried };
    } else return null;
  }
}

const isFunction = (node) => ts.isArrowFunction(node) || ts.isFunctionExpression(node);

/** A literal's text as written; any other expression as its source (a template keeps its `${…}`). */
function titleOf(node, sf) {
  if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) return node.text;
  if (ts.isTemplateExpression(node)) return node.getText(sf).slice(1, -1);
  return node.getText(sf);
}

/** Tags from a Playwright details object's `tag`: a string or a list of strings. */
function optionTags(node) {
  if (!node || !ts.isObjectLiteralExpression(node)) return [];
  const tag = node.properties.find((p) => ts.isPropertyAssignment(p) && p.name.getText() === 'tag');
  if (!tag) return [];
  const value = tag.initializer;
  const literal = (n) => (ts.isStringLiteral(n) || ts.isNoSubstitutionTemplateLiteral(n) ? [n.text] : []);
  return ts.isArrayLiteralExpression(value) ? value.elements.flatMap(literal) : literal(value);
}

/** `@tokens` in a title, which Playwright reads as tags. */
const titleTags = (title) => [...title.matchAll(TITLE_TAG)].map((m) => m[1]);

/**
 * What a call declares: a describe (with a body), a test (with a body, or `.todo` with a title), or nothing (a hook,
 * a step, `test.skip(condition)` inside a test, any other call).
 */
function classify(call) {
  const chain = chainOf(call.expression);
  if (!chain || !ROOTS.has(chain.names[0])) return null;
  const { names, curried } = chain;
  if (names.some((n) => NOT_TESTS.has(n))) return null;
  const describe = DESCRIBES.has(names[0]) || names.includes('describe');
  const modifier = names.find((n) => MODIFIERS.has(n));
  const args = call.arguments;
  const body = args.length > 0 && isFunction(args[args.length - 1]);
  const titled = args.length > 0 && !isFunction(args[0]);
  const parameterised = curried && (names.includes('each') || names.includes('for'));
  if (describe) return body ? { kind: 'describe', modifier, titled, parameterised } : null;
  if (!titled) return null;
  if (!body && !(modifier === 'todo' || args.length === 1)) return null;
  return { kind: 'test', modifier, parameterised };
}

/** A node that runs its body more than once: a loop, or a callback of forEach, map or flatMap. */
function repeats(node) {
  if (ts.isForStatement(node) || ts.isForOfStatement(node) || ts.isForInStatement(node) || ts.isWhileStatement(node) || ts.isDoStatement(node))
    return true;
  const parent = node.parent;
  return (
    isFunction(node) &&
    parent !== undefined &&
    ts.isCallExpression(parent) &&
    ts.isPropertyAccessExpression(parent.expression) &&
    ITERATORS.has(parent.expression.name.text)
  );
}

/**
 * The path a `goto` argument opens (plan M13.3): a literal as written, a template's `${…}` as a `:param` segment,
 * without the query or fragment; undefined for anything else, or a path not starting with '/'.
 */
function visitedPath(node) {
  let text;
  if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) text = node.text;
  else if (ts.isTemplateExpression(node)) text = node.head.text + node.templateSpans.map((span) => `:param${span.literal.text}`).join('');
  else return undefined;
  const opened = text.split(/[?#]/)[0];
  return opened.startsWith('/') ? opened : undefined;
}

/**
 * Where a Playwright file's code navigates: `visitsOf(node)` is every path a `*.goto(…)` under `node` opens, and those
 * of the same-file functions it calls by name, transitively. `hooksOf(statements)` is what the `beforeEach` hooks
 * among `statements` open.
 */
function navigation(sf) {
  const direct = (node) => {
    const visits = [];
    const calls = [];
    const walk = (n) => {
      if (ts.isCallExpression(n)) {
        const callee = n.expression;
        if (ts.isPropertyAccessExpression(callee) && callee.name.text === 'goto' && n.arguments[0]) {
          const opened = visitedPath(n.arguments[0]);
          if (opened) visits.push(opened);
        }
        if (ts.isIdentifier(callee)) calls.push(callee.text);
      }
      ts.forEachChild(n, walk);
    };
    walk(node);
    return { visits, calls };
  };
  const helpers = new Map();
  const collect = (n) => {
    if (ts.isFunctionDeclaration(n) && n.name && n.body) helpers.set(n.name.text, direct(n.body));
    else if (ts.isVariableDeclaration(n) && ts.isIdentifier(n.name) && n.initializer && isFunction(n.initializer))
      helpers.set(n.name.text, direct(n.initializer.body));
    ts.forEachChild(n, collect);
  };
  collect(sf);
  const resolve = (name, seen) => {
    const helper = helpers.get(name);
    if (!helper || seen.has(name)) return [];
    seen.add(name);
    return [...helper.visits, ...helper.calls.flatMap((call) => resolve(call, seen))];
  };
  const visitsOf = (node) => {
    const { visits, calls } = direct(node);
    const seen = new Set();
    return [...visits, ...calls.flatMap((call) => resolve(call, seen))];
  };
  const hooksOf = (statements) =>
    statements.flatMap((statement) => {
      if (!ts.isExpressionStatement(statement) || !ts.isCallExpression(statement.expression)) return [];
      const chain = chainOf(statement.expression.expression);
      // test.beforeEach(…), or a bare beforeEach(…).
      if (!chain?.names.includes('beforeEach')) return [];
      return statement.expression.arguments.filter(isFunction).flatMap(visitsOf);
    });
  return { visitsOf, hooksOf };
}

const statementsOf = (fn) => (ts.isBlock(fn.body) ? [...fn.body.statements] : []);

/** The runner a file's imports name: Playwright, node:test, or Vitest by default. */
function runnerOf(sf, playwright) {
  if (playwright) return 'playwright';
  const sources = sf.statements.filter(ts.isImportDeclaration).map((s) => s.moduleSpecifier.text);
  if (sources.includes('@playwright/test')) return 'playwright';
  if (sources.includes('node:test')) return 'node';
  return 'vitest';
}

/**
 * One test file's tests, in source order, from `source`. `playwright` forces the Playwright runner, for a file that
 * imports its `test` from a fixtures module.
 */
export function parseTestFile(file, source, { playwright = false } = {}) {
  compiler();
  const sf = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, scriptKind(file));
  const runner = runnerOf(sf, playwright);
  // Only end-to-end tests record the paths they open (M13.3's routes visited).
  const nav = runner === 'playwright' ? navigation(sf) : undefined;
  const tests = [];
  const visit = (node, ctx) => {
    if (ts.isCallExpression(node)) {
      const found = classify(node);
      if (found) {
        const args = node.arguments;
        const title = found.kind === 'describe' && !found.titled ? undefined : titleOf(args[0], sf);
        // Playwright's details object sits between the title and the body: test('t', { tag }, fn).
        const tags = [
          ...ctx.tags,
          ...optionTags(args.length >= 3 ? args[1] : undefined),
          ...(runner === 'playwright' && title !== undefined ? titleTags(title) : []),
        ];
        const modifier = found.modifier ?? ctx.modifier;
        if (found.kind === 'describe') {
          const inner = {
            path: title === undefined ? ctx.path : [...ctx.path, title],
            tags,
            modifier,
            // A describe.each's tests repeat with it.
            repeated: ctx.repeated || found.parameterised,
            visits: nav ? [...ctx.visits, ...args.filter(isFunction).flatMap((fn) => nav.hooksOf(statementsOf(fn)))] : [],
          };
          for (const arg of args) if (isFunction(arg)) visit(arg, inner);
        } else {
          const visits = nav ? [...new Set([...ctx.visits, ...args.filter(isFunction).flatMap((fn) => nav.visitsOf(fn))])] : [];
          tests.push({
            path: ctx.path,
            title,
            line: sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1,
            ...(modifier ? { modifier } : {}),
            ...(found.parameterised || ctx.repeated ? { parameterised: true } : {}),
            tags: [...new Set(tags)],
            ...(visits.length > 0 ? { visits } : {}),
          });
        }
        return;
      }
    }
    const next = !ctx.repeated && repeats(node) ? { ...ctx, repeated: true } : ctx;
    ts.forEachChild(node, (child) => visit(child, next));
  };
  visit(sf, { path: [], tags: [], modifier: undefined, repeated: false, visits: nav ? nav.hooksOf([...sf.statements]) : [] });
  return { file, runner, tests };
}

/** The `name` of the nearest project.json, else package.json, from `dir` up to the repository root; '' for none. */
function projectFinder(repoRoot) {
  const cache = new Map();
  const find = (dir) => {
    if (cache.has(dir)) return cache.get(dir);
    let name;
    for (const manifest of ['project.json', 'package.json']) {
      const file = path.join(repoRoot, dir, manifest);
      if (name === undefined && existsSync(file)) {
        try {
          const parsed = JSON.parse(readFileSync(file, 'utf8'));
          if (typeof parsed.name === 'string') name = parsed.name;
        } catch {
          // An unreadable manifest names no project.
        }
      }
    }
    if (name === undefined) name = dir === '' ? '' : find(path.posix.dirname(dir) === '.' ? '' : path.posix.dirname(dir));
    cache.set(dir, name);
    return name;
  };
  return (file) => find(path.posix.dirname(file) === '.' ? '' : path.posix.dirname(file));
}

/**
 * Every test file `tests.include` matches under `repoRoot`, parsed, in path order. `parse(file, source, options)`
 * defaults to parseTestFile; the Vite plugin passes a cached one. The walk skips what the source scan skips.
 */
export function scanTests(repoRoot, tests, parse = parseTestFile) {
  const include = tests.include.map(globMatcher);
  const playwright = (tests.playwright ?? []).map(globMatcher);
  const { files } = scanFeatureSources(repoRoot, { globs: tests.include, includeTests: true });
  const projectOf = projectFinder(repoRoot);
  return {
    files: files
      .filter((file) => include.some((match) => match(file)))
      .map((file) => {
        const parsed = parse(file, readFileSync(path.join(repoRoot, file), 'utf8'), { playwright: playwright.some((match) => match(file)) });
        return { file, runner: parsed.runner, project: projectOf(file), tests: parsed.tests };
      }),
  };
}
