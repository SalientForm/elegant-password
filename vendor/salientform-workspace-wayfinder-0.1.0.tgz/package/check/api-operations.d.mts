/** The API module's data: the OpenAPI subset it reads, the consumer registry and its rows. */

/** A JSON Schema, as far as the API page reads one. */
export interface JsonSchema {
  $ref?: string;
  type?: string | string[];
  format?: string;
  enum?: unknown[];
  properties?: Record<string, JsonSchema>;
  required?: string[];
  items?: JsonSchema;
  oneOf?: JsonSchema[];
  anyOf?: JsonSchema[];
  additionalProperties?: unknown;
  default?: unknown;
  minimum?: number;
  maximum?: number;
  minLength?: number;
}

export interface OpenApiParameter {
  name: string;
  /** 'query', 'path', 'header' or 'cookie'; the page lists query parameters. */
  in: string;
  required?: boolean;
  schema?: JsonSchema;
}

export interface OpenApiOperation {
  summary?: string;
  tags?: string[];
  parameters?: OpenApiParameter[];
  requestBody?: { content?: Record<string, { schema?: JsonSchema }> };
  responses?: Record<string, { content?: Record<string, { schema?: JsonSchema }> }>;
}

/** An OpenAPI 3 document, as far as the API module reads one: its paths, tags and component schemas. */
export interface OpenApiDocument {
  /** Path → path item; a path item's lower-case HTTP method keys are its operations. */
  paths?: Record<string, Record<string, OpenApiOperation | unknown>>;
  /** Declared tags, in the order the area groups operations without a registry. */
  tags?: { name: string }[];
  /** `$ref: '#/components/schemas/<name>'` targets. */
  components?: { schemas?: Record<string, JsonSchema> };
}

/** One group of the page: a section, its anchor and a nav item. */
export interface ApiGroup {
  /** Lowercase kebab; the section's anchor. 'unlisted' is reserved for operations the registry does not list. */
  id: string;
  label: string;
}

/**
 * used   — the product calls it from a reachable page
 * unused — nothing in the product calls it
 * stub   — it responds with placeholder data
 */
export type ApiEndpointStatus = 'used' | 'unused' | 'stub';

/** One row of a consumer registry: what the document cannot say about an operation. */
export interface ApiEndpoint {
  /** Upper case: GET, PUT, POST, PATCH, DELETE, HEAD, OPTIONS or TRACE. */
  method: string;
  /** As the document writes it, e.g. '/api/cases'. */
  path: string;
  /** An `ApiGroup` id. */
  group: string;
  /** What comes back, in one clause. */
  description: string;
  status: ApiEndpointStatus;
  /** Repository path of the handler's source. */
  handler?: string;
  /** The code that calls it, when `used`. */
  consumer?: string;
  /** Product routes that render its data; each links to the product (`productUrl`). */
  pages?: string[];
  note?: string;
  /** An example request path, linked to the running API. */
  example?: string;
  /** Served by the API but not described by the document: the page shows no shapes and the agreement rules skip it. */
  outsideDocument?: true;
}

/** A consumer registry (`settings.areas.api.registry`, JSON): the overlay an OpenAPI document cannot express. */
export interface ApiRegistry {
  /**
   * Repository directory handler labels are relative to: a handler outside it is labelled relative to the nearest
   * ancestor of it that contains the handler (`apps/api/src/routes` labels `apps/api/src/app.ts` as `app.ts`).
   */
  handlerRoot?: string;
  /** In page order. */
  groups: ApiGroup[];
  /** One row per method and path, in page order. */
  endpoints: ApiEndpoint[];
}

/** One row of the API page: a document operation, a registry row, or both. */
export interface ApiOperation {
  method: string;
  path: string;
  /** `${method} ${path}`: the search title and the source of the row id. */
  key: string;
  /** An `ApiGroup` id. */
  group: string;
  /** Whether the document describes it. */
  inDocument: boolean;
  /** The registry row's description, else the document operation's summary, else ''. */
  description: string;
  /** The registry row, when there is one. */
  endpoint?: ApiEndpoint;
  /** The handler's label (relative to `handlerRoot` or its nearest containing ancestor), when the row names a handler. */
  handlerLabel?: string;
}

export const HTTP_METHODS: readonly string[];
export const ENDPOINT_STATUSES: readonly ApiEndpointStatus[];
export const UNLISTED_GROUP: ApiGroup;

/** Every operation the document describes, in document order: one per HTTP method of each path item. */
export function documentOperations(document: unknown): {
  method: string;
  path: string;
  key: string;
  summary?: string;
  tags: string[];
}[];

/**
 * A handler's label: its path relative to the nearest of `root` and root's ancestors that contains it, else its
 * whole path; without a root, its file name.
 */
export function handlerLabel(handler: string, root?: string): string;

/**
 * The page's groups and rows, every problem (the registry's own faults, or a document with no `paths`) and the drift
 * (where the registry and the document disagree). Without a registry the groups are the document's tags.
 */
export function apiOperations(
  document: unknown,
  registry?: unknown,
  names?: { document?: string; registry?: string }
): { groups: ApiGroup[]; operations: ApiOperation[]; problems: string[]; drift: string[] };
